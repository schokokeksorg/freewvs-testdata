PR.registerLangHandler(PR.sourceDecorator({
    keywords: "bytes,default,double,enum,extend,extensions,false,group,import,max,message,option,optional,package,repeated,required,returns,rpc,service,syntax,to,true",
    types: /^(bool|(double|s?fixed|[su]?int)(32|64)|float|string)\b/,
    cStyleComments: !0
}), ["proto"]);
