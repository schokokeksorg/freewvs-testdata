<?php

/************************************************
 * DeluxeBB 1.3                                 *
 * Copyright (C) 2005-2009 Frank Nissel         *
 * http://www.DeluxeBB.com	                    *
 * For license information, please read the     *
 * license file in the docs/ folder! 			      *
 ************************************************/


$cssstyle = 'forum.css';
require('./header.php');
$footer=TRUE;

$fid = @intval($fid);

##guests allowed to see forums?
if($settings['guestforumview']==0 && usercheck()==FALSE) {
	require('./header_html.php');
	bar($bar_unknown_forum);
	message($lang_guestnoaccess, $lang_guestnoaccess2);
	quit();
}

$forums = $db->query("SELECT * FROM ".$prefix."forums WHERE (fid='$fid')");
$forum = $db->fetch_array($forums);

$where = 'Viewing forum: '.addslashes($forum['name']);
$temptitle = $forum['name'];

//security checks
if($forum['password']!='') {
	if(!$_COOKIE['membercookie'] || $_COOKIE['membercookie']=='guest') {
		require('./header_html.php');
		bar($bar_seperator.'<a href="forums.php?fid='.$forum['fid'].'">'.$forum['name'].'</a>'.$bar_seperator.$bar_forum_restr);
		include($templatefolder.'/error_forum_restrictions.dtf');
    include('./footer.php');
    exit();
	}

	if($action == 'pwverify') {
		if($pw != $forum['password']) {
			require('./header_html.php');
			bar($bar_seperator.'<a href="forums.php?fid='.$forum['fid'].'">'.$forum['name'].'</a>'.$bar_seperator.$bar_wrong_pw);
			message($lang_badpassword, $lang_badpasswordinfo);
			quit();
		} else {
			setcookie("fpw$fid", $pw, time()+86400*7, $cp, $cd, $cs);
			redirect("forums.php?fid=$fid", 0);
			exit();
		}
	}
	
	if($_COOKIE['fpw'.$fid]=='' || $forum['password']!=$_COOKIE['fpw'.$fid]) {
		require('./header_html.php');
		bar($bar_seperator.'<a href="forums.php?fid='.$forum['fid'].'">'.$forum['name'].'</a>'.$bar_seperator.$bar_pw_req);
		include($templatefolder.'/enterpw.dtf');
		$footer = FALSE;
		quit();
	}
}

require('./header_html.php');

if(!$fid || !$forum['fid']) {
	bar($bar_unknown_forum);
	message($lang_forum_not_exist, $lang_forwardmainpage, "index.php");
	quit();
}

if(!access($member['username'], $member['membercode'], $forum['viewstatus'], '', '', $forum['userlist'])) {
	bar($bar_seperator.'<a href="forums.php?fid='.$forum['fid'].'">'.$forum['name'].'</a>');
	include($templatefolder.'/error_forum_restrictions.dtf');
  include('./footer.php');
  exit();
}
//security checks end

// Get Mods
if($forum['moderators']!='' && $settings['showmod']!=0) {
	$mod = explode(", ", $forum['moderators']);
	$modbar = " <em>($lang_forumismoderatedby ";
	for($x=0;$x<sizeof($mod);$x++) {
		if(sizeof($mod)-1==$x) {
			$modbar .= "<a href=\"misc.php?sub=profile&amp;name=$mod[$x]\">$mod[$x]</a>)</em>";
		} else {
			$modbar .= "<a href=\"misc.php?sub=profile&amp;name=$mod[$x]\">$mod[$x]</a>, ";
		}
	}
}

//the bar
bar($bar_seperator.$forum['name'].$modbar);

//handling redirected forums
if($forum['redirect']!='') {
	message($lang_forumredirection, $lang_forumredirectiontxt, $forum['redirect'], 4);
	quit();
}

// Show topics from x and sort them by x, defining important values
if(!$from || $from==0) {
	$posttime = 0;
} else {
	$from = intval($from);
	$add = '&from='.$from;
	$posttime = time()-(86400*$from);
}
if($sort!='ASC' && $sort!='DESC') {
	$sort = 'DESC';
}
$add .= '&sort='.$sort;

//calculating pages and navigation
$current_count = 0;
$tppt = $settings['tppt'];

//caching censors
if($settings['censors']!=0) {
	bbcodecache();
}

//forum info
$rows = $db->query("SELECT COUNT(tid) FROM ".$prefix."threads WHERE (lastpostdate>='$posttime' && fid='$fid')");
$nrows = $db->result($rows);

$pageinfo = multipage($nrows, $page, $settings['tppf'], "forums.php?fid=$fid", $add);

include($templatefolder.'/forums_header.dtf');

//get and format all threads
$threads = $db->query("SELECT t.*,u.username FROM ".$prefix."threads t LEFT JOIN ".$prefix."users u ON (t.author=u.uid) WHERE (t.fid='$fid' && t.lastpostdate>='$posttime') ORDER BY t.pinned $sort,t.lastpostdate $sort LIMIT $pageinfo[0], $pageinfo[1]");

while($open = $db->fetch_array($threads)) {
	##doing censoring
	$open['subject'] = bbcode($open['subject'], 1);
	
	$posts=$open['replies']+1;
	$pagenum = ceil($posts/$tppt);
	for($y = 1; $y <= $pagenum && $y < 4; $y++) {
		$topic_pagelinks .= " <a href=\"topic.php?fid=$open[fid]&amp;tid=$open[tid]&amp;page=$y\">$y</a>";
	}
	if($pagenum > 3) {
		$topic_pagelinks .= " <a href=\"topic.php?fid=$open[fid]&amp;tid=$open[tid]&amp;page=$pagenum\">&raquo;</a>";
	} elseif($pagenum == 1) {
		$topic_pagelinks = '';
	}
	if($open['closed'] == '0') { $statusicon = lastvisit(); }
	if($open['closed'] == '1') { $statusicon = '<img src="'.$images.'/lock_folder.gif" alt="Locked Folder" />'; }

	if($open['author']!=0) {
		$author = "<a href=\"misc.php?sub=profile&amp;uid=$open[author]\">$open[username]</a>";
	} else {
		$author = $lang_guest;
	}
	if($open['lastpostby'] != 'guest') {
		$lastpost = "$lang_by <a href=\"misc.php?sub=profile&amp;name=".urlencode($open['lastpostby'])."\">$open[lastpostby]</a>";
	} else {
		$lastpost = "$lang_by $lang_guest";
	}
	if($open['lastpostdate']!='') {
		$date = gmdate($datecode, $open['lastpostdate'] + ($member['timeoffset'] * 3600));
		$time = gmdate($timecode, $open['lastpostdate'] + ($member['timeoffset'] * 3600));
		$lastpost .= "<br /> $date $lang_at $time";
	}
	
	if($open['moved']!=0) {
		include($templatefolder.'/forums_redirect.dtf');
	} elseif($open['pinned']==1) {
		include($templatefolder.'/forums_pinned.dtf');
	} elseif($open['pinned']==0) {
		include($templatefolder.'/forums_fields.dtf');
	}
		
	$topic_pagelinks = '';
	$posts=0;
}


/* Rules */
if($showrules) {
	if(!access($member['username'], $member['membercode'], $forum['viewstatus'], $forum['poststatus'], '', '')) {
		$rules = $lang_maynotpost."<br />";
	} else {
		$rules = $lang_maypost."<br />";
	}

	if(!access($member['username'], $member['membercode'], $forum['viewstatus'], '', $forum['replystatus'], '')) {
		$rules .= $lang_maynotreply."<br />";
	} else {
		$rules .= $lang_mayreply."<br />";
	}

	if((($settings['useredit']==1 && $_COOKIE['membercookie']!='') || $member['membercode']>1) && ($forum['poststatus']!='no' && $forum['replystatus']!='no')) {
		$rules .= $lang_mayedit;
	} else {
		$rules .= $lang_maynotedit;
	}

	if($settings['htmloff']==0) {
		$features = $lang_htmlenabled.'<br />';
	} else {
		$features = $lang_htmldisabled.'<br />';
	}

	if($settings['smilies']==1) {
		$features .= $lang_smilieson.'<br />';
	} else {
		$features .= $lang_smiliesoff.'<br />';
	}
	
	if($settings['allowattach']==1) {
		$features .= $lang_attachenabled;
	} else {
		$features .= $lang_attachdisabled;
	}
}

include($templatefolder.'/forums_footer.dtf');
include('./footer.php');

?>