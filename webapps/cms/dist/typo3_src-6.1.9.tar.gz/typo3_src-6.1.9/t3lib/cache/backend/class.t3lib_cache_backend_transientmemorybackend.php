<?php
/*
 * @deprecated since 6.0, the classname t3lib_cache_backend_TransientMemoryBackend and this file is obsolete
 * and will be removed with 6.2. The class was renamed and is now located at:
 * typo3/sysext/core/Classes/Cache/Backend/TransientMemoryBackend.php
 */
require_once \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath('core') . 'Classes/Cache/Backend/TransientMemoryBackend.php';
?>