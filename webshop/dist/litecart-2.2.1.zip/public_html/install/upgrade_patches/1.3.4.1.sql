UPDATE `lc_translations` SET `text_en` = 'Order %order_id has updated to %order_status' where `code` = 'email_subject_order_updated';
