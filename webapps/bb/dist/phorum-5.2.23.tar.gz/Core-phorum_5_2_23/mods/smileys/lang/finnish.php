<?php
$PHORUM["DATA"]["LANG"]["mod_smileys"] = array(
    'smiley'        => 'Liit� hymi�',
    'subjectsmiley' => 'Liit� hymi� otsikkoon',
    'smileys help'  => 'Hymi�-ohje',

    # Text for the smileys disable option in the posting editor.
    'disable'      => 'Disable smileys for this message'
);
?>
