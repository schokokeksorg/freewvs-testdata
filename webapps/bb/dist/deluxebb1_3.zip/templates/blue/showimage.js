function display(src){
	html='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><title>Photo</title></head><body style="margin:0;"><div><img src="'+src+'" /></div></body>';
	var img = new Image();
	img.src = src; 
	img.onload = function() {
		var leftPos = (screen.availWidth - img.width) / 2;
		var topPos = (screen.availHeight - img.height) / 2;
		popup=window.open('','image','toolbar=0,location=0,directories=0,menuBar=0,scrollbars=0,resizable=1,width=' + img.width + ',height=' + img.height + ',left=' + leftPos + ',top=' + topPos);
		popup.document.open();
		popup.document.write(html);
		popup.document.body.focus();
		popup.document.close()
	}
};
var oldonload = window.onload;
if (typeof window.onload != 'function') {
	window.onload = function () {
		var imgs = document.getElementsByTagName('img');
		
		var i;
		for(i=0;i<imgs.length;i++) {
			if(imgs[i].className == 'userimage') {
				imgs[i].onclick = function () { display(this.src) };
				if(imgs[i].width >= 512) {
					imgs[i].style.width = '512px';
					imgs[i].style.height = (512 / imgs[i].width * imgs[i].height).toString()+'px';
				}
			}
		}
	}
} else {
	window.onload = function () {
		var imgs = document.getElementsByTagName('img');
		
		var i;
		for(i=0;i<imgs.length;i++) {
			if(imgs[i].className == 'userimage') {
				imgs[i].onclick = function () { display(this.src) };
				if(imgs[i].width >= 512) {
					imgs[i].style.width = '512px';
					imgs[i].style.height = (512 / imgs[i].width * imgs[i].height).toString()+'px';
				}
			}
		}
		oldonload();
	}
}