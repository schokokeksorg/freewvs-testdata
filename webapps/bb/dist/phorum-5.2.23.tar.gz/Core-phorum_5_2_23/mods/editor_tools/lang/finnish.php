<?php
$PHORUM["DATA"]["LANG"]["mod_editor_tools"] = array(
    # Button descriptions.
    'help'         => 'Ohjeita',
);
?>
