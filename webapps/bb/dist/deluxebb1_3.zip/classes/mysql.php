<?php

class db {
	var $qn = 0;
	var $fontatr = 'size="2" face="Verdana, Arial"';
	var $pconnect = 0;
	var $debugmode = 0;

	function connect($host, $dbname, $dbusername, $dbpassword) {
  	##connecting to the db
  	if($this->pconnect!=0) {
	  		$link = @mysql_pconnect($host, $dbusername, $dbpassword);
		} else {
			$link = @mysql_connect($host, $dbusername, $dbpassword);
		}
  		if($link===FALSE) {
    		echo "<div align=\"center\"><font $this->fontatr><b>Error establishing a database connection!</b></font><ol><li><font $this->fontatr>Are you sure you entered the correct user/password?</font><li><font $this->fontatr>Are you sure that you have typed the correct hostname?</font><li><font $this->fontatr>Are you sure that the database server is running?</font></ol><font $this->fontatr>Please check your settings, if you are not able to get it working send an email to your host!<br />This is the error message returned by MySql: <em>".mysql_errno().": ".mysql_error()."</em></div>";
    		exit();
		}
		##accessing database
		$connection = @mysql_select_db($dbname, $link);
		if($connection===FALSE) {
	  	echo "<div align=\"center\"><font $this->fontatr><b>Error accessing the database: $dbname!</b></font><ol><li><font $this->fontatr>Are you sure you entered the correct database name and the database exists?</font><li><font $this->fontatr>Are you sure that you have permission to access this database?</ol><font $this->fontatr>Please check your settings, if you are not able to get it working send an email to your host!<br />This is the error message returned by MySql: <em>".mysql_errno().": ".mysql_error()."</em></div>";
			exit();
	  }
	  @mysql_query("SET NAMES 'utf8'");
	}

	function query($input) {		
	/*
		$write .= "$input\n";
		if($file = @fopen("debug.txt", "a")) {
			@fputs($file, $write);
			@fclose($file);
		}
		*/
		$output = @mysql_query($input);
		if(empty($output)) {
			if($this->debugmode==0) {
		    	echo "<div align=\"center\"><font $this->fontatr><b>Error querying the database!</b></font><ol><li><font $this->fontatr>Check the input for invalid characters...</font><li><font $this->fontatr>Inform the DeluxeBB team @ deluxebb.com/community</ol><br />";
			} else {
				echo "This is the query DeluxeBB tried to execute: $input<br />This is the error message returned by MySql: <em>".mysql_errno().": ".mysql_error()."</em></div>";
			}
		    exit();
    	}
		$this->qn++;
		return $output;
	}
	
	function unbuffered_query($input) {
		if($this->debugmode==0) {
			@mysql_unbuffered_query($input) or die('Invalid SQL, Contact us under www.deluxebb.com for a solution');
		} else {
			@mysql_unbuffered_query($input) or die('Invalid query: '.mysql_error().'<br />'.$input);
		}
		$this->qn++;
		return;
	}

	function fetch_array($input, $type=MYSQL_ASSOC) {
		$output = @mysql_fetch_array($input, $type);
		return $output;
	}
	
	function num_rows($query) {
		$output = @mysql_num_rows($query);
		if($output===FALSE) {
			$output=0;
		}
		return $output;
	}
	
	function result($query, $row=0) {
		$output = @mysql_result($query, $row);
		return $output;
	}
	
	function insert_id() {
		$output = @mysql_insert_id();
		return $output;
	}
	
	function affected_rows($resource) {
		$output = @mysql_affected_rows($resource);
		return $output;
	}
	
	function escape($var) {
		if(get_magic_quotes_gpc()===1) {
			##removing existing gpc magic quotes so we can use the better mysql functions for escaping
			$var = stripslashes($var);
		}
		
		if(@version_compare(phpversion(),"4.3.0")==1) {
			$var = mysql_real_escape_string($var);
		} else {
			$var = mysql_escape_string($var);
		}
		return $var;
	}
	
}
?>