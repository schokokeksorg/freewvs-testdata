<?php
define('TYPO3_MOD_PATH', 'sysext/opendocs/mod/');
$BACK_PATH='../../../';

$MLANG['default']['tabs_images']['tab'] = 'document.gif';
$MLANG['default']['ll_ref'] = 'LLL:EXT:opendocs/mod/locallang_mod.xml';

$MCONF['script'] = $BACK_PATH.'alt_doc.php';
$MCONF['access'] = 'group,user';
$MCONF['name'] = 'opendocs';

?>