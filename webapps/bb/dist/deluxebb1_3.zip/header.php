<?php

/************************************************
 * DeluxeBB 1.3                                 *
 * Copyright (C) 2005-2009 Frank Nissel         *
 * http://www.DeluxeBB.com	                    *
 * For license information, please read the     *
 * license file in the docs/ folder! 			      *
 ************************************************/


error_reporting(E_ALL&~E_NOTICE);
@ini_set("register_globals", 0);

if(file_exists('./install.php')) {
	echo 'Please remove install.php from your server, as it could be used by others to harm your forums..!';
	exit();
}

$versionname = '1.3';
$vchecksum = '0b0ec9f1cc28b3c19dc6c36dcd5af7cc';

require_once('settings/info.php');
require_once('classes/mysql.php');
$db = new db;
$db->connect($hostname, $dbname, $dbusername, $dbpassword);
require_once('./tools.php');

$ts = getmicrotime();
$footer=TRUE;

##Fix for superglobals
$list = array('_POST', '_GET', '_ENV', '_SERVER');
foreach($list as $element) {
    if(!empty($$element) && is_array($$element) ) {
        extract($$element, EXTR_SKIP);
    }
}

##security checks
if(stristr($templatefolder, 'http://') || stristr($templatefolder, 'https://') || stristr($templatefolder, 'ftp://') || stristr($templatefolder, 'ftps://') || stristr($templatefolder, '.ext') || basename(__FILE__)==basename($_SERVER['PHP_SELF'])) {
	exit();
}
$list = array('"', '\\', ',', '|##|', "'", '  ');
foreach($list as $element) {
	if(strstr($_COOKIE['membercookie'], $element)) {
		exit();	
	}
}

$getsettings = $db->query("SELECT * FROM ".$prefix."settings WHERE (name = 'settings')");
$settings = $db->fetch_array($getsettings);

if($settings['gzip']==1 || $settings['email_pro']==1) {
	ob_start();
}
ob_implicit_flush(0);

if(getenv('REMOTE_ADDR')) {
	$ip = getenv('REMOTE_ADDR');
} elseif(getenv('HTTP_X_FORWARDED_FOR')) {
	$ip = getenv('HTTP_X_FORWARDED_FOR');
} else {
	$ip = getenv('HTTP_CLIENT_IP');
}
$ips = @explode(".", $ip);
$host = @gethostbyaddr($ip);

$time = time();

##cookiedomain and cookieurl
if($fullpath && $fullpath!='') {
	$cookie_data = parse_url($fullpath);
	$cookie_data['host'] = str_replace('www.', '.', $cookie_data['host']);
	
	$cp = $cookie_data['path'];
	$cd = $cookie_data['host'];
	
	##if forum is installed on root
	if($cookie_data['path']=='/') {
		$cp = '';
	##if forum is installed on localhost
	} elseif($cookie_data['host']=='localhost') {
		$cd = '';
	}
}

##other cookie settings (secure)
$cs = 0;

if(usercheck()) {
	$_COOKIE['memberid'] = @intval($_COOKIE['memberid']);
	if(strlen($_COOKIE['memberpw'])>32) {
		$_COOKIE['memberpw'] = '';
	}
	$_COOKIE['memberpw'] = $db->escape($_COOKIE['memberpw']);
	$_COOKIE['membercookie'] = $db->escape($_COOKIE['membercookie']);
	
	$loadmember = $db->query("SELECT * FROM ".$prefix."users WHERE (uid='".$_COOKIE['memberid']."' && username='".$_COOKIE['membercookie']."' && pass='".$_COOKIE['memberpw']."')");
	$member = $db->fetch_array($loadmember);
	
	##validating cookie & password
	if($db->num_rows($loadmember)==0 || $member['valnum']!='') {
		$is_guest = true;
		#deleting cookies for security reasons!
		$time = time()-29030400;
		setcookie("membercookie", "", $time, $cp, $cd, $cs);
		setcookie("memberid", "", $time, $cp, $cd, $cs);
		setcookie("invisible", 0, $time, $cp, $cd, $cs);
	} else {
		$db->unbuffered_query("UPDATE ".$prefix."users SET lastip='$ip', lastactive='$time' WHERE (uid='".$_COOKIE['memberid']."')");
		if($settings['overrideoffset']==1) {
			$member['timeoffset'] = $settings['timeoffset'];
		}
	}
} else {
	$_COOKIE['memberid'] = @intval($_COOKIE['memberid']);
	$is_guest = true;
}

if($is_guest) {
	$member = array('uid' => 0,
	 				'username' => 'guest',
	 				'membercode' => 0,
	 				'customtitle' => $lang_guesttitle,
	 				'posts' => 0,
	 				'lastpost' => 0,
	 				'skin' => 'default',
	 				'language' => 'default',
	 				'joineddate' => $time,
	 				'timeoffset' => $settings['timeoffset'],
	 				'dateformat' => $settings['dateformat'],
	 				'timeformat' => $settings['timeformat'],
	 				'lastip' => $ip,
	 				'lastactive' => $time,
	 				'markposts' => 15
	 				);
}

$banned=0;
$getbannedppl = $db->query("SELECT * FROM ".$prefix."banned");
while($check = $db->fetch_array($getbannedppl)) {
	if($check['type'] == 'name' && $check['value']==$member['username'] && $member['username']!=$settings['headadmin']) {
		$banned++;
	} elseif($check['type'] == 'email' && $check['value'] == $member['email']) {
		$banned++;
	} elseif($check['type'] == 'ip') {
		$regip = explode(".", $check['value']);
		if(($regip['0'] == $ips['0'] || $regip['0'] == "*") && ($regip['1'] == $ips['1'] || $regip['1'] == "*") && ($regip['2'] == $ips['2'] || $regip['2'] == "*") && ($regip['3'] == $ips['3'] || $regip['3'] == "*")) {
			$banned++;
		}
	} elseif($check['type'] == 'host') {
		$reghost = explode("*", $check['value']);
		$reghost = @array_filter($reghost);
		$a = 0;
		foreach($reghost as $x=>$y) {
			if(stristr($host,current($reghost))) {
				$a++;
			}
			next($reghost);
		}

		if($a==sizeof($reghost)) {
			$banned++;
		}
	}
}

if($_COOKIE['membercookie']) {
	if($member['language']!='' && $member['language']!='default' && file_exists("lang/$member[language].php")) {
		$langfile = $member['language'];
	} else {
		$langfile = $settings['language'];
	}
} else {
	$langfile = $settings['language'];
}

require_once('lang/'.$langfile.'.php');

if(usercheck()) {
	if($member['skin']!='default' && $member['skin']!='') {
		$theskinname = $member['skin'];
	} else {
		$theskinname = $settings['skin'];
	}
} else {
	$theskinname = $settings['skin'];
}

$getskin = $db->query("SELECT * FROM ".$prefix."skins WHERE (skinname = '$theskinname')");
$theskin = $db->fetch_array($getskin);
extract($theskin);

if($settings['overridetime']) {
	if($settings['timeformat']==24) {
		$timecode = 'H:i';
	} else {
		$timecode = 'h:i A';
	}
} else {
	if($member['timeformat']==24) {
		$timecode = 'H:i';
	} else {
		$timecode = 'h:i A';
	}
}

if($member['dateformat']=='' || $settings['overridedate']) {
	$datecode = $settings['dateformat'];
} else {
	$datecode = $member['dateformat'];
}

if(usercheck() && $banned==0 && $settings['allowpm']!=0) {
	$count=0;
	$getpm = $db->query("SELECT hasread FROM ".$prefix."pm WHERE (whoto='".$_COOKIE['membercookie']."' && type='inbox')");
	while($pm = $db->fetch_array($getpm)) {
		if($pm['hasread'] == 'no') {
			$count++;
		}
	}
}

//fixing daylight savings
if(date("I")) {
	$member['timeoffset']++;
}

//set last visit
setcookie("lastvisita", $time, $time+29030400, $cp, $cd, $cs);

if($_COOKIE['lastvisita']) {
	$lvtime = $_COOKIE['lastvisita'];
} else {
	$lvtime = 0;
}

if(!$_COOKIE['lastvisitb']) {
	setcookie("lastvisitb", $lvtime, $time+($member['markposts']*60), $cp, $cd, $cs);
}

?>