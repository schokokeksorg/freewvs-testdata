<?php

  return $widget_config = array(
    'name' => language::translate('title_orders', 'Orders'),
    'file' => 'orders.inc.php',
    'priority' => 2,
  );
