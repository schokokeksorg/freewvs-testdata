<?php

/************************************************
 * DeluxeBB 1.3                                 *
 * Copyright (C) 2005-2009 Frank Nissel         *
 * http://www.DeluxeBB.com	                    *
 * For license information, please read the     *
 * license file in the docs/ folder! 			      *
 ************************************************/


$cssstyle = 'postmod.css';
require('./header.php');
$footer = TRUE;

$tid = @intval($tid);
$fid = @intval($fid);

$getinfo = $db->query("SELECT f.*,t.* FROM ".$prefix."forums f LEFT JOIN ".$prefix."threads t ON (f.fid=t.fid) WHERE (tid='$tid')");
$info = $db->fetch_array($getinfo);

$temptitle = $lang_modtopic;
$where = 'Moderating a thread: ' . addslashes($info['subject']);

if($info['password']!='') {
	if(!$_COOKIE['membercookie'] || $_COOKIE['membercookie']=='guest') {
		require('./header_html.php');
		bar($bar_seperator.'<a href="forums.php?fid='.$info['fid'].'">'.$info['name'].'</a>'.$bar_seperator.$bar_forum_restr);
		include($templatefolder.'/error_forum_restrictions.dtf');
    include('./footer.php');
    exit();
	}

	if($action == 'pwverify') {
		if($pw != $info['password']) {
			require('./header_html.php');
			bar($bar_seperator.'<a href="forums.php?fid='.$info['fid'].'">'.$info['name'].'</a>'.$bar_seperator.$bar_wrong_pw);
			message($lang_badpassword, $lang_badpasswordinfo, "index.php");
			quit();
		} else {
			setcookie("fpw$fid", $pw, time()+86400*7, $cp, $cd, $cs);
			redirect("topic.php?tid=$tid", 1);
			exit();
		}
	}
	
	if($_COOKIE['fpw'.$info['fid']]=='' || $info['password']!=$_COOKIE['fpw'.$info['fid']]) {
		require('./header_html.php');
		bar($bar_seperator.'<a href="forums.php?fid='.$info['fid'].'">'.$info['name'].'</a>'.$bar_seperator.$bar_pw_req);
		include($templatefolder.'/enterpw.dtf');
		quit();
	}
}

require('./header_html.php');

##access?
if(!access($member['username'], $member['membercode'], $info['viewstatus'], $info['poststatus'], '', $info['userlist'])) {
	bar($bar_seperator.'<a href="forums.php?fid='.$info['fid'].'">'.$info['name'].'</a>'.$bar_seperator.'<a href="topic.php?tid='.$info['tid'].'">'.$info['subject'].'</a>'.$bar_seperator.$lang_nomodperm);
	include($templatefolder.'/error_forum_restrictions.dtf');
  include('./footer.php');
  exit();
}
 
bar($bar_seperator.'<a href="forums.php?fid='.$info['fid'].'">'.$info['name'].'</a>'.$bar_seperator.'<a href="topic.php?tid='.$info['tid'].'">'.$info['subject'].'</a>'.$bar_seperator.$lang_modarea);

##mod?
if(modcheck($member['username'], $member['membercode'], $info['moderators'], 1) && isset($sub)) {
	$footer = FALSE;
	$getfid = $db->query("SELECT fid FROM ".$prefix."threads WHERE (tid='$tid')");
	$fid = $db->result($getfid, 0);
	if($sub == 'delete') {
		if($submit==$lang_delete) {
			$x = -1; //-1 instead of 0 to fix thread info is being counted
			##deleting thread info
			$db->unbuffered_query("DELETE FROM ".$prefix."threads WHERE (tid='$tid')");
			##updating user post count
			$getusers = $db->query("SELECT u.uid,p.pid FROM ".$prefix."posts p LEFT JOIN ".$prefix."users u ON (p.author=u.uid) WHERE (p.tid='$tid')");
			while($fix = $db->fetch_array($getusers)) {
				##updating user profile
				$db->unbuffered_query("UPDATE ".$prefix."users SET posts=posts-1 WHERE (uid='$fix[uid]')");
				$x++;
				##deleting attachments
				$query = $db->query("SELECT a.filename,p.postdate FROM ".$prefix."attachments a LEFT JOIN ".$prefix."posts p ON (a.pid=p.pid) WHERE (a.pid=p.pid && p.pid='$fix[pid]')");
				if($db->num_rows($query)!=0) {
					$theinfo = $db->fetch_array($query);
					$attachurl = $settings['attachdir'].utf8_decode($theinfo['filename']).'-'.$theinfo['postdate']. '.'.'ext';
					if(@unlink(@trim($attachurl)) || !file_exists($attachurl)) {
						$db->unbuffered_query("DELETE FROM ".$prefix."attachments WHERE (pid='$fix[pid]')");
					}
				}
			}
			##deleting posts
			$db->unbuffered_query("DELETE FROM ".$prefix."posts WHERE (tid='$tid')");
			$db->unbuffered_query("DELETE FROM ".$prefix."posts_archive WHERE (tid='$tid')");
			##deleting a possible redirection link
			$db->unbuffered_query("DELETE FROM ".$prefix."threads WHERE (moved='$tid')");
			##updating forum stats
			$getlp = $db->query("SELECT tid,subject,lastpostdate,lastpostby FROM ".$prefix."threads WHERE (fid='$info[fid]') ORDER BY lastpostdate DESC LIMIT 1");
			$lpinfo = $db->fetch_array($getlp);
			if(!$lpinfo['tid']) {
				$db->unbuffered_query("UPDATE ".$prefix."forums SET topics=0, replies=0, lastpost=NULL, lastpostby='0', lastpid='', lastpidtime='' WHERE (fid='$info[fid]')");
			} else {
			  if($lpinfo['lastpostby']=='guest') {
           $getlpuid = 0;
         } else {
         	$getlpuid = $db->query("SELECT uid FROM ".$prefix."users WHERE username='".$lpinfo['lastpostby']."'");
         }
				$db->unbuffered_query("UPDATE ".$prefix."forums SET topics=topics-1, replies=replies-".$x.", lastpost='".$db->escape($lpinfo['subject'])."', lastpostby='".$db->result($getlpuid)."', lastpid='$lpinfo[tid]', lastpidtime='$lpinfo[lastpostdate]' WHERE (fid='$info[fid]')");
			}
			
			##printing out a message
			message($lang_actioncomplete, $lang_forwardlastforumview, "forums.php?fid=$fid");
		} else {
			$action=$lang_modconfirmdel;
			$button=$lang_delete;
			include($templatefolder.'/mod_confirm.dtf');
		}
	}
	if($sub == 'pin') {
		if($submit==$lang_pintopic) {
			##update thread info
			$db->unbuffered_query("UPDATE ".$prefix."threads SET pinned='1' WHERE (tid='$tid')");
			message($lang_actioncomplete, $lang_forwardeditedthread, "topic.php?tid=$tid");
		} else {
			$action=$lang_modconfirmpin;
			$button=$lang_pintopic;
			include($templatefolder.'/mod_confirm.dtf');
		}
	}
	if($sub == 'unpin') {
		if($submit==$lang_unpintopic) {
			##update thread info
			$db->unbuffered_query("UPDATE ".$prefix."threads SET pinned='0' WHERE (tid='$tid')");
			message($lang_actioncomplete, $lang_forwardeditedthread, "topic.php?tid=$tid");
		} else {
			$action=$lang_modconfirmunpin;
			$button=$lang_unpintopic;
			include($templatefolder.'/mod_confirm.dtf');
		}
	}
	if($sub == 'close') {
		if($submit==$lang_closetopic) {
			##update thread info
			$db->unbuffered_query("UPDATE ".$prefix."threads SET closed='1' WHERE (tid='$tid')");
			message($lang_actioncomplete, $lang_forwardeditedthread, "topic.php?tid=$tid");
		} else {
			$action=$lang_modconfirmclose;
			$button=$lang_closetopic;
			include($templatefolder.'/mod_confirm.dtf');
		}
	}
	if($sub == 'open') {
		if($submit==$lang_opentopic) {
			##update thread info
			$db->unbuffered_query("UPDATE ".$prefix."threads SET closed='0' WHERE (tid='$tid')");
			message($lang_actioncomplete, $lang_forwardeditedthread, "topic.php?tid=$tid");
		} else {
			$action=$lang_modconfirmopen;
			$button=$lang_opentopic;
			include($templatefolder.'/mod_confirm.dtf');
		}
	}
	if($sub == 'move') {
		if($submit==$lang_move) {
			##moving thread to new forum
			$db->unbuffered_query("UPDATE ".$prefix."threads SET fid='$mfid' WHERE (tid='$tid')");
		
    	##deleting older redirects
			$db->unbuffered_query("DELETE FROM ".$prefix."threads WHERE moved='$tid'");
				
			if($redirect) {
				##getting info of thread
				$query = $db->query("SELECT * FROM ".$prefix."threads WHERE (tid='$tid')");
				$redinfo = $db->fetch_array($query);
				
				##leaving redirection
				$db->query("INSERT INTO ".$prefix."threads VALUES (NULL, '$fid', '$redinfo[author]', '$redinfo[subject]', '$redinfo[picon]', '$redinfo[views]', '$redinfo[replies]', '$redinfo[closed]', '', '$tid', '$redinfo[lastpostby]', '$redinfo[lastpostdate]')");
			}
			
			##updating forum counts and laltpost info
			$fttquery = $db->query("SELECT fid FROM ".$prefix."forums WHERE (fid='$fid' || fid='$mfid')");
			while($fttx = $db->fetch_array($fttquery)) {
				##counting posts
				$replies = 0;
				$threads = 0;
				$pcquery = $db->query("SELECT tid FROM ".$prefix."threads WHERE (fid='$fttx[fid]' && moved='0')");
				while($pc = $db->fetch_array($pcquery)) {
					$pq = $db->query("SELECT COUNT(pid) FROM ".$prefix."posts WHERE (tid='$pc[tid]')");
					$replyupdate = $db->result($pq)-1;
					$replies += $replyupdate;
					##counting threads
					$threads++;					
					##updating thread info
					$db->unbuffered_query("UPDATE ".$prefix."threads SET replies='".$replyupdate."' WHERE (tid='$pc[tid]')");
				}
				
				##updating forum stats
				$getlp = $db->query("SELECT tid,subject,lastpostdate,lastpostby FROM ".$prefix."threads WHERE (fid='$fttx[fid]' && moved=0) ORDER BY lastpostdate DESC LIMIT 1");
				$lpinfo = $db->fetch_array($getlp);
				if(!$lpinfo['tid']) {
					$db->unbuffered_query("UPDATE ".$prefix."forums SET topics=0, replies=0, lastpost='', lastpostby='0', lastpid='', lastpidtime='' WHERE (fid='$fttx[fid]')");
				} else {
  			  if($lpinfo['lastpostby']=='guest') {
             $getlpuid = 0;
           } else {
           	$getlpuid = $db->query("SELECT uid FROM ".$prefix."users WHERE username='".$lpinfo['lastpostby']."'");
           }
					$db->unbuffered_query("UPDATE ".$prefix."forums SET topics='$threads', replies='$replies', lastpost='$lpinfo[subject]', lastpostby='".$db->result($getlpuid)."', lastpid='$lpinfo[tid]', lastpidtime='$lpinfo[lastpostdate]' WHERE (fid='$fttx[fid]')");
				}
			}
			message($lang_actioncomplete, $lang_forwardeditedthread, "topic.php?tid=$tid");
		} else {
			$getcat = $db->query("SELECT name,cid FROM ".$prefix."categories ORDER BY ordered,cid ASC");
			$flist = "<option value=\"\">------------------------------</option>\n";
			while($cat = $db->fetch_array($getcat)) {
				$flist .= "<option value=\"\">$cat[name]</option>\n";
				$getf = $db->query("SELECT fid,name,viewstatus,userlist FROM ".$prefix."forums WHERE (cid='$cat[cid]') ORDER BY ordered,fid ASC");
				while($f = $db->fetch_array($getf)) {
					if(access($member['username'], $member['membercode'], $f['viewstatus'], '', '',  $f['userlist'])) {
						$flist .= "<option value=\"$f[fid]\">---".$f['name']."</option>\n";
					}
				}
			}
			$flist .= "<option value=\"\">------------------------------</option>\n";
			$button=$lang_move;
			$action=$lang_modconfirmmove;
			include($templatefolder.'/mod_move.dtf');
		}
	}	
} else {
	bar($bar_seperator.'<a href="forums.php?fid='.$info['fid'].'">'.$info['name'].'</a>'.$bar_seperator.'<a href="topic.php?tid='.$info['tid'].'">'.$info['subject'].'</a>'.$bar_seperator.$lang_nomodperm);
	include($templatefolder.'/error_forum_restrictions.dtf');
  include('./footer.php');
  exit();
}

include('./footer.php');

?>