<?php
/*
 * @deprecated since 6.0, the classname t3lib_transl8tools and this file is obsolete
 * and will be removed with 6.2. The class was renamed and is now located at:
 * typo3/sysext/backend/Classes/Configuration/TranslationConfigurationProvider.php
 */
require_once \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath('backend') . 'Classes/Configuration/TranslationConfigurationProvider.php';
?>