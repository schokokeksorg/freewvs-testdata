<?php

/************************************************
 * DeluxeBB 1.3                                 *
 * Copyright (C) 2005-2009 Frank Nissel         *
 * http://www.DeluxeBB.com	                    *
 * For license information, please read the     *
 * license file in the docs/ folder! 			      *
 ************************************************/


$maintenance = 1;
$cssstyle = 'admincp.css';
require('./header.php');

$temptitle = $lang_admincplong;
$where = 'Administrator Control Panel';

if(stristr($REQUEST_URI, 'logs=')) {
	exit();
}

if($member['membercode'] < 4) {
	require('./header_html.php');
	bar($bar_identerror);
	message($lang_wronguserorpass, $lang_wronguserorpassinfo, 'index.php');
	quit();
}

if($settings['cplog']==1 || $logs==1) {
	$time = time();
	$dir = $settings['logpath'];
	@chmod($dir.'/cp.php', 0777);
	$REQUEST_URI = html($REQUEST_URI);
	$string = $_COOKIE['membercookie']."|##|$ip|##|$time|##|$REQUEST_URI\n";
	$filehandle=@fopen($dir.'/cp.php',"a");
	if(!$filehandle) {
		message($lang_wrongfilepermission, $lang_plschmod);
	}
	@flock($filehandle, 2);
	@fwrite($filehandle, $string);
	@fclose($filehandle);
}

if(!isset($sub)) {
	require('./header_html.php');
	bar($bar_admincp);
	include($templatefolder.'/admincp/index.dtf');
}

if($sub == 'profile') {
	require('./header_html.php');
	bar($bar_search_member);
	if(!checkrestrictions('editmember')) {
		message($lang_accessdenied, $lang_noaccessmsg);
	}
	if($submit==$lang_search || $search) {
		$thename = html($thename);
		
		##doing multipaging
		$getnum = $db->query("SELECT uid FROM ".$prefix."users WHERE (username LIKE '%$thename%' && username!='guest' && username!='invisible')");
		$totalrows = $db->num_rows($getnum);
		$pageinfo = multipage($totalrows, $page, $settings['ompp'], 'admincp.php?sub=profile', "&amp;thename=$thename&amp;search=1");

		$loadmember = $db->query("SELECT * FROM ".$prefix."users WHERE (username LIKE '%$thename%' && username!='guest' && username!='invisible') ORDER BY username LIMIT ".$pageinfo[0].",".$pageinfo[1]);
		if($totalrows==0) {
			message($lang_memnotfound, $lang_plstryagain,'','','strong','');
		} elseif($totalrows==1) {
			$getmembername = $db->fetch_array($loadmember);
			$name = $getmembername['username'];
			message($lang_foundmember, $lang_forwardmes, "admincp.php?sub=editmember&uid=$getmembername[uid]", 1);
		} elseif($totalrows>1) {
			if(empty($thename)) {
				message($lang_missingfields, $lang_missingfieldsinfo);
				quit();
			}
			include($templatefolder.'/admincp/find_header.dtf');
			while($memberoutput = $db->fetch_array($loadmember)) {
	 			if($memberoutput['username']!='guest' && $memberoutput['username']!='invisible' && !empty($memberoutput['joineddate'])) {
					$joineddate = gmdate($datecode, $memberoutput['joineddate'] + ($member['timeoffset'] * 3600));

					if($memberoutput['membercode']==1) {
						$status = $lang_member;
					} elseif($memberoutput['membercode']==2) {
						$status = $lang_moderator;
					} elseif($memberoutput['membercode']==3) {
						$status = $lang_supermoderator;
					} elseif($memberoutput['membercode']==4) {
						$status = $lang_administrator;
					} elseif($memberoutput['membercode']==5) {
						$status = $lang_headadministrator;
					}
					include($templatefolder.'/admincp/find_fields.dtf');
				}
			}
			include($templatefolder.'/admincp/find_footer.dtf');
		}
	} elseif($submit==$lang_listusers || $page) {
		if($select == "username") {
			$order = "username";
			$orderwhat = "username";
		} elseif($select == "status") {
			$order = "membercode";
			$orderwhat = "status";
		} elseif($select == "registered") {
			$order = "joineddate";
			$orderwhat = "date of registration";
		} elseif($select == "posts") {
			$order = "posts";
			$orderwhat = "number of posts";
		}
		
		if($select2 == "asc") {
			$sort = "ASC";
			$sortwhat = "Ascending";
		} elseif($select2 == "desc") {
			$sort = "DESC";
			$sortwhat = "Descending";
		}
		
		if($select3 == "all") {
			$filter = "membercode!=0";
			$who = "all members";
		} elseif($select3 == "ad") {
			$filter = "membercode>=4";
			$who = "Administrators";
		} elseif($select3 == "admo") {
			$filter = "membercode>=2";
			$who = "Administrators / Moderators";
		} elseif($select3 == "mo") {
			$filter = "(membercode=2 || membercode=3)";
			$who = "Moderators";
		} elseif($select3 == "me") {
			$filter = "membercode=1";
			$who = "Members";
		}

		$getnum = $db->query("SELECT username FROM ".$prefix."users WHERE (".$filter.")");
		$totalrows = $db->num_rows($getnum);
		$pageinfo = multipage($totalrows, $page, $settings['ompp'], 'admincp.php?sub=profile', "&amp;select=$select&amp;select2=$select2&amp;select3=$select3");
		
		include($templatefolder.'/admincp/list_header.dtf');
		$getallmembers = $db->query("SELECT * FROM ".$prefix."users WHERE (".$filter.") ORDER BY ".$order." ".$sort." LIMIT ".$pageinfo[0].",".$pageinfo[1]);
	 	while ($allmember = $db->fetch_array($getallmembers)) {
	 		if($allmember['username']!='guest' && $allmember['username']!='invisible') {
			 	if(!empty($allmember['joineddate'])) {
			 		$joineddate = gmdate($datecode, $allmember['joineddate'] + ($member['timeoffset'] * 3600));
		 		}
				
		 		if($allmember['membercode']==1) {
					$status = $lang_member;
				} elseif($allmember['membercode']==2) {
					$status = $lang_moderator;
				} elseif($allmember['membercode']==3) {
					$status = $lang_supermoderator;
				} elseif($allmember['membercode']==4) {
					$status = $lang_administrator;
				} elseif($allmember['membercode']==5) {
					$status = $lang_headadministrator;
				}
				include($templatefolder.'/admincp/list_fields.dtf');
			}
		}
		include($templatefolder.'/admincp/list_footer.dtf');
	} elseif($submit==$lang_delete) {
		$query = $db->query("SELECT uid FROM ".$prefix."users");
		while($users = $db->fetch_array($query)) {
			$delete = "delete$users[uid]";
			$delete = "${$delete}";
			if($delete!='') {
				$delete = @intval($delete);
				$db->unbuffered_query("DELETE FROM ".$prefix."users WHERE (uid='$delete' && username!='invisible' && username!='guest' && membercode<4)");
				$db->unbuffered_query("DELETE FROM ".$prefix."pm WHERE (whoto='$memberinfo[username]')");
			}
		}

		##Fixing newest member
		$getlastjoined = $db->query("SELECT username FROM ".$prefix."users ORDER BY joineddate DESC LIMIT 1");
		$lastjoined = $db->result($getlastjoined);
		$db->unbuffered_query("UPDATE ".$prefix."boardstats SET whenof='$lastjoined', whatof=whatof-1 WHERE nameof='members'");
		
		message($lang_successfullyeditm, $lang_forwardadmincp, "admincp.php");
	} else {
		include($templatefolder.'/admincp/find.dtf');
	}
}

if($sub == 'editmember' && isset($uid)) {
	$getinfo = $db->query("SELECT * FROM ".$prefix."users WHERE (uid = '$uid')");
	$memberinfo = $db->fetch_array($getinfo);
	
	require('./header_html.php');
	bar($bar_editing_user.' '.$memberinfo['username']);

	if(!checkrestrictions('editmember')) {
		message($lang_accessdenied, $lang_noaccessmsg);
	}
	if($submit==$lang_update) {
		if(!isemail($email)) {
			message($lang_erroremail, $lang_erroremailinfo);
			quit();
		}
		
		if(($old_code==5 && $status!=5) || ($old_code!=5 && $status==5)) {
			message($lang_noeditpermission, $lang_ucancontactadmin);
			quit();
		}
		if($box1=='checked') {
			##protecting headadmin from being deleted
			if($old_code!=5) {
				$db->unbuffered_query("DELETE FROM ".$prefix."users WHERE (uid='$uid')");
				$db->unbuffered_query("DELETE FROM ".$prefix."pm WHERE (whoto='$memberinfo[username]')");
			}
			
			##Fixing newest member
			$getlastjoined = $db->query("SELECT username FROM ".$prefix."users ORDER BY joineddate DESC LIMIT 1");
			$lastjoined = $db->result($getlastjoined);
			$db->unbuffered_query("UPDATE ".$prefix."boardstats SET whenof='$lastjoined', whatof=whatof-1 WHERE nameof='members'");
		}
		if($box2=='checked') {
			##protecting headadmins posts from being deleted
			if($old_code!=5) {
				$query = $db->query("SELECT pid,tid,postdate FROM ".$prefix."posts WHERE (author='$uid')");
				while($del = $db->fetch_array($query)) {
					$db->unbuffered_query("DELETE FROM ".$prefix."posts WHERE (pid='$del[pid]')");
					$db->unbuffered_query("DELETE FROM ".$prefix."posts_archive WHERE (pid='$del[pid]')");
					
          ##deleting attachments
  				$query = $db->query("SELECT filename FROM ".$prefix."attachments WHERE (pid='$del[pid]')");
  				if($db->num_rows($query)!=0) {
  					$theinfo = $db->fetch_array($query);
  					$attachurl = $settings['attachdir'].utf8_decode($theinfo['filename']).'-'.$del['postdate']. '.'.'ext';
  					if(@unlink(@trim($attachurl)) || !file_exists($attachurl)) {
  						$db->unbuffered_query("DELETE FROM ".$prefix."attachments WHERE (pid='$del[pid]')");
  					}
  				}
					
					$threadlp = $db->query("SELECT u.username,p.author FROM ".$prefix."posts p, ".$prefix."users u WHERE (p.tid='".$del['tid']."') ORDER BY p.postdate DESC LIMIT 1");
					$db->unbuffered_query("UPDATE ".$prefix."threads SET lastpostby='".$db->result($threadlp)."' WHERE tid='".$del['tid']."'");					
				}
				
				##If thread is emtpy now we need to fix this!
				##Wouldnt make sense deleting whole threads of this user
				$fixquery = $db->query("SELECT tid FROM ".$prefix."threads WHERE author='".$uid."'");
				while($fixit = $db->fetch_array($fixquery)) {
					$pquery = $db->query("SELECT pid FROM ".$prefix."posts WHERE (tid='".$fixit['tid']."')");
					if($db->num_rows($pquery)==0) {
						$db->unbuffered_query("DELETE FROM ".$prefix."threads WHERE (tid='".$fixit['tid']."')");
					}
				}
				
				
				
				$fttquery = $db->query("SELECT fid FROM ".$prefix."forums");
				while($fttx = $db->fetch_array($fttquery)) {
					##counting posts
					$replies = 0;
					$threads = 0;
					$pcquery = $db->query("SELECT tid FROM ".$prefix."threads WHERE (fid='$fttx[fid]' && moved='0')");
					while($pc = $db->fetch_array($pcquery)) {
						$pq = $db->query("SELECT COUNT(pid) FROM ".$prefix."posts WHERE (tid='$pc[tid]')");
						$replyupdate = $db->result($pq)-1;
						$replies += $replyupdate;
						##counting threads
						$threads++;					
						##updating thread info
						$db->unbuffered_query("UPDATE ".$prefix."threads SET replies='".$replyupdate."' WHERE (tid='$pc[tid]')");
					}
					
					##updating forum stats
					$getlp = $db->query("SELECT tid,subject,lastpostdate,lastpostby FROM ".$prefix."threads WHERE (fid='$fttx[fid]') ORDER BY lastpostdate DESC LIMIT 1");
					$lpinfo = $db->fetch_array($getlp);
					if(!$lpinfo['tid']) {
						$db->unbuffered_query("UPDATE ".$prefix."forums SET topics=0, replies=0, lastpost='', lastpostby='0', lastpid='', lastpidtime='' WHERE (fid='$fttx[fid]')");
					} else {
						$getlpuid = $db->query("SELECT uid FROM ".$prefix."users WHERE username='".$lpinfo['lastpostby']."'");
						$db->unbuffered_query("UPDATE ".$prefix."forums SET topics='$threads', replies='$replies', lastpost='$lpinfo[subject]', lastpostby='".$db->result($getlpuid)."', lastpid='$lpinfo[tid]', lastpidtime='$lpinfo[lastpostdate]' WHERE (fid='$fttx[fid]')");
					}
					
				}
			}
		}
		
		$customtitle = $db->escape($customtitle);
				
		$sig = $db->escape(trim($post));
		if($settings['sightml']==0) {
			$sig = html($sig);
		}
		
		if($box1!='checked' && $box2!='checked') {
			$db->unbuffered_query("UPDATE ".$prefix."users SET membercode='$status', customtitle='$customtitle', posts='$posts', avatar='$avatar', sig='$sig', msn='$msn', aim='$aim', icq='$icq', yim='$yim', location='$location', email='$email', site='$site', skin='$skinx', language='$languagex', hideemail='$xhideemail', timeoffset='$xthetimeoffset', timeformat='$xthetimeformat', dateformat='$xthedateformat', pmnotify='$pmnotify', invisible='$invisiblebrowse', markposts='$markposts', valnum='$valnum' WHERE (uid='$uid')");
			##Changing password
			if($password!='') {
				$db->unbuffered_query("UPDATE ".$prefix."users SET pass='".md5($password)."' WHERE (uid='$uid')");
			}
			##Changing username
			if($username!='') {
				##Security checks
				if($username == 'guest' || $username == 'invisible') {
					message($lang_namenotallowed, $lang_chooseanother);
				}
				##Checking for invalid chars
				$list = array('"', '\\', ', ', '|##|', "'");
				foreach($list as $element) {
					if(strstr($username, $element)) {
						message("$lang_invalidchars $element", $lang_chooseanother);
					}
				}
				##Checking if username is free
				$check = $db->query("SELECT username FROM ".$prefix."users WHERE (username='$username')");
				if($db->num_rows($check) > 0) {
					message($lang_nametaken, $lang_nametakeninfo);
				}
				##Rewriting database
				$db->unbuffered_query("UPDATE ".$prefix."pm SET whoto='$username' WHERE (whoto='$memberinfo[username]')");
				$db->unbuffered_query("UPDATE ".$prefix."pm SET `from`='$username' WHERE (`from`='$memberinfo[username]')");
				$db->unbuffered_query("UPDATE ".$prefix."restrictions SET `name`='$username' WHERE (`name`='$memberinfo[username]')");
				$db->unbuffered_query("UPDATE ".$prefix."settings SET `headadmin`='$username' WHERE (`headadmin`='$memberinfo[username]')");
				$db->unbuffered_query("UPDATE ".$prefix."threads SET `lastpostby`='$username' WHERE (`lastpostby`='$memberinfo[username]')");
				$db->unbuffered_query("UPDATE ".$prefix."users SET `username`='$username' WHERE (`uid`='$memberinfo[uid]')");
			}
		}
		message($lang_successfullyeditm, $lang_forwardadmincp, "admincp.php");
	} else {
		if(date("I")) {
			$gmdateoffset = 3600;
		}
		$gmtime = gmdate($timecode, $time + $gmdateoffset);
		$gmtimemsg = "$lang_curgmttime $gmtime";
		if($memberinfo['timeformat'] == "24") {
			$check24 = "checked=\"checked\"";
		} else {
			$check12 = "checked=\"checked\"";
		}
		
		$dateformat = array('d.m.y', #24.12.00
						   'd.m.Y', #24.12.2000
						   'd/m/y', #24/12/00
						   'd/m/Y', #24/12/2000
						   'm/d/y', #12/24/00
						   'm/d/Y', #12/24/2000
						   'd-m-y', #24-12-00
						   'd-m-Y', #24-12-2000
						   'm-d-y', #12-24-00
						   'm-d-Y', #12-24-2000
						   'Y-m-d', #2000-12-24
						   'j M Y', #24 Dec 2000
						   'j F Y', #24 December 2000
						   'j F Y l', #24 December 2000 Sunday
						   'M jS, Y', #Dec 24th, 2000
						   'F j, Y', #December 24, 2000
						   'F jS Y', #December 24th 2000
						   'D M jS, Y', #Sun Dec 24th, 2000
						   'D M j', #Sun Dec 24
						   'l F jS, Y', #Sunday December 24th, 2000
						   'l M jS, Y' #Sunday Dec 24th, 2000
						   );
	
		foreach($dateformat as $id => $code) {
			$selected = '';
			if($code == $memberinfo['dateformat']) {
				$selected = ' selected="selected"';
			}
			$dateformatlist .= "<option value=\"$code\"$selected>".gmdate($code, 977619600)."</option>\n";
		}
		
		if($settings['userranks']!=0) {
			##caching ranks
			prepareranks();
			
			$checktitle = '';
			switch ($memberinfo['membercode']) {
				case(2): $checktitle = "Moderator"; break;
				case(3): $checktitle = "Super Moderator"; break;
				case(4): $checktitle = "Administrator"; break;
				case(5): $checktitle = "Head Admin"; break;
			}
		
			if($checktitle!='') {
				$rankinfo = explode(",", $specialrank[$checktitle]);
			} else {
				foreach ($userrank as $key => $rinfo) {
					if($memberinfo['posts'] >= $key) {
						$rankinfo = explode(",", $rinfo);
					}
				}
			}
		}
		
		if($memberinfo['membercode']==1) {
			$status = $lang_member;
		} elseif($memberinfo['membercode']==2) {
			$status = $lang_moderator;
		} elseif($memberinfo['membercode']==3) {
			$status = $lang_supermoderator;
		} elseif($memberinfo['membercode']==4) {
			$status = $lang_administrator;
		} elseif($memberinfo['membercode']==5) {
			$status = $lang_headadministrator;
		}
		
		//fixing daylight savings
		if(date("I")) {
			$member['timeoffset']--;
		}
		
		/* retrieving languages */
		$dir = opendir("lang");
		while ($langfile = readdir($dir)) {
			if(is_file("lang/$langfile")) {
				$langfile = str_replace(".php", "", $langfile);
				if($langfile == "memberinfo[language]") {
					$languagelist .= "<option value=\"$langfile\" selected=\"selected\">$langfile</option>\n";
				} else {
					$languagelist .= "<option value=\"$langfile\">$langfile</option>\n";
				}
			}
		}
		
		/* getting all skins */
		$query = $db->query("SELECT skinname FROM ".$prefix."skins");
		while($skininfo = $db->fetch_array($query)) {
			if($skininfo['skinname'] == $memberinfo['skin']) {
				$skinlist .= "<option value=\"$skininfo[skinname]\" selected=\"selected\">$skininfo[skinname]</option>\n";
			} else {
				$skinlist .= "<option value=\"$skininfo[skinname]\">$skininfo[skinname]</option>\n";
			}
		}
		
		/* formatting lastpost */
		if($memberinfo['lastpost']!=0) {
			$date = gmdate($datecode, $memberinfo['lastpost'] + ($member['timeoffset'] * 3600));
			$time = gmdate($timecode, $memberinfo['lastpost'] + ($member['timeoffset'] * 3600));
			$lastpost = "$date $lang_at $time";
		} else {
			$lastpost = "<em>$lang_haventposted</em>";
		}
		
		/* fixing signature */
		$memberinfo['sig'] = addslashes($memberinfo['sig']);
		
		/* doing stats */
		$query = $db->query("SELECT COUNT(tid) AS topics, COUNT(pid) AS replies FROM ".$prefix."posts WHERE (author='$memberinfo[uid]')");
		$sum = $db->fetch_array($query);
		
		$allposts = $sum['topics']+$sum['replies'];
		
		//joineddate
		$date = gmdate($datecode, $memberinfo['joineddate'] + ($member['timeoffset'] * 3600));
		$time = gmdate($timecode, $memberinfo['joineddate'] + ($member['timeoffset'] * 3600));
		$joineddate = "$date $lang_at $time";
		
		//lastactive
		$date = gmdate($datecode, $memberinfo['lastactive'] + ($member['timeoffset'] * 3600));
		$time = gmdate($timecode, $memberinfo['lastactive'] + ($member['timeoffset'] * 3600));
		$lastactive = "$date $lang_at $time";
		
		//posts per day
		$ppd = $allposts / ((time() - $memberinfo['joineddate']) / 86400);
		$ppd = number_format($ppd, 2);
		
		//% of total posts
		if($allposts!=0) {
			$percentoftotal = $memberinfo['posts'] / $allposts * 100;
			$percentoftotal = number_format($percentoftotal, 2);
		} else {
			$percentoftotal = 0;
		}
		
		include($templatefolder.'/admincp/profile.dtf');
	}
}

if($sub == 'structure') {
	require('./header_html.php');
	bar($bar_forum_structure);
	if(!checkrestrictions('editforum')) {
		message($lang_accessdenied, $lang_noaccessmsg);
	}
	if(!isset($submit)) {
		include($templatefolder.'/admincp/category_header.dtf');
		$getcat = $db->query("SELECT * FROM ".$prefix."categories ORDER BY ordered");
		while($cat = $db->fetch_array($getcat)) {
		  $cat['name']=html($cat['name']);
			$query = $db->query("SELECT SUM(topics) AS topicsum, SUM(replies) AS replysum FROM ".$prefix."forums WHERE (cid='$cat[cid]') GROUP BY cid");
			$num = $db->fetch_array($query);
			include($templatefolder.'/admincp/category.dtf');
			$getforum = $db->query("SELECT fid,cid,name,ordered,topics,replies FROM ".$prefix."forums WHERE (cid='$cat[cid]') ORDER BY ordered");
			while($forum = $db->fetch_array($getforum)) {
			  $forum['name'] = html($forum['name']);
				include($templatefolder.'/admincp/forum.dtf');
			}
		}
		include($templatefolder.'/admincp/category_footer.dtf');
	} else {
		//cat modifications
		for($x=0;$x<sizeof($delcat);$x++) {
			$getthreads = $db->query("SELECT fid FROM ".$prefix."forums WHERE (cid='$delcat[$x]')");
			while($del = $db->fetch_array($getthreads)) {
				$getthreads = $db->query("SELECT tid FROM ".$prefix."threads WHERE (fid='$del[fid]')");
				while($fix = $db->fetch_array($getthreads)) {
					$db->unbuffered_query("DELETE FROM ".$prefix."threads WHERE (tid='$fix[tid]')");
					//del attachments
					$query = $db->query("SELECT a.filename,p.postdate,p.pid FROM ".$prefix."attachments a LEFT JOIN ".$prefix."posts p ON (a.pid=p.pid) LEFT JOIN ".$prefix."users u ON (p.author=u.uid) WHERE (a.pid=p.pid && p.tid='$fix[tid]')");
					while($theinfo = $db->fetch_array($query)) {
            $attachurl = $settings['attachdir'].utf8_decode($theinfo['filename']).'-'.$theinfo['postdate']. '.'.'ext';
            if(@unlink(@trim($attachurl)) || !file_exists($attachurl)) {
              $db->unbuffered_query("DELETE FROM ".$prefix."attachments WHERE (pid='$theinfo[pid]')");
            }
					}
          $db->unbuffered_query("DELETE FROM ".$prefix."posts WHERE (tid='$fix[tid]')");
          $db->unbuffered_query("DELETE FROM ".$prefix."posts_archive WHERE (tid='$fix[tid]')");
				}
			}
			$db->unbuffered_query("DELETE FROM ".$prefix."forums WHERE (cid='$delcat[$x]')");
			$db->unbuffered_query("DELETE FROM ".$prefix."categories WHERE (cid='$delcat[$x]')");
		}
		$query = $db->query("SELECT cid FROM ".$prefix."categories");
		while($cat = $db->fetch_array($query)) {
			$catname = "catname$cat[cid]";
			$catname = "${$catname}";
			$catorder = "catorder$cat[cid]";
			$catorder = "${$catorder}";
		
			if($catname!='') {
				$catname = $db->escape($catname);
				$db->unbuffered_query("UPDATE ".$prefix."categories SET name='$catname', ordered='$catorder' WHERE (cid='$cat[cid]')");
			}
		}
		
		//forum modifications
		for($x=0;$x<sizeof($delforum);$x++) {
			$getthreads = $db->query("SELECT tid FROM ".$prefix."threads WHERE (fid='$delforum[$x]')");
			while($fix = $db->fetch_array($getthreads)) {
				$db->unbuffered_query("DELETE FROM ".$prefix."threads WHERE (tid='$fix[tid]')");
				
				//del attachments
				$query = $db->query("SELECT a.filename,p.postdate,p.pid FROM ".$prefix."attachments a LEFT JOIN ".$prefix."posts p ON (a.pid=p.pid) LEFT JOIN ".$prefix."users u ON (p.author=u.uid) WHERE (a.pid=p.pid && p.tid='$fix[tid]')");
				while($theinfo = $db->fetch_array($query)) {
           $attachurl = $settings['attachdir'].utf8_decode($theinfo['filename']).'-'.$theinfo['postdate']. '.'.'ext';
           if(@unlink(@trim($attachurl)) || !file_exists($attachurl)) {
             $db->unbuffered_query("DELETE FROM ".$prefix."attachments WHERE (pid='$theinfo[pid]')");
           }
				}
			
				$db->unbuffered_query("DELETE FROM ".$prefix."posts WHERE (tid='$fix[tid]')");
				$db->unbuffered_query("DELETE FROM ".$prefix."posts_archive WHERE (tid='$fix[tid]')");
			}
			$db->unbuffered_query("DELETE FROM ".$prefix."forums WHERE (fid='$delforum[$x]')");
		}
		$query = $db->query("SELECT fid FROM ".$prefix."forums");
		while($forum = $db->fetch_array($query)) {
			$forumname = "forumname$forum[fid]";
			$forumname = "${$forumname}";
			$forumorder = "forumorder$forum[fid]";
			$forumorder = "${$forumorder}";
			$catlist = "catlist$forum[fid]";
			$catlist = "${$catlist}";
		
			if($forumname!='') {
				$forumname = $db->escape($forumname);
				$db->unbuffered_query("UPDATE ".$prefix."forums SET name='$forumname', ordered='$forumorder', cid='$catlist' WHERE (fid='$forum[fid]')");
			}
		}
		
		//new cats/forums
		if($newcatname!=$lang_newcat && value_exists($newcatname)) {
			$newcatname = $db->escape($newcatname);
			if($newcatorder=='') {
				$getnum = $db->query("SELECT MAX(ordered) AS max FROM ".$prefix."categories");
				$newcatorder = $db->result($getnum,0)+1;
			}
			$db->unbuffered_query("INSERT INTO ".$prefix."categories VALUES (NULL, '$newcatorder', '$newcatname')");
		}		
		if($newforumname!=$lang_newforum && value_exists($newforumname)) {
			$newcatname = $db->escape($newcatname);
			$newforumname = $db->escape($newforumname);
			if($newforumorder=='') {
				$getnum = $db->query("SELECT MAX(ordered) FROM ".$prefix."forums WHERE (cid='$newcat')");
				$newforumorder = $db->result($getnum,0)+1;
			}
			$db->unbuffered_query("INSERT INTO ".$prefix."forums VALUES ('$newforumorder', '$newcat', '$newforumname', '', '0', '0', 'all', 'all', 'all', NULL, '', NULL, '', NULL, '', '', '', '')");
		}
		message($lang_successfullystructure, $lang_forwardstructure, "admincp.php?sub=structure");
		
	}
}

if($sub == 'editforum') {
	require('./header_html.php');
	bar($bar_editing_structure);

	if(!checkrestrictions('editforum')) {
		message($lang_accessdenied, $lang_noaccessmsg);
	}
	if($submit==$lang_update) {
		if($fname == '' || $category == '' || $viewstatus == '' || $poststatus == '') {
			message($lang_missingfields, $lang_missingfieldsinfo);
		} else {
			$mod = @explode(", ", $moderators);
			for($x=0;$x<sizeof($mod);$x++) {
				$query = $db->query("SELECT membercode FROM ".$prefix."users WHERE (username='$mod[$x]')");
				$check = $db->fetch_array($query);
				if($check['membercode']==1) {
					$db->unbuffered_query("UPDATE ".$prefix."users SET membercode=2 WHERE (username='$mod[$x]')");
				}
			}
			if($delete==1) {
				$db->unbuffered_query("DELETE FROM ".$prefix."forums WHERE (fid='$fid')");
			}
      if($empty==1 || $delete==1) {
		    $getthreads = $db->query("SELECT tid FROM ".$prefix."threads WHERE (fid='$fid')");
				while($fix = $db->fetch_array($getthreads)) {
					$db->unbuffered_query("DELETE FROM ".$prefix."threads WHERE (tid='$fix[tid]')");
					$getposts = $db->query("SELECT pid, postdate FROM ".$prefix."posts WHERE (tid='$fix[tid]')");
					while($fixp = $db->fetch_array($getposts)) {
  					$db->unbuffered_query("DELETE FROM ".$prefix."posts WHERE (tid='$fixp[pid]')");
  					$db->unbuffered_query("DELETE FROM ".$prefix."posts_archive WHERE (tid='$fixp[pid]')");
					
  					##deleting attachments
    				$query = $db->query("SELECT filename FROM ".$prefix."attachments WHERE (pid='$fixp[pid]')");
    				if($db->num_rows($query)!=0) {
    					$theinfo = $db->fetch_array($query);
    					$attachurl = $settings['attachdir'].utf8_decode($theinfo['filename']).'-'.$fixp['postdate']. '.'.'ext';
    					if(@unlink(@trim($attachurl)) || !file_exists($attachurl)) {
    						$db->unbuffered_query("DELETE FROM ".$prefix."attachments WHERE (pid='$fixp[pid]')");
    					}
    				}
					}
				}
				if(!$delete) {
  				##updating forum stats
  				$db->unbuffered_query("UPDATE ".$prefix."forums SET topics=0, replies=0, lastpost=NULL, lastpostby='0', lastpid='', lastpidtime='' WHERE (fid='$fid')");
			  }
      }
			if($delete!=1) {
				$fname = $db->escape($fname);
				$fdescription = $db->escape($fdescription);
				$db->unbuffered_query("UPDATE ".$prefix."forums SET cid='$category', name='$fname', viewstatus='$viewstatus', poststatus='$poststatus', replystatus='$replystatus', ordered='$order', description='$fdescription', password='$fpassword', userlist='$userlist', moderators='$moderators', redirect='$redirect' WHERE (fid='$fid')");
			}
			message($lang_successfullyeditf, $lang_forwardstructure, "admincp.php?sub=structure");
		}
	} else {
		$forums = $db->query("SELECT * FROM ".$prefix."forums WHERE (fid='$fid')");
		$open = $db->fetch_array($forums);

		//handle viewstatus
		if($open['viewstatus']=='ad') {
			$vfour=' selected="selected"';
		} elseif($open['viewstatus']=='mo') {
			$vthree=' selected="selected"';
		} elseif($open['viewstatus']=='me') {
			$vtwo=' selected="selected"';
		} elseif($open['viewstatus']=='all') {
			$vone=' selected="selected"';
		} elseif($open['viewstatus']=='no') {
			$vzero=' selected="selected"';
		}
		$viewstatus = "<option value=\"all\"$vone>$lang_allusers</option>\n<option value=\"me\"$vtwo>$lang_allnoguests</option>\n<option value=\"mo\"$vthree>$lang_adminsandmods</option>\n<option value=\"ad\"$vfour>$lang_adminsonly</option>\n<option value=\"no\"$vzero>$lang_noviewing</option>";
		
		//handle poststatus
		if($open['poststatus']=='ad') {
			$pfour=' selected="selected"';
		} elseif($open['poststatus']=='mo') {
			$pthree=' selected="selected"';
		} elseif($open['poststatus']=='me') {
			$ptwo=' selected="selected"';
		} elseif($open['poststatus']=='all') {
			$pone=' selected="selected"';
		} elseif($open['poststatus']=='no') {
			$pzero=' selected="selected"';
		}
		$poststatus = "<option value=\"all\"$pone>$lang_allusers</option>\n<option value=\"me\"$ptwo>$lang_allnoguests</option>\n<option value=\"mo\"$pthree>$lang_adminsandmods</option>\n<option value=\"ad\"$pfour>$lang_adminsonly</option>\n<option value=\"no\"$pzero>$lang_noposting</option>";
		
		//handle replystatus
		if($open['replystatus']=='ad') {
			$rfour=' selected="selected"';
		} elseif($open['replystatus']=='mo') {
			$rthree=' selected="selected"';
		} elseif($open['replystatus']=='me') {
			$rtwo=' selected="selected"';
		} elseif($open['replystatus']=='all') {
			$rone=' selected="selected"';
		} elseif($open['replystatus']=='no') {
			$rzero=' selected="selected"';
		}
		$replystatus = "<option value=\"all\"$rone>$lang_allusers</option>\n<option value=\"me\"$rtwo>$lang_allnoguests</option>\n<option value=\"mo\"$rthree>$lang_adminsandmods</option>\n<option value=\"ad\"$rfour>$lang_adminsonly</option>\n<option value=\"no\"$rzero>$lang_noreplying</option>";

		$categories = $db->query("SELECT * FROM ".$prefix."categories");
		while ($post = $db->fetch_array($categories)) {
			if($post['cid'] == $open['cid']) {
				$category .= '<option value="'.$post['cid'].'" selected="selected">'.$post['name']."</option>\n";
			} else {
				$category .= '<option value="'.$post['cid'].'">'.$post['name']."</option>\n";
			}
		}
		
    $open['name'] = html($open['name']);
		
		include($templatefolder.'/admincp/forums_edit.dtf');
	}
}

if($sub == 'settings')	{
	require('./header_html.php');
	bar($bar_settings);
	if(!checkrestrictions('settings')) {
		message($lang_accessdenied, $lang_noaccessmsg);
	}
	if($submit==$lang_update) {
		if($gzlevel>9 || $gzlevel<0) {
			$gzlevel=5;
		}
		$pmwelcometxt = $db->escape($pmwelcometxt);
		$forumrules = $db->escape($forumrules);
		$wraplength = @intval($wraplength);
	    $edithistory = @intval($edithistory);
		$attachmaxsize = $attachmaxsize*1024;
		
		if(!$overridedate) {
			$overridedate = 0;
		}
		if(!$overrideoffset) {
			$overrideoffset = 0;
		}
		if(!$overridetime) {
			$overridetime = 0;
		}

		if($_COOKIE['membercookie'] == $settings['headadmin']) {
			if($theboardname=='' || $thehomeurl=='' || $siglength=='' || $avatarw=='' || $avatarh=='' || $avatarwlow=='' || $avatarhlow=='' || $hottopic=='' || $tppf=='' || $tppt=='' || $ompp=='' || $theheadadmin=='' || $floodctrl=='' || $maxpm=='' || $maxchars=='' || $gzlevel=='' || $spr=='' || $email_pro=='' || $wraplength=='') {
				message($lang_missingfields, $lang_missingfieldsinfo);
			} else {
				if($oldheadadmin!=$theheadadmin) {
				  $check = $db->query("SELECT uid FROM ".$prefix."users WHERE (username='".$theheadadmin."')");
				  if($db->num_rows($check)==1) { ##check if the new headadmin exists
            $db->unbuffered_query("UPDATE ".$prefix."users SET membercode='4' WHERE (username='$oldheadadmin')");
            $db->unbuffered_query("UPDATE ".$prefix."users SET membercode='5' WHERE (username='$theheadadmin')");
				  } else { ##if he doesnt exist, restore the old head admin
				    $theheadadmin = $oldheadadmin;
				  }
        }
				$db->unbuffered_query("UPDATE ".$prefix."settings SET homeurl='$thehomeurl', boardname='$theboardname', siglength='$siglength', avatarw='$avatarw', avatarh='$avatarh', avatarwlow='$avatarwlow', avatarhlow='$avatarhlow', headadmin='$theheadadmin', sightml='$sightml', skin='$skinx', language='$languagex', gzip='$gzip', hottopic='$hottopic', tppf='$tppf', tppt='$tppt', ompp='$ompp', homeurlname='$homeurlname', htmloff='$htmloff', smilies='$smilies', censors='$censors', editby='$editby', duplicateemail='$duplicateemail', floodctrl='$floodctrl', maxpm='$maxpm', useredit='$useredit', maxchars='$maxchars', guestposting='$guestposting', dateformat='$thedateformat', timeformat='$thetimeformat', hideprivf='$hideprivf', showmod='$showmod', gzlevel='$gzlevel', perstitleedit='$perstitleedit', pmwelcome='$pmwelcome', pmwelcometxt='$pmwelcometxt', timeoffset='$thetimeoffset', overrideoffset='$overrideoffset', overridedate='$overridedate', overridetime='$overridetime', spr='$spr', email_pro='$email_pro', showlocation='$showlocation', userranks='$userranks', invisible='$invisiblebrowse', wrap='$wrap', wraplength='$wraplength', guestmemfunctions='$guestmemfunctions', allowpm='$allowpm', allowonline='$allowonline', guestforumview='$guestforumview', allowlostpw='$allowlostpw', showforumrules='$showforumrules', forumrules='$forumrules', edithistory='$edithistory', emailver='$emailver', captcha='$captcha', topicstarter='$topicstarter', quickreply='$quickreply' WHERE (name='settings')");
				message($lang_successfullysettings, $lang_forwardadmincp, "admincp.php");
			}
		} else {
			if($theboardname=='' || $thehomeurl=='' || $siglength=='' || $avatarw=='' || $avatarh=='' || $avatarwlow=='' || $avatarhlow=='' || $hottopic=='' || $tppf=='' || $tppt=='' || $ompp=='' || $floodctrl=='' || $maxpm=='' || $maxchars=='' || $gzlevel=='' || $spr=='' || $email_pro=='' || $wraplength=='') {
				message($lang_missingfields, $lang_missingfieldsinfo);
			} else {
				$db->unbuffered_query("UPDATE ".$prefix."settings SET homeurl='$thehomeurl', boardname='$theboardname', siglength='$siglength', avatarw='$avatarw', avatarh='$avatarh', avatarwlow='$avatarwlow', avatarhlow='$avatarhlow', sightml='$sightml', skin='$skinx', language='$languagex', gzip='$gzip', hottopic='$hottopic', tppf='$tppf', tppt='$tppt', ompp='$ompp', homeurlname='$homeurlname', htmloff='$htmloff', smilies='$smilies', censors='$censors', editby='$editby', duplicateemail='$duplicateemail', floodctrl='$floodctrl', maxpm='$maxpm', useredit='$useredit', maxchars='$maxchars', guestposting='$guestposting', dateformat='$thedateformat', timeformat='$thetimeformat', hideprivf='$hideprivf', showmod='$showmod', gzlevel='$gzlevel', perstitleedit='$perstitleedit', pmwelcome='$pmwelcome', pmwelcometxt='$pmwelcometxt', timeoffset='$thetimeoffset', overrideoffset='$overrideoffset', overridedate='$overridedate', overridetime='$overridetime', spr='$spr', email_pro='$email_pro', showlocation='$showlocation', userranks='$userranks', invisible='$invisiblebrowse', wrap='$wrap', wraplength='$wraplength', guestmemfunctions='$guestmemfunctions', allowpm='$allowpm', allowonline='$allowonline', guestforumview='$guestforumview', allowlostpw='$allowlostpw', showforumrules='$showforumrules', forumrules='$forumrules', edithistory='$edithistory', emailver='$emailver', captcha='$captcha', topicstarter='$topicstarter', quickreply='$quickreply'  WHERE (name='settings')");
				message($lang_successfullysettings, $lang_forwardadmincp, "admincp.php");
			}
		}
	} else {
		if(date("I")) {
			$gmdateoffset = 3600;
		}
		$gmtime = gmdate($timecode, $time + $gmdateoffset);
		$gmtimemsg = "$lang_curgmttime $gmtime";
	
		$dir = opendir("lang");
		while($langfile = readdir($dir)) {
			if(is_file("lang/$langfile")) {
				$langfile = str_replace(".php", "", $langfile);
				if($langfile == "$settings[language]") {
					$languagelist .= '<option value="'.$langfile.'" selected="selected">'.$langfile."</option>\n";
				} else {
					$languagelist .= '<option value="'.$langfile.'">'.$langfile."</option>\n";
				}
			}
		}
		$query = $db->query("SELECT skinname FROM ".$prefix."skins");
		while($skininfo = $db->fetch_array($query)) {
			if($skininfo['skinname'] == $settings['skin']) {
				$skinlist .= '<option value="'.$skininfo['skinname'].'" selected="selected">'.$skininfo['skinname']."</option>\n";
			} else {
				$skinlist .= '<option value="'.$skininfo['skinname'].'">'.$skininfo['skinname']."</option>\n";
			}
		}
		
		if($settings['timeformat']==24) {
			$check24 = 'checked="checked"';
		} else {
			$check12 = 'checked="checked"';
		}

		$dateformat = array('d.m.y', #24.12.00
						   'd.m.Y', #24.12.2000
						   'd/m/y', #24/12/00
						   'd/m/Y', #24/12/2000
						   'm/d/y', #12/24/00
						   'm/d/Y', #12/24/2000
						   'd-m-y', #24-12-00
						   'd-m-Y', #24-12-2000
						   'm-d-y', #12-24-00
						   'm-d-Y', #12-24-2000
						   'Y-m-d', #2000-12-24
						   'j M Y', #24 Dec 2000
						   'j F Y', #24 December 2000
						   'j F Y l', #24 December 2000 Sunday
						   'M jS, Y', #Dec 24th, 2000
						   'F j, Y', #December 24, 2000
						   'F jS Y', #December 24th 2000
						   'D M jS, Y', #Sun Dec 24th, 2000
						   'D M j', #Sun Dec 24
						   'l F jS, Y', #Sunday December 24th, 2000
						   'l M jS, Y' #Sunday Dec 24th, 2000
						   );
	
		foreach($dateformat as $id => $code) {
			$selected = '';
			if($code == $settings['dateformat']) {
				$selected = ' selected="selected"';
			}
			$dateformatlist .= "<option value=\"$code\"$selected>".gmdate($code, 977619600)."</option>\n";
		}


		if($_COOKIE['membercookie'] == $settings['headadmin']) {
			include($templatefolder.'/admincp/settings_head.dtf');
		} else {
			include($templatefolder.'/admincp/settings.dtf');
		}
	}
}

if($sub == 'attachsettings')	{
	require('./header_html.php');
	bar($bar_attachment_settings);
	  
	if(!checkrestrictions('attachsettings')) {
		message($lang_accessdenied, $lang_noaccessmsg);
	}
	if($submit==$lang_update) {
		if(stristr($attachtypes, 'php')) {
			message($lang_phpattachments, $lang_phpattachmentsmsg);
		}
		
		$attachmaxsize = $attachmaxsize*1024;
		if($attachdir=='' || $attachtypes=='' || $attachmaxsize=='') {
			message($lang_missingfields, $lang_missingfieldsinfo);
		} else {
			$db->unbuffered_query("UPDATE ".$prefix."settings SET allowattach='$allowattach', attachdir='$attachdir', attachtypes='$attachtypes', attachmaxsize='$attachmaxsize', attachimgpost='$attachimgpost' WHERE (name='settings')");
			message($lang_successfullysettings, $lang_forwardadmincp, "admincp.php");
		}
	} else {
		$settings['attachmaxsize'] = $settings['attachmaxsize']/1024;
		include($templatefolder.'/admincp/attachment_settings.dtf');
	}
}

if($sub == 'skins') {
	if(isset($action)) {
		if($action == "view") {
			require('./header_html.php');
			bar($bar_skin_info);
			if(!checkrestrictions('skins')) {
				message($lang_accessdenied, $lang_noaccessmsg);
			}
			$getskin = $db->query("SELECT * FROM ".$prefix."skins WHERE (skinname='$name')");
			$xskin = $db->fetch_array($getskin);
			include($templatefolder.'/admincp/skins_view.dtf');
		} elseif($action == 'new') {
			require('./header_html.php');
			bar($bar_new_skin);
			if(!checkrestrictions('skins')) {
				message($lang_accessdenied, $lang_noaccessmsg);
			}
			if($submit==$lang_create) {
				$query = $db->query("SELECT skinname FROM ".$prefix."skins WHERE (skinname='$xskinname')");
				if($db->num_rows > 0) {
					message($lang_skinexists, $lang_skinexistsinfo);
				}
				$db->unbuffered_query("INSERT INTO ".$prefix."skins VALUES ('$xskinname', '$ximages', '$xsmiliepath', '$xtemplatefolder', '$xlogourl', '$xcomment')");
				message($lang_successfullynewskin, $lang_forwardadmincp, "admincp.php");
			} else {
				include($templatefolder.'/admincp/skins_new.dtf');
			}
		} elseif($action == 'edit') {
			require('./header_html.php');
			if(!checkrestrictions('skins')) {
				message($lang_accessdenied, $lang_noaccessmsg);
			}
			if($submit==$lang_update) {
				bar($bar_edit_skin.' '.$xskinname);
		  		$db->unbuffered_query("UPDATE ".$prefix."skins SET images='$ximages', smiliepath='$xsmiliepath', logourl='$xlogourl' WHERE (skinname='$xskinname')");
				message($lang_successfullyeditskin, $lang_forwardmainskinview, "admincp.php?sub=skins");
				quit();
			} else {
				bar($bar_edit_skin.' '.$name);
				$getskininfo = $db->query("SELECT * FROM ".$prefix."skins WHERE (skinname='$name')");
				$skin = $db->fetch_array($getskininfo);
				
				$csspath = $skin['images'].'/css/';
				
				include($templatefolder.'/admincp/skins_edit.dtf');
			}
		} elseif($action == 'delete') {
			require('./header_html.php');
			if(!checkrestrictions('skins')) {
				message($lang_accessdenied, $lang_noaccessmsg);
			}
			if(isset($sname)) {
				bar($bar_del_skin.' '.$sname);
				if($submit==$lang_yes) {
					$db->unbuffered_query("DELETE FROM ".$prefix."skins WHERE (skinname='$sname')");
					##update user skins
					$db->unbuffered_query("UPDATE ".$prefix."users SET skin='$settings[skin]' WHERE (skin='$sname')");
					message($lang_successfullydeleteskin, $lang_forwardmainskinview, "admincp.php?sub=skins");
				} elseif($submit2==$lang_no) {
					redirect("admincp.php?sub=skins", 0.1);
				}
			} else {
				bar($bar_del_skin.' '.$name);
				include($templatefolder.'/admincp/skins_delete.dtf');
			}
		} elseif($action == 'export') {
			if(!checkrestrictions('skins')) {
				message($lang_accessdenied, $lang_noaccessmsg);
			}

			//getting skin data
			$data .= "/* ---> Skin Data <--- */\r\n";
			$query = $db->query("SELECT * FROM ".$prefix."skins WHERE (skinname='$name')");
			while($skindata = $db->fetch_array($query)) {
				foreach($skindata as $x=>$y) {
					if(!is_integer($x)) {
						addslashes($y);
						$data .= "$x=$y\r\n";
					}
				}
			}
			
			##correct headers so it works on ie AND other browsers
			header("Content-Length: ".strlen($data));
			header("Content-Type: application/x-ms-download");
	
			if(checkbrowser() == 'IE') {
				header('Content-Disposition: inline; filename="' . $name . '.dbb"');
				header('Expires: 0');
				header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
				header('Pragma: public');
			} else {
				header('Content-Disposition: attachment; filename="' . $name . '.dbb"');
				header('Expires: 0');
				header('Pragma: no-cache');
			}
			echo $data;
			exit();
		} elseif($action == 'import') {
			require('./header_html.php');
			bar($bar_import_skin);

			if(!checkrestrictions('skins')) {
				message($lang_accessdenied, $lang_noaccessmsg);
			}
			
			@extract($_FILES);
			
			if(!$skinfile) {
				message($lang_missingfields, $lang_missingfieldsinfo);
				quit();
			}			
			
			$lines = @file($skinfile['tmp_name']);
			if(!$lines) {
				message($lang_skinimport_error, $lang_forwardskins, "admincp.php?sub=skins");
				quit();
			}
			$num = 0;
			
			foreach($lines as $num => $line) {
				if($line!="" && strstr($line, '=')) {
					$array = explode("=",$line);

					if($array['0']=='skinname') {
						$check = $db->query("SELECT skinname FROM ".$prefix."skins WHERE (skinname='$array[1]')");
						if($db->num_rows($check) > 0) {
							message($lang_import_error, $lang_import_already_ex);
							quit();
						}
					}
					$array['0'] = trim($array['0']);
					$array['1'] = trim($array['1']);
					$array['1'] = stripslashes($array['1']);
					$data[$array['0']] = $array['1'];
					$array['0'] = '';
					$array['1'] = '';
				}
			}
			$db->unbuffered_query("INSERT INTO ".$prefix."skins VALUES ('$data[skinname]', '$data[images]', '$data[smiliepath]', '$data[templatefolder]', '$data[logourl]', '$data[comment]')");
			message($lang_successfullyimport, $lang_forwardskins, "admincp.php?sub=skins");
		}
	} else {
		require('./header_html.php');
		bar($bar_skins);
		
		if(!checkrestrictions('skins')) {
			message($lang_accessdenied, $lang_noaccessmsg);
		}
		
		include($templatefolder.'/admincp/skins_header.dtf');
		$getskins = $db->query("SELECT * FROM ".$prefix."skins ORDER BY skinname");
		$x=0;
		while($skin = $db->fetch_array($getskins)) {
			$memuseskin = $db->query("SELECT COUNT('$skin[skinname]') FROM ".$prefix."users WHERE (skin='$skin[skinname]')");
			$members = $db->result($memuseskin, 0);
			
			//Fix for members using 'default'
			if($settings['skin']==$skin['skinname']) {
				$memuseskin = $db->query("SELECT COUNT('default') FROM ".$prefix."users WHERE (skin='default')");
				$members += $db->result($memuseskin, 0);
			}

			if($x==0) {
				$add = ' checked="checked"';
			} else {
				$add = '';
			}
			include($templatefolder.'/admincp/skins_fields.dtf');
			$x++;
		}
		include($templatefolder.'/admincp/skins_footer.dtf');
	}
}

if($sub == 'maintenance') {
	require('./header_html.php');
	bar($bar_maintenance_opt);
	if(!checkrestrictions('maintenance')) {
		message($lang_accessdenied, $lang_noaccessmsg);
	}
	if($submit==$lang_update) {
		if($msg == '')	{
			message($lang_missingfields, $lang_missingfieldsinfo);
		} else {
			$msg = trim($msg);
			$msg = $db->escape($msg);
			$db->unbuffered_query("UPDATE ".$prefix."settings SET maintenance='$option', maintenancemsg='$msg' WHERE (name='settings')");
			message($lang_successfullymaintance, $lang_forwardadmincp, "admincp.php");
		}
	} else {
		if($settings['maintenance'] == '1') { $one = 'selected="selected"'; } else { $two = 'selected="selected"'; }
		include($templatefolder.'/admincp/maintenance.dtf');
	}
}

if($sub == "cplog") {
	require('./header_html.php');
	bar($bar_cplog);
	if(!checkrestrictions('cplog')) {
		message($lang_accessdenied, $lang_noaccessmsg);
	}
	
	if($settings['cplog']==0) {
		message($lang_cplogdisabled, $lang_forwardadmincp, "admincp.php");
	} else {
		include_once($templatefolder.'/admincp/cplog_header.dtf');
		$a = file("$dir/cp.php");
		$total = count($a);
		for($x=0;$x<$total;$x++) {
			$info = explode("|##|", $a[$x]);
			$date = gmdate($datecode, $info['2'] + ($member['timeoffset'] * 3600));
			$time = gmdate($timecode, $info['2'] + ($member['timeoffset'] * 3600));
			$url = '<a href="'.str_replace('&', '&amp;', $info[3]).'" target="_blank">'.str_replace('&', '&amp;', $info[3]).'</a>';
			include($templatefolder.'/admincp/cplog_fields.dtf');
		}
		echo "</table></td></tr></table>";
	}
}

if($sub == "cplogoptions") {
	require('./header_html.php');
	bar($bar_cplog_opt);
	if(!checkrestrictions('cplogopt')) {
		message($lang_accessdenied, $lang_noaccessmsg);
	}
	
	if($logs==1) {
		message($lang_logconfdisabled);
	}

	if($submit==$lang_reset) {
		if($select == "yes") {
			$dir = "$settings[logpath]";
			$path = $dir."/cp.php";
			$fp = @fopen("$path","a+");
			if(@ftruncate($fp, 0)) {
				message($lang_successfullyresetcplog, $lang_forwardadmincp, "admincp.php");
			} else {
				message("$path $lang_cplogdeletefailed", $lang_cplogdeletefailedinfo, "admincp.php", 3);
			}
			@fclose($fp);
		} else {
			message($lang_noresetcplog, $lang_forwardadmincp, "admincp.php");
		}
	} elseif($submit2==$lang_update) {
		$db->unbuffered_query("UPDATE ".$prefix."settings SET logpath='$logdir', cplog='$cplog' WHERE (name='settings')");
		message($lang_succesfullyeditcplog, $lang_forwardadmincp, "admincp.php");
	} else {
		include($templatefolder.'/admincp/cplogoptions.dtf');
	}
}

if($sub == "optimize") {
	require('./header_html.php');
	bar($bar_optimize);
	
	if(!checkrestrictions('optimize')) {
		message($lang_accessdenied, $lang_noaccessmsg);
	}
	
	if($submit==$lang_go) {
		//cleaning up db can take pretty long so we try to override 30 sec limit
		@ini_set('max_execution_time', '1000');
		@set_time_limit (1000);
		
		$list = array('attachments','banned','boardstats','categories','forums','online','pm','posts','posts_archive','replacements','restrictions','settings','skins','subscriptions','ranks','threads','users');
		if($reminv==1) {
			//deleting invalid users
			$db->unbuffered_query("DELETE FROM ".$prefix."users WHERE (membercode=0 && username!='guest' && username!='invisible')");
			$db->unbuffered_query("DELETE FROM ".$prefix."users WHERE (username='')");
				
			//deleting invalid categories
			$db->unbuffered_query("DELETE FROM ".$prefix."categories WHERE (name='')");
			
			//deleting invalid or left forums
			$db->unbuffered_query("DELETE FROM ".$prefix."forums WHERE (name='' || cid='')");
			$getforums = $db->query("SELECT cid,fid FROM ".$prefix."forums");
			while($fix = $db->fetch_array($getforums)) {
				$getcats = $db->query("SELECT count(cid) FROM ".$prefix."categories WHERE (cid='$fix[cid]')");
				if(!$db->result($getcats)) {
					$db->unbuffered_query("DELETE FROM ".$prefix."forums WHERE (cid='$fix[cid]')");
				}
				$querythread = $db->query("SELECT tid FROM ".$prefix."threads WHERE (fid='$fix[fid]')");
				while($fix2 = $db->fetch_array($querythread)) {
					$db->unbuffered_query("DELETE FROM ".$prefix."threads WHERE (tid='$fix[tid]')");
					$db->unbuffered_query("DELETE FROM ".$prefix."posts WHERE (tid='$fix[tid]')");
				}
			}

			//deleting invalid or left threads (forum doesnt exsist anymore)
			$db->unbuffered_query("DELETE FROM ".$prefix."threads WHERE (subject='')");
			$getthreads = $db->query("SELECT fid,tid FROM ".$prefix."threads");
			while($fix = $db->fetch_array($getthreads)) {
				$getforums = $db->query("SELECT count(fid) FROM ".$prefix."forums WHERE (fid='$fix[fid]')");
				if(!$db->result($getforums)) {
					$db->unbuffered_query("DELETE FROM ".$prefix."threads WHERE (fid='$fix[fid]')");
					$db->unbuffered_query("DELETE FROM ".$prefix."posts WHERE (tid='$fix[tid]')");
				}
			}
			
			//deleting invalid or left posts (thread doesnt exsist anymore)
			$db->unbuffered_query("DELETE FROM ".$prefix."posts WHERE (message='')");
			$getposts = $db->query("SELECT tid FROM ".$prefix."posts");
			while($fix = $db->fetch_array($getposts)) {
				$getthread = $db->query("SELECT COUNT(tid) FROM ".$prefix."threads WHERE (tid='$fix[tid]')");
				if(!$db->result($getthread)) {
					$db->unbuffered_query("DELETE FROM ".$prefix."posts WHERE (tid='$fix[tid]')");
				}
			}

			//clean up skin table
			$db->unbuffered_query("DELETE FROM ".$prefix."skins WHERE (skinname='')");
		}
		
		if($clearunval==1) {
  		$oneweek = time()- 604800; ##one week ago
  		$getunval = $db->query("SELECT uid,username FROM ".$prefix."users WHERE (valnum!='' && joineddate<$oneweek)");
  		while($unval = $db->fetch_array($getunval)) {
  			$db->unbuffered_query("DELETE FROM ".$prefix."users WHERE (uid=".$unval['uid'].")");
  			$db->unbuffered_query("DELETE FROM ".$prefix."pm WHERE (whoto='".$unval['username']."')");
  		}
		}
			
		if($ftt==1) {
			$fttquery = $db->query("SELECT fid FROM ".$prefix."forums");
			while($fttx = $db->fetch_array($fttquery)) {
				##counting posts
				$replies = 0;
				$threads = 0;
				$pcquery = $db->query("SELECT tid FROM ".$prefix."threads WHERE (fid='$fttx[fid]' && moved=0)");
				while($pc = $db->fetch_array($pcquery)) {
					$pq = $db->query("SELECT COUNT(pid) FROM ".$prefix."posts WHERE (tid='$pc[tid]')");
					$replyupdate = $db->result($pq)-1;
					$replies += $replyupdate;
					##counting threads
					$threads++;
					##updating thread info
					$db->unbuffered_query("UPDATE ".$prefix."threads SET replies='".$replyupdate."' WHERE (tid='$pc[tid]')");
				}
				
				##updating forum stats
				$getlp = $db->query("SELECT tid,subject,lastpostdate,lastpostby FROM ".$prefix."threads WHERE (fid='$fttx[fid]') ORDER BY lastpostdate DESC LIMIT 1");
				$lpinfo = $db->fetch_array($getlp);
				if(!$lpinfo['tid']) {
					$db->unbuffered_query("UPDATE ".$prefix."forums SET topics=0, replies=0, lastpost=NULL, lastpostby='0', lastpid='', lastpidtime='' WHERE (fid='$fttx[fid]')");
				} else {
  			  if($lpinfo['lastpostby']=='guest') {
             $getlpuid = 0;
           } else {
           	$getlpuid = $db->query("SELECT uid FROM ".$prefix."users WHERE username='".$lpinfo['lastpostby']."'");
           }
					$db->unbuffered_query("UPDATE ".$prefix."forums SET topics='$threads', replies='$replies', lastpost='".$db->escape($lpinfo['subject'])."', lastpostby='".$db->result($getlpuid)."', lastpid='$lpinfo[tid]', lastpidtime='$lpinfo[lastpostdate]' WHERE (fid='$fttx[fid]')");
				}
			}
		}
		
		if($fmp==1) {
			$fmpquery = $db->query("SELECT uid FROM ".$prefix."users");
			while($memberx = $db->fetch_array($fmpquery)) {
				##get threads
				$getthreads = $db->query("SELECT COUNT(*) FROM ".$prefix."threads WHERE (author='$memberx[uid]')");
				$threads = $db->result($getthreads);
				##get replies
				$getposts = $db->query("SELECT COUNT(*) FROM ".$prefix."posts WHERE (author='$memberx[uid]')");
				$posts = $db->result($getposts)-$threads; //substracting threads
				##inserting
				$count = $threads+$posts;
				$db->unbuffered_query("UPDATE ".$prefix."users SET posts='$count' WHERE (uid='$memberx[uid]')");
				##updating stored stats
				$getmemnum = $db->query("SELECT COUNT(uid) FROM ".$prefix."users WHERE (username!='guest' && username!='invisible')");
				$memnum = $db->result($getmemnum);
				$db->unbuffered_query("UPDATE ".$prefix."boardstats SET whatof='$memnum' WHERE (nameof='members')");
				##Fixing newest member
				$getlastjoined = $db->query("SELECT username FROM ".$prefix."users ORDER BY joineddate DESC LIMIT 1");
				$lastjoined = $db->result($getlastjoined);
				$db->unbuffered_query("UPDATE ".$prefix."boardstats SET whenof='$lastjoined' WHERE nameof='members'");
			}
		}
		
		if($deletelog==1 && $logs!=1) {
			$dir = $settings['logpath'];
			$path = $dir.'/cp.php';
			$fp = @fopen("$path","a+");
			if(!@ftruncate($fp, 0)) {
				message("$path $lang_cplogdeletefailed", $lang_cplogdeletefailedinfo);
			}
			@fclose($fp);
		}
		
		if($reptables==1) {
			$db->query("UNLOCK TABLES"); 
			foreach($list as $element) {
				$db->query("CHECK TABLE ".$prefix.$element." EXTENDED"); 
				$db->query("REPAIR TABLE ".$prefix.$element);
			}
		}
		
		if($opttables==1) {
			foreach($list as $element) {
				$db->query("OPTIMIZE TABLE ".$prefix.$element);
			}
		}
		
		if($clearonline==1) {
			//dump whos online
			$db->unbuffered_query("TRUNCATE ".$prefix."online");
		}
		message($lang_successfullyoptimized, $lang_forwardadmincp, "admincp.php");
	} else {
		include($templatefolder.'/admincp/optimize.dtf');
	}
}

if($sub == "exec") {
	require('./header_html.php');
	bar($bar_exec);
	
	if(!checkrestrictions('exec')) {
		message($lang_accessdenied, $lang_noaccessmsg);
	}

	if($submit==$lang_execute) {
		$explode = explode(";\r\n", $execboxcontent);

		for($x=0;$x<sizeof($explode);$x++) {
			if($explode[$x]!='') {
				##First we equalise GPC settings with the escape functions and then we remove the unneeded slashes!
				$explode[$x] = stripslashes($db->escape($explode[$x]));
				$db->query("$explode[$x]");
			}
		}
		message($lang_successfully_exec, $lang_forwardadmincp, "admincp.php");
	} else {
		include($templatefolder.'/admincp/execbox.dtf');
	}
}

if($sub == "ban") {
	require('./header_html.php');
	bar($bar_ban);
	if(!checkrestrictions('ban')) {
		message($lang_accessdenied, $lang_noaccessmsg);
	}
	
	if($submit==$lang_unban) {
		for($x=0;$x<sizeof($delete);$x++) {
			$db->unbuffered_query("DELETE FROM ".$prefix."banned WHERE (value='$delete[$x]')");
		}
		message($lang_successfully_unbanned, $lang_forwardadmincp, "admincp.php");
	} elseif($submit2==$lang_ban) {
		if(value_exists($byname)) {
			$db->unbuffered_query("INSERT INTO ".$prefix."banned VALUES ('$byname', 'name')");
		}
		if(value_exists($byemail)) {
			$db->unbuffered_query("INSERT INTO ".$prefix."banned VALUES ('$byemail', 'email')");
		}
		if(value_exists($byip1)) {
			$byip = "$byip1.$byip2.$byip3.$byip4";
			$db->unbuffered_query("INSERT INTO ".$prefix."banned VALUES ('$byip', 'ip')");
		}
		if(value_exists($byhost)) {
			$db->unbuffered_query("INSERT INTO ".$prefix."banned VALUES ('$byhost', 'host')");
		}	
		message($lang_banningsuccess, $lang_forwardadmincp, "admincp.php");
	} else {
		include($templatefolder.'/admincp/ban_header.dtf');
		$getbans = $db->query("SELECT * FROM ".$prefix."banned ORDER BY value");
		while($bans = $db->fetch_array($getbans)) {
			include($templatefolder.'/admincp/ban_fields.dtf');
		}
		include($templatefolder.'/admincp/ban_footer.dtf');
		include($templatefolder.'/admincp/ban.dtf');
	}
}

if($sub == "pruneposts") {
	require('./header_html.php');
	bar($bar_prune_posts);
	if(!checkrestrictions('pruneposts')) {
		message($lang_accessdenied, $lang_noaccessmsg);
	}
	
	if($submit==$lang_pruneposts) {
		//calculating the unixtime
		$stamp = time()-(86400*$age);
		
		//closed
		if($closed==1) {
			$additions = " && t.closed='1'";
		}
		
		//user
		if($user!='') {
			$additions .= " && u.username='$user'";
		}
		
		if($forum!='pruneall') {
			$additions .= " && t.fid='$forum'";
		}

		//query
		$query = $db->query("SELECT t.tid,t.subject,t.replies FROM ".$prefix."threads t LEFT JOIN ".$prefix."users u ON (t.author=u.uid) WHERE (t.lastpostdate <= '$stamp'".$additions.")");
		
		if($what=='delete') {
			//deleting data
			while($delete = $db->fetch_array($query)) {
				$db->unbuffered_query("DELETE FROM ".$prefix."threads WHERE (tid='$delete[tid]')");
				
        //del attachments
        $query = $db->query("SELECT a.filename,p.postdate,p.pid FROM ".$prefix."attachments a LEFT JOIN ".$prefix."posts p ON (a.pid=p.pid) LEFT JOIN ".$prefix."users u ON (p.author=u.uid) WHERE (a.pid=p.pid && p.tid='$delete[tid]')");
        while($theinfo = $db->fetch_array($query)) {
          $attachurl = $settings['attachdir'].utf8_decode($theinfo['filename']).'-'.$theinfo['postdate']. '.'.'ext';
          if(@unlink(@trim($attachurl)) || !file_exists($attachurl)) {
            $db->unbuffered_query("DELETE FROM ".$prefix."attachments WHERE (pid='$theinfo[pid]')");
          }
        }
				
				$db->unbuffered_query("DELETE FROM ".$prefix."posts WHERE (tid='$delete[tid]')");
				$db->unbuffered_query("DELETE FROM ".$prefix."posts_archive WHERE (tid='$delete[tid]')");
			}
		} elseif($what=='move') {
			//moving data
			if($move!='') {
				while($moveto = $db->fetch_array($query)) {
					$db->unbuffered_query("UPDATE ".$prefix."threads SET fid='$move' WHERE (tid='$moveto[tid]')");
				}
			} else {
				message($lang_forgotmovefield1, $lang_forgotmovefield2);
				quit();
			}
		}
		
		##correcting counts
		@ini_set('max_execution_time', '1000');
		@set_time_limit(1000);
		$fttquery = $db->query("SELECT fid FROM ".$prefix."forums");
		while($fttx = $db->fetch_array($fttquery)) {
			##counting posts
			$replies = 0;
			$threads = 0;
			$pcquery = $db->query("SELECT tid FROM ".$prefix."threads WHERE (fid='$fttx[fid]' && moved='0')");
			while($pc = $db->fetch_array($pcquery)) {
				$pq = $db->query("SELECT COUNT(pid) FROM ".$prefix."posts WHERE (tid='$pc[tid]')");
				$replyupdate = $db->result($pq)-1;
				$replies += $replyupdate;
				##counting threads
				$threads++;					
				##updating thread info
				$db->unbuffered_query("UPDATE ".$prefix."threads SET replies='".$replyupdate."' WHERE (tid='$pc[tid]')");
			}
			##updating forum thread and replies count
			$db->unbuffered_query("UPDATE ".$prefix."forums SET topics='$threads', replies='$replies' WHERE (fid='$fttx[fid]')");
		}
		$fmpquery = $db->query("SELECT uid FROM ".$prefix."users");
		while($memberx = $db->fetch_array($fmpquery)) {
			##get threads
			$getthreads = $db->query("SELECT COUNT(*) FROM ".$prefix."threads WHERE (author='$memberx[uid]')");
			$threads = $db->result($getthreads);
			##get replies
			$getposts = $db->query("SELECT COUNT(*) FROM ".$prefix."posts WHERE (author='$memberx[uid]')");
			$posts = $db->result($getposts)-$threads; //substracting threads
			##inserting
			$count = $threads+$posts;
			$db->unbuffered_query("UPDATE ".$prefix."users SET posts='$count' WHERE (uid='$memberx[uid]')");
			##updating stored stats
			$getmemnum = $db->query("SELECT COUNT(uid) FROM ".$prefix."users WHERE (username!='guest' && username!='invisible')");
			$memnum = $db->result($getmemnum);
			$db->unbuffered_query("UPDATE ".$prefix."boardstats SET whatof='$memnum' WHERE (nameof='members')");
		}
		message($lang_successfullypruned, $lang_forwardadmincp, "admincp.php");
	} else {
		$query = $db->query("SELECT fid,name FROM ".$prefix."forums ORDER BY ordered");
		while($forums = $db->fetch_array($query)) {
			$forumlist .= "<option value=\"$forums[fid]\">".$forums['name']."</option>\n";
		}
		include($templatefolder.'/admincp/prune_posts.dtf');
	}
}

if($sub == "prunepm") {
	require('./header_html.php');
	bar($bar_prune_pm);
	if(!checkrestrictions('prunepms')) {
		message($lang_accessdenied, $lang_noaccessmsg);
	}
	
	if($submit==$lang_prunepm) {
		//calculating the unixtime
		if($age!="now") {
			$stamp = time()-(86400*$age);
		} else {
			$stamp = time();
		}
		//read
		if($read==1) {
			$additions = " && (hasread='yes')";
		}
		
		//user
		if($user!="") {
			$additions .= " && (whoto='$user')";
		}
		
		//query
		if($folder=="pruneall") {
			$query = $db->query("SELECT pmid,whoto FROM ".$prefix."pm WHERE (orderunixtime <= '$stamp') && (type='inbox' || type='outbox')".$additions);
		} else {
			$query = $db->query("SELECT pmid,whoto FROM ".$prefix."pm WHERE (orderunixtime <= '$stamp') && (type='$folder')".$additions);
		}
		
		//deleting data
		while($delete = $db->fetch_array($query)) {
			if($who=='all') {
				$db->unbuffered_query("DELETE FROM ".$prefix."pm WHERE (pmid='$delete[pmid]')");
			} else {
				$lmem = $db->query("SELECT membercode FROM ".$prefix."users WHERE (username = '$delete[whoto]')");
				$mem = $db->fetch_array($lmem);
				if($who='admo' && ($mem['membercode']==4||$mem['membercode']==3||$mem['membercode']==2)) {
					$db->unbuffered_query("DELETE FROM ".$prefix."pm WHERE (pmid='$delete[pmid]')");
				} elseif($who='me' && $mem['membercode']==1) {
					$db->unbuffered_query("DELETE FROM ".$prefix."pm WHERE (pmid='$delete[pmid]')");
				}
			}
		}
		
		message($lang_successfullypruned, $lang_forwardadmincp, "admincp.php");
	} else {
		include($templatefolder.'/admincp/prune_pm.dtf');
	}
}

if($sub == "smilie") {
	bbcodecache();
	require('./header_html.php');
	bar($bar_smilies);
	if(!checkrestrictions('editsmilies')) {
		message($lang_accessdenied, $lang_noaccessmsg);
	}
	
	if($submit == $lang_delete) {
		for($x=0;$x<sizeof($delete);$x++) {
			$db->unbuffered_query("DELETE FROM ".$prefix."replacements WHERE (id='$delete[$x]')");
		}
		$what = $lang_osmilies;
		message("$lang_successfully_replacements $what", $lang_forwardeditsmiliemain, "admincp.php?sub=smilie");
	} elseif($submit2 == $lang_smilie_make) {
		$bbcode = $db->escape($bbcode);
		$replacement = $db->escape($replacement);
		if(value_exists($bbcode)) {
			$db->unbuffered_query("INSERT INTO ".$prefix."replacements VALUES (NULL,'$bbcode', '$replacement', 'smilie', '$inmenu','$enabled')");
			message($lang_successfullysmilie, $lang_forwardeditsmiliemain, "admincp.php?sub=smilie");
		} else {
			message($lang_missingfields, $lang_missingfieldsinfo);
		}
	} elseif($submit2 == $lang_edit) {
		$bbcode = $db->escape($bbcode);
		$replacement = $db->escape($replacement);
		if(value_exists($bbcode)) {
			$db->unbuffered_query("UPDATE ".$prefix."replacements SET tag='$bbcode', replacement='$replacement', type='smilie', enabled='$enabled', inmenu='$inmenu' WHERE id='$id'");
			message($lang_successfullyeditsmilie, $lang_forwardeditsmiliemain, "admincp.php?sub=smilie");
		} else {
			message($lang_missingfields, $lang_missingfieldsinfo);
		}		
	} elseif(isset($edit) && $edit != "edit") {
		$query = $db->query("SELECT * FROM ".$prefix."replacements WHERE (type='smilie' && id='$edit')");
		$qbbcode = $db->fetch_array($query);
		if(value_exists($qbbcode)) {
			include($templatefolder.'/admincp/smilie_edit.dtf');
		} else {
			message($lang_smilie_notex, $lang_forwardeditsmiliemain, "admincp.php?sub=smilie");
		}		
	} else {
		include($templatefolder.'/admincp/smilie_header.dtf');
		$getbbcodes = $db->query("SELECT * FROM ".$prefix."replacements WHERE (type='smilie') ORDER BY id");
		while($bbcodes = $db->fetch_array($getbbcodes)) {
			$id=$bbcodes['id'];
			$tag=$bbcodes['tag'];
			$example=$tag;
			$preview=bbcode($example);
			include($templatefolder.'/admincp/smilie_fields.dtf');
			
		}
		include($templatefolder.'/admincp/smilie_footer.dtf');
		include($templatefolder.'/admincp/smilie.dtf');
	}
}

if($sub == "posticon") {
	require('./header_html.php');
	bar($bar_posticons);
	if(!checkrestrictions('editposticons')) {
		message($lang_accessdenied, $lang_noaccessmsg);
	}
	
	if($submit == $lang_delete) {
		for($x=0;$x<sizeof($delete);$x++) {
			$db->unbuffered_query("DELETE FROM ".$prefix."replacements WHERE (id='$delete[$x]')");
		}
		$what = $lang_posticonso;
		message("$lang_successfully_replacements $what", $lang_forwardeditposticonmain, "admincp.php?sub=posticon");
	} elseif($submit2 == $lang_add) {
		$bbcode = $db->escape($bbcode);
		$replacement = $db->escape($replacement);
		if(value_exists($bbcode)) {
			$db->unbuffered_query("INSERT INTO ".$prefix."replacements VALUES (NULL, NULL, '$bbcode', 'posticon', 'yes', '$enabled')");
			message($lang_successfullyposticon, $lang_successfullyeditposticon, "admincp.php?sub=posticon");
		} else {
			message($lang_missingfields, $lang_missingfieldsinfo);
		}
	} elseif($submit2 == $lang_edit) {
		$bbcode = $db->escape($bbcode);
		$replacement = $db->escape($replacement);
		if(value_exists($replacement)) {
			$db->unbuffered_query("UPDATE ".$prefix."replacements SET replacement='$replacement', type='posticon', enabled='$enabled', inmenu='$inmenu' WHERE (id='$id')");
			message($lang_successfullyeditposticon, $lang_forwardeditposticonmain, "admincp.php?sub=posticon");
		} else {
			message($lang_missingfields, $lang_missingfieldsinfo);
		}		
	} elseif(isset($edit) && $edit != "edit") {
		$query = $db->query("SELECT * FROM ".$prefix."replacements WHERE (type='posticon' && id='$edit')");
		$qbbcode = $db->fetch_array($query);
		if(value_exists($qbbcode)) {
			include($templatefolder.'/admincp/posticon_edit.dtf');
		} else {
			message($lang_posticon_notex, $lang_successfullyeditposticon, "admincp.php?sub=posticon");
		}		
	} else {
		include($templatefolder.'/admincp/posticon_header.dtf');
		$getbbcodes = $db->query("SELECT * FROM ".$prefix."replacements WHERE (type='posticon') ORDER BY id");
		while($bbcodes = $db->fetch_array($getbbcodes)) {
			$id=$bbcodes['id'];
			$preview = '<img src="'.$smiliepath."/".$bbcodes['replacement'].'" alt="Smilie" />';
			include($templatefolder.'/admincp/posticon_fields.dtf');
			
		}
		include($templatefolder.'/admincp/posticon_footer.dtf');
		include($templatefolder.'/admincp/posticon.dtf');
	}
}

if($sub == "censor") {
	bbcodecache();
	require('./header_html.php');
	bar($bar_censors);
	if(!checkrestrictions('editcensors')) {
		message($lang_accessdenied, $lang_noaccessmsg);
	}
	
	if($submit == $lang_delete) {
		for($x=0;$x<sizeof($delete);$x++) {
			$db->unbuffered_query("DELETE FROM ".$prefix."replacements WHERE (id='$delete[$x]')");
		}
		$what = $lang_censors;
		message("$lang_successfully_replacements $what", $lang_forwardeditcensorsmain, "admincp.php?sub=censor");
	} elseif($submit2 == $lang_censor_make) {
		$bbcode = $db->escape($bbcode);
		$replacement = $db->escape($replacement);
		if(value_exists($bbcode)) {
			$db->unbuffered_query("INSERT INTO ".$prefix."replacements VALUES (NULL, '$bbcode', '$replacement', 'censor','','$enabled')");
			message($lang_successfullycensor, $lang_forwardeditcensorsmain, "admincp.php?sub=censor");
		} else {
			message($lang_missingfields, $lang_missingfieldsinfo);
		}		
	} elseif($submit2 == $lang_edit) {
		$bbcode = $db->escape($bbcode);
		$replacement = $db->escape($replacement);
		if(value_exists($bbcode)) {
			$db->unbuffered_query("UPDATE ".$prefix."replacements SET tag='$bbcode', replacement='$replacement', type='censor', enabled='$enabled' WHERE id='$id'");
			message($lang_successfullyeditcensor, $lang_forwardeditcensorsmain, "admincp.php?sub=censor");
		} else {
			message($lang_censor_notex, $lang_forwardeditcensorsmain, "admincp.php?sub=censor");
		}		
	} elseif(isset($edit) && $edit != "edit") {
		$edit = $db->escape($edit);
		$query = $db->query("SELECT * FROM ".$prefix."replacements WHERE (type='censor' && id='$edit')");
		$qbbcode = $db->fetch_array($query);
		if(value_exists($qbbcode)) {
			include($templatefolder.'/admincp/censor_edit.dtf');
		} else {
			message($lang_censor_notex, $lang_forwardeditcensorsmain, "admincp.php?sub=censor");
		}	
	} else {
		include($templatefolder.'/admincp/censor_header.dtf');
		$getbbcodes = $db->query("SELECT * FROM ".$prefix."replacements WHERE (type='censor') ORDER BY id");
		while($bbcodes = $db->fetch_array($getbbcodes)) {
			$id=$bbcodes['id'];
			$tag=$bbcodes['tag'];
			$replacement=$bbcodes['replacement'];
			$replacement=htmlspecialchars(get_magic_quotes_gpc()?stripslashes($replacement):$replacement);
			$example=$bbcodes['tag'];
			$preview=bbcode($tag);
			include($templatefolder.'/admincp/censor_fields.dtf');
			
		}
		include($templatefolder.'/admincp/censor_footer.dtf');
		include($templatefolder.'/admincp/censor.dtf');
	}
}

if($sub == "backup") {
	if($submit==$lang_go) {
		//initialising
		$crlf = "\r\n";
		$dump = '';
		$date = date("Y-m-d");
		$now = gmdate('D, d M Y H:i:s') . ' GMT';

		//check for output compressions
   	$gzip_on = (@function_exists('gzencode'));
    $bzip_on = (@function_exists('bzcompress'));
    	
    //mode check
		if($what=='board') {
			$sqlfile="deluxebb-backup-$date";
			$list = array('attachments','banned','boardstats','categories','forums','online','pm','posts','posts_archive','replacements','restrictions','settings','skins','subscriptions','ranks','threads','users');

			foreach($list as $cur_table) {
				$cur_table = $prefix.$cur_table;
				if($content=='both' || $content=='structure') {
					$dump .= get_table_def($cur_table, $crlf).$crlf;
				}
				if($content=='both' || $content=='data') {
					$dump .= get_table_content($cur_table, $crlf);
				}
				$dump .= $crlf;
			}
		} elseif($what=='database') {
			$sqlfile="$dbname-backup-$date.sql";
			$tables = mysql_list_tables($dbname);
			$num_tables = $db->num_rows($tables);
			$i=0;
			while($i < $num_tables) {
				$table = mysql_tablename($tables, $i);
				if($content=='both' || $content=='structure') {
					$dump .= get_table_def($table, $crlf).$crlf;
				}
				if($content=='both' || $content=='data') {
					$dump .= get_table_content($table, $crlf);
				}
				$dump .= $crlf;
				$i++;
			}
		}
		
		//after we received the dump - optional compression
		if($compress!='display') {
			if(($gzip_on) && $compress=='gzip') {
				$ext = 'gz';
				$mime_type = 'application/x-gzip';
			} elseif(($bzip_on) && $compress=='bzip') {
				$ext = 'bz2';
				$mime_type = 'application/x-bzip';
	    	} else {
		    	$ext = 'sql';
				$mime_type = 'unknown/unknown';		
			}	    	

		    // Send headers
		    header('Content-Type: ' . $mime_type);
		    header('Content-Length: ' . strlen($dump));
		    header('Expires: ' . $now);

		    if(checkbrowser()=='IE') {
				//ie headers
				header('Content-Disposition: inline; filename="' . $sqlfile . '.' . $ext . '"');
				header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
				header('Pragma: public');
			} else {
				header('Content-Disposition: attachment; filename="' . $sqlfile . '.' . $ext . '"');
				header('Pragma: no-cache');
			}
			
			//download file
			if($compress=='gzip') {
				echo gzencode($dump);
			} elseif($compress=='bzip') {
				echo bzcompress($dump);
			} else {
				echo $dump;
			}
			exit();
		} else {
			require('./header_html.php');
			bar($bar_view_dump);
			if(!checkrestrictions('backup')) {
				message($lang_accessdenied, $lang_noaccessmsg);
			}

			$dump = htmlspecialchars($dump);
			$dump = nl2br($dump);
			include($templatefolder.'/admincp/showdump.dtf');
		}
	} else {
		require('./header_html.php');
		bar($bar_backup);
		if(!checkrestrictions('backup')) {
			message($lang_accessdenied, $lang_noaccessmsg);
		}
		
		include($templatefolder.'/admincp/backup.dtf');
	}
}

if($sub == "newsletter") {
	require('./header_html.php');
	bar($bar_newsletter);
	if(!checkrestrictions('newsletter')) {
		message($lang_accessdenied, $lang_noaccessmsg);
	}
	
	if($submit==$lang_send) {
		if($who=="all") {
			$add = " WHERE (username!='guest' && username!='invisible')";
		} elseif($who=="ad") {
			$add = " WHERE ((membercode='5'||membercode='4') && (username!='guest' && username!='invisible'))";
		} elseif($who=="admo") {
			$add = " WHERE ((membercode='5'||membercode='4'||membercode='3'||membercode='2') && (username!='guest' && username!='invisible'))";
		} elseif($who=="me") {
			$add = " WHERE (membercode='1' && username!='guest' && username!='invisible')";
		}

		$timenow = time();
		@ini_set('max_execution_time', '1000');
		@set_time_limit(1000);
		@ignore_user_abort(1);
		
		##preparing email function
		if($how=="email") {
			##getting headadmin email
			$getemail = $db->query("SELECT email FROM ".$prefix."users WHERE (username='".$settings['headadmin']."')");
			$heademail = $db->fetch_array($getemail);
			
			##Security Checks
			if(!isset($_SERVER['HTTP_USER_AGENT'])){
			   die("Forbidden - You are not authorized to view this page");
			}
			
			if(!$_SERVER['REQUEST_METHOD'] == "POST"){
			   die("Forbidden - You are not authorized to view this page");
			}
			
			##Server Conf.
			if(strtoupper(substr(PHP_OS, 0, 3) == 'WIN')) {
				$nl_tag = "\r\n";
			} elseif (strtoupper(substr(PHP_OS, 0, 3) == 'MAC')) {
				$nl_tag = "\r";
			} else {
				$nl_tag = "\n";
			}
			
			$headers = 'From: '.$settings['boardname'].' <'.$heademail['email'].'>'.$nl_tag;
			$headers .= 'Reply-To: '.$settings['boardname'].' <'.$heademail['email'].'>'.$nl_tag; 
			$headers .= 'X-Original-From: '.$settings['boardname'].$nl_tag;
			$headers .= 'X-Mailer: Deluxe Bulletin Board Mailer'.$nl_tag;
			$headers .= 'X-Sender: <'.$heademail['email'].'>'.$nl_tag;
			$headers .= 'X-AntiAbuse: Forum - '.$settings['boardname'].$nl_tag;
			$headers .= 'Return-Path: <'.$heademail['email'].'>'.$nl_tag;

			if($type!=$lang_default) {
				$headers .= 'MIME-version: 1.0'.$nl_tag;
				$headers .= 'Content-Type: text/html; charset='.$lang_charset;
			} else {
				$headers .= 'Content-Type: text/plain; charset='.$lang_charset;
			}
		}

		##Doing some non-html conversation
		if(($type!='html' && $settings['htmloff']==1) || ($type!='html' && $how=="email")) {
			$message = preg_replace('=<br */?>=i', "\n", $message);
			$message = preg_replace("/<\/?p(.|\s)*?>/i","\n",$message);
		} elseif($type!='html' && $how=="pm") {
		  $message = nl2br($message);
		}
    
    if($type=='html') {
      $message = $messagerichtext;
	  }
		
		$message = stripslashes($message);
		
		##gathering infos then sending pms/emails
		$query = $db->query("SELECT username,email FROM ".$prefix."users".$add);
		while($get = $db->fetch_array($query)) {
			$message2 = str_replace('$membername', "$get[username]", $message);			
			if($how=="pm") {
				$db->unbuffered_query("INSERT INTO ".$prefix."pm VALUES (NULL, '$get[username]', '".$_COOKIE['membercookie']."', '$subject', '$message2', 'exclamation.gif', 'no', '$timenow', 'inbox')");
			} elseif($how=="email") {
				$to = "<$get[email]>";
				mail($to, $subject, $message2, $headers);
			}
		}
		message($lang_successfullynewsletter, $lang_forwardadmincp, "admincp.php");
	} else {
		include($templatefolder.'/admincp/newsletter.dtf');
	}
}

if($sub == "restrict") {
	require('./header_html.php');
	bar($bar_admin_restrictions);
	if($_COOKIE['membercookie']!=$settings['headadmin']) {
		message($lang_highestseclevel, $lang_notheadadmin, "admincp.php");
		quit();
	}
	
	if(!isset($action)) {
		if(!isset($submit)) {
			include($templatefolder.'/admincp/restrict_header.dtf');
			
			// Getting a list of all administators
			$admins = "<select name=\"username\">\n\r";
			$query = $db->query("SELECT username FROM ".$prefix."users WHERE (membercode='4') ORDER BY username");
			##if no admin exists
			if($db->num_rows($query)==0) {
				$admins .= '<option value=""></option>';
			}
			while($array = $db->fetch_array($query)) {
				$admins .= "<option value=\"$array[username]\">$array[username]</option>\n\r";
			}
			$admins .= "</select>\n\r";
			
			// Displaying all profiles
			$query = $db->query("SELECT * FROM ".$prefix."restrictions");
			while($list = $db->fetch_array($query)) {
				if($list['name']!='default') {
					if($list['status']==1) {
						$status = $lang_on;
					} else {
						$status = $lang_off;
					}
				} else {
					$list['name'] = $lang_default;
					$status = $lang_globalsettings;
				}
				
				include($templatefolder.'/admincp/restrict_fields.dtf');
			}
			include($templatefolder.'/admincp/restrict_footer.dtf');		
		} elseif($submit==$lang_add) {
			if(empty($username)) {
				message($lang_missingfields, $lang_missingfieldsinfo);
				quit();
			}
			$query = $db->query("SELECT * FROM ".$prefix."restrictions WHERE (`name`='$username')");
			if($db->num_rows($query) > 0) {
				message($lang_restricterror, $lang_restrictexist);
				quit();
			}
			$db->unbuffered_query("INSERT INTO ".$prefix."restrictions (`name`, `status`) VALUES ('$username', '1')");
			message($lang_restrictionadded, $lang_forwardrestrictedit, "admincp.php?sub=restrict&action=edit&name=".urlencode($username), 4);
		} elseif($submit==$lang_delete) {
			for($x=0;$x<sizeof($delete);$x++) {
				$db->unbuffered_query("DELETE FROM ".$prefix."restrictions WHERE (name='".urldecode($delete[$x])."')");
			}
			message($lang_successfullydelrestr, $lang_forwardrestrmain, "admincp.php?sub=restrict");
		}
	} elseif($action=='edit') {
		if(!isset($submit)) {
			$query = $db->query("SELECT * FROM ".$prefix."restrictions WHERE (name='".urldecode($name)."')");
			$edit = $db->fetch_array($query);
			include($templatefolder.'/admincp/restrict_edit.dtf');
		} else {
			$db->unbuffered_query("UPDATE ".$prefix."restrictions SET `status`='$xstatus', `settings`='$xsettings', `editmember`='$xeditmember', `maintenance`='$xmaintenance', `skins`='$xskins', `editforum`='$xeditforum', `editposticons`='$xeditposticons', `editsmilies`='$xeditsmilies', `editcensors`='$xeditcensors', `ban`='$xban', `cplogopt`='$xcplogopt', `cplog`='$xcplog', `optimize`='$xoptimize', `exec`='$xexec', `pruneposts`='$xpruneposts', `prunepms`='$xprunepms', `backup`='$xbackup', `newsletter`='$xnewsletter', `attachsettings`='$attachsettings', `listattachments`='$listattachments', `userranks`='$userranks' WHERE (`name`='$xname')");
			message($lang_successfullyeditrestr, $lang_forwardrestrmain, "admincp.php?sub=restrict");
		}
	}
}

if($sub == "versioncheck") {
	require('./header_html.php');
	bar($bar_versioncheck);
	include($templatefolder.'/admincp/versioncheck.dtf');
}

if($sub == 'attachments') {
	require('./header_html.php');
	bar($bar_attachments);
	if(!checkrestrictions('listattachments')) {
		message($lang_accessdenied, $lang_noaccessmsg);
	}
	
	if($submit==$lang_list || $page!='') {
		//creating the query
		if($filename!='') {
			$filename = preg_replace("/[^\w\.]/", "_", $filename);
			$add = "&& a.filename LIKE '%$filename%'";
		}		
		if($user!='') {
			$add .= " && u.username='$user'";
		}
		if($forum!='all') {
			$add .= " && p.fid='$forum'";
		}
		if($sizemin!='') {
			$sizemin = $sizemin*1024;
			$add .= " && a.size>'$sizemin'";
		}
		if($sizemax!='') {
			$sizemax = $sizemax*1024;
			$add .= " && a.size<'$sizemax'";
		}
		if($countmin!='') {
			$add .= " && a.downloads>'$countmin'";
		}
		if($countmax!='') {
			$add .= " && a.downloads<'$countmax'";
		}
		if($ext!='') {
			$add .= " && a.downloads='$ext'";
		}
		
		if($order=='filename') {
			$ord = 'a.filename';
		} elseif($order=='username') {
			$ord = 'p.author';
		} elseif($order=='downloads') {
			$ord = 'a.downloads';
		} elseif($order=='size') {
			$ord = 'a.size';
		}
			
		//calculating the unixtime
		if($age!='beginning') {
			$stamp = time()-(86400*$age);
		} else {
			$stamp = 0;
		}
		
		//doing multipage
		$getnum = $db->query("SELECT COUNT(*)  FROM ".$prefix."attachments a LEFT JOIN ".$prefix."posts p ON (a.pid=p.pid) LEFT JOIN ".$prefix."users u ON (p.author=u.uid) WHERE (a.pid=p.pid && p.postdate>='$stamp' ".$add.")");
		$totalrows = $db->result($getnum, 0);
		$pageinfo = multipage($totalrows, $page, $settings['ompp'], 'admincp.php?sub=attachments', "&amp;filename=$filename&amp;user=$user&amp;forum=$forum&amp;sizemin=$sizemin&amp;sizemax=$sizemax&amp;countmin=$countmin&amp;countmax=$countmax&amp;ext=$ext&amp;order=$order&amp;age=$age");
			
		$query = $db->query("SELECT a.*,a.type AS thetype,p.*,u.username FROM ".$prefix."attachments a LEFT JOIN ".$prefix."posts p ON (a.pid=p.pid) LEFT JOIN ".$prefix."users u ON (p.author=u.uid) WHERE (a.pid=p.pid && p.postdate>='$stamp' ".$add.") ORDER BY ".$ord." ".$sort." LIMIT ".$pageinfo[0].",".$pageinfo[1]);
		
		include($templatefolder.'/admincp/attachments_header.dtf');	
		while($attach = $db->fetch_array($query)) {
			$size = number_format(($attach['size']/1024), 2).$lang_kilobytes;
			if(!value_exists($attach['author'])) {
				$attauthor = $lang_guest;
			} else {
				$attauthor = '<a href="misc.php?sub=profile&amp;uid='.$attach['author'].'">'.$attach['username'].'</a>';
			}
			include($templatefolder.'/admincp/attachments_fields.dtf');	
		}
		include($templatefolder.'/admincp/attachments_footer.dtf');	
	} elseif($submit==$lang_submitchanges) {
		for($x=0;$x<sizeof($delete);$x++) {
			$query = $db->query("SELECT a.*,p.postdate,u.username FROM ".$prefix."attachments a LEFT JOIN ".$prefix."posts p ON (a.pid=p.pid) LEFT JOIN ".$prefix."users u ON (p.author=u.uid) WHERE (a.pid=p.pid && p.pid='$delete[$x]')");
			$info = $db->fetch_array($query);
			
			$attachurl = $settings['attachdir'].$info['filename'].'-'.$info['postdate']. '.'.'ext';
			if(@unlink(@trim($attachurl)) || !file_exists($attachurl)) {
				$deleted = 1;
				$db->unbuffered_query("DELETE FROM ".$prefix."attachments WHERE (pid='$delete[$x]')");
			}
		}
		if($deleted==1) {
			message($lang_attachmentsdeleted, $lang_forwardadmincp, "admincp.php");
		} else {
			message($lang_attachmentsnotdel, $lang_forwardadmincp, "admincp.php");
		}
	} else {
		$query = $db->query("SELECT fid,name FROM ".$prefix."forums ORDER BY ordered");
		while($forums = $db->fetch_array($query)) {
			$forumlist .= "<option value=\"$forums[fid]\">".stripslashes($forums['name'])."</option>\n";
		}
		
		include($templatefolder.'/admincp/attachments.dtf');	
	}
}

if($sub == 'userranks') {
	require('./header_html.php');
	bar($bar_userranks);
	if(!checkrestrictions('userranks')) {
		message($lang_accessdenied, $lang_noaccessmsg);
	}
	
	if($submit!=$lang_update) {
		include($templatefolder.'/admincp/userranks_header.dtf');
		$query = $db->query("SELECT * FROM ".$prefix."ranks ORDER BY stars");
		while($list = $db->fetch_array($query)) {
			$disabled = '';
			if($list['title']=='Moderator' || $list['title']=='Super Moderator' || $list['title']=='Administrator' || $list['title']=='Head Admin') {
				$disabled = 'disabled="disabled"';
			}
			include($templatefolder.'/admincp/userranks_fields.dtf');
		}
		include($templatefolder.'/admincp/userranks_footer.dtf');	
	} else {
		//Deleting Ranks
		for($x=0;$x<sizeof($delete);$x++) {
			$db->unbuffered_query("DELETE FROM ".$prefix."ranks WHERE (rid='".$delete[$x]."')");
		}
		$query = $db->query("SELECT rid FROM ".$prefix."ranks");
		while($rank = $db->fetch_array($query)) {
			$ranktitle = "title$rank[rid]";
			$title = "${$ranktitle}";
			
			$rankposts = "posts$rank[rid]";
			$posts = "${$rankposts}";
			
			$rankstars = "stars$rank[rid]";
			$stars = "${$rankstars}";
			
			$rankstarimage = "starimage$rank[rid]";
			$starimage = "${$rankstarimage}";
			
			$rankallowavatar = "allowavatar$rank[rid]";
			$allowavatar = "${$rankallowavatar}";
			
			$rankallowsig = "allowsig$rank[rid]";
			$allowsig = "${$rankallowsig}";
			
			//Update Users
			if($title!='') {
				$title = $db->escape($title);
				$db->unbuffered_query("UPDATE ".$prefix."ranks SET title='$title', posts='$posts', stars='$stars', starimage='$starimage', allowavatar='$allowavatar', allowsig='$allowsig' WHERE (rid='$rank[rid]')");
			}
			//Update Mods & Admins
			if($rank[rid]>=7 && $rank[rid]<=10) {
				$db->unbuffered_query("UPDATE ".$prefix."ranks SET stars='$stars', starimage='$starimage', allowavatar='$allowavatar', allowsig='$allowsig' WHERE (rid='$rank[rid]')");
			}
		}
		if($newtitle!='') {
			$db->unbuffered_query("INSERT INTO ".$prefix."ranks (`title`, `posts`, `stars`, `starimage`, `allowavatar`, `allowsig`) VALUES ('$newtitle', '$newposts', '$newstars', '$newstarimage', '$newallowavatar', '$newallowsig')");
		}
		
		message($lang_rankeditsuccessfull, $lang_forwardrankedit, "admincp.php?sub=userranks");
	}	
}

include('./footer.php');

?>