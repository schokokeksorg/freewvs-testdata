<?php
require __DIR__ . '/deprecated.php';
