<?php
$PHORUM["DATA"]["LANG"]["mod_smileys"] = array(
    'smiley'        => 'Vložit smajlíka',
    'subjectsmiley' => 'Vložit smajlíka do předmětu',
    'smileys help'  => 'Smajlíky nápověda',

    # Text for the smileys disable option in the posting editor.
    'disable'      => 'Disable smileys for this message'
);
?>
