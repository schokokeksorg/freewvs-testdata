<?php

/************************************************
 * DeluxeBB 1.3                                 *
 * Copyright (C) 2005-2009 Frank Nissel         *
 * http://www.DeluxeBB.com	                    *
 * For license information, please read the     *
 * license file in the docs/ folder! 			      *
 ************************************************/


if(!$footer) {
	echo "</body></html>";
} else {
	$te = getmicrotime();
	$time = $te - $ts;
	$finalresult = number_format($time, 5);
	
/* removing the copyright message below is forbidden
   if we detect an abuse of our license (we have ways to do this) we will take further steps against you */
  include($templatefolder.'/footer_html.dtf');
}

if($settings['gzip']==1 && $settings['email_pro']==1) {
	gzout('pegz');
} elseif($settings['gzip']==1 && $settings['email_pro']==0) {
	gzout('gz');
} elseif($settings['gzip']==0 && $settings['email_pro']==1) {
	gzout('pe');
}
?>