<?php
namespace {
    die('Access denied');
}

namespace TYPO3\CMS\Frontend\View {
    class AdminPanelView extends \TYPO3\CMS\Adminpanel\View\AdminPanelView
    {
    }
    interface AdminPanelViewHookInterface extends \TYPO3\CMS\Adminpanel\View\AdminPanelViewHookInterface
    {
    }
}
