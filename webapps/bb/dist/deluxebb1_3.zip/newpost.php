<?php

/************************************************
 * DeluxeBB 1.3                                 *
 * Copyright (C) 2005-2009 Frank Nissel         *
 * http://www.DeluxeBB.com	                    *
 * For license information, please read the     *
 * license file in the docs/ folder! 			      *
 ************************************************/

$cssstyle = 'newpost.css';
require('./header.php');
$footer = TRUE;

##security checks
$fid = @intval($fid);
$tid = @intval($tid);
$disablesmilies = @intval($disablesmilies);

if($fid) {
	$getinfo = $db->query("SELECT fid,name,password,userlist,viewstatus,poststatus,replystatus,moderators,redirect FROM ".$prefix."forums WHERE (fid='$fid')");
} elseif($tid) {
	$getinfo = $db->query("SELECT f.fid,f.name,f.password,f.userlist,f.viewstatus,f.poststatus,f.replystatus,f.redirect,t.tid,t.subject,t.closed,t.pinned FROM ".$prefix."threads t, ".$prefix."forums f WHERE (f.fid=t.fid) && (t.tid='$tid')");
}
	
$info = $db->fetch_array($getinfo);

$temptitle = $lang_postnewmsg;
$where = 'Posting a new message in this forum: '.addslashes($info['name']);

if($info['password']!='') {
	if(!$_COOKIE['membercookie'] || $_COOKIE['membercookie']=='guest') {
		require('./header_html.php');
		bar($bar_seperator.'<a href="forums.php?fid='.$info['fid'].'">'.$info['name'].'</a>'.$bar_seperator.$bar_forum_restr);
    include($templatefolder.'/error_forum_restrictions.dtf');
    include('./footer.php');
    exit();
	}

	if($action == "pwverify") {
		if($pw != $info['password']) {
			require('./header_html.php');
			bar($bar_seperator.'<a href="forums.php?fid='.$info['fid'].'">'.$info['name'].'</a>'.$bar_seperator.$bar_wrong_pw);
			message($lang_badpassword, $lang_badpasswordinfo, "index.php");
			quit();
		} else {
			setcookie("fpw$info[fid]", $pw, time()+86400*7, $cp, $cd, $cs);
			redirect("topic.php?fid=$info[fid]&tid=$info[tid]", 1);
			exit();
		}
	}
	
	if($_COOKIE['fpw'.$info['fid']]=='' || $info['password']!=$_COOKIE['fpw'.$info['fid']]) {
		require('./header_html.php');
		bar($bar_seperator.'<a href="forums.php?fid='.$info['fid'].'">'.$info['name'].'</a>'.$bar_seperator.$bar_pw_req);
		include($templatefolder.'/enterpw.dtf');
		quit();
	}
}

require('./header_html.php');
cachelists();

##Loading preview of text
if($preview==$lang_preview) {
	##Caching Censors/Smilies
	bbcodecache();
	
	##doing user ranks
	if($settings['userranks']!=0) {
		##caching ranks
		prepareranks();
		
		$checktitle = '';
		switch ($member['membercode']) {
			case(2): $checktitle = "Moderator"; break;
			case(3): $checktitle = "Super Moderator"; break;
			case(4): $checktitle = "Administrator"; break;
			case(5): $checktitle = "Head Admin"; break;
		}

		if($checktitle!='') {
			$rankinfo = explode(",", $specialrank[$checktitle]);
		} elseif($member['uid'] == 0) {
			$rankinfo = '';
		} else {
			foreach ($userrank as $key => $rinfo) {
				if($member['posts'] >= $key) {
					$rankinfo = explode(",", $rinfo);
				}
			}
		}
	}
	
	##formating values
	##->escape function is used here to bring the escaping to an equal level
	$subjectpreview = $db->escape(trim($subject));
	$postpreview = $db->escape(removeEvilTags(trim($rte1)));
	$subject = removeEvilTags(html($db->escape(trim($subject))));
	$rte1 = $db->escape(removeEvilTags(trim($rte1)));
	$posticon = $db->escape(removeEvilTags(trim($posticon)));
	
	##formating message and subject
	if($settings['htmloff']!=0) {
		$postpreview = html($postpreview);
	}
	
	$subjectpreview = html($subjectpreview);
	##censor title
	if($settings['censors']!=0) {
		$subjectpreview = bbcode($subjectpreview, 1);
	}
	
	##check for existing formatting -> else use css defined value
	$formatted = 0;
	$formatarray = array('<font', '<span style', '<h1', '<h2', '<h3', '<h4', '<h5', '<h6', '<adress', '<pre', '<p');
		
	foreach($formatarray as $element) {
		if(stristr($postpreview, $element)) {
			$formatted++;
		}
	}
						
	if($formatted==0) {
		$postpreview= '<span class="topic">'.$postpreview.'</span>';
	}

	$postpreview = bbcode($postpreview,$disablesmilies);
}


if($sub == 'newthread') {
	//checking access
	if(!access($member['username'], $member['membercode'], $info['viewstatus'], $info['poststatus'], '', $info['userlist'])) {
		bar($bar_seperator.'<a href="forums.php?fid='.$info['fid'].'">'.$info['name'].'</a>'.$bar_seperator.$bar_no_post_perm);
		include($templatefolder.'/error_forum_restrictions.dtf');
    include('./footer.php');
    exit();
	}
	
	//settings for guests
	if(!$_COOKIE['membercookie'] || !$_COOKIE['memberid']) {
		$_COOKIE['membercookie'] = 'guest';
		$_COOKIE['memberid'] = 0;
	}
	
	//the nav bar
	bar($bar_seperator.'<a href="forums.php?fid='.$info['fid'].'">'.$info['name'].'</a>'.$bar_seperator.$lang_postingnewthread);

	//handling redirected forums
	if($info['redirect']!='') {
		message($lang_forumredirection, $lang_forumredirectiontxt, $info['redirect'], 4);
		quit();
	}
	
	##Previewing the post?
	if($preview==$lang_preview) {
		$postpreview = stripslashes($postpreview);
		$subjectpreview = stripslashes($subjectpreview);		
		include($templatefolder.'/preview.dtf');
		$message = $rte1;
	}
	
	if($submit==$lang_post) {
		##formatting post and subject
		##subject needs the html function, the wysiwyg does this automatically for the post!
		$subject = removeEvilTags(html($db->escape(trim($subject))));
		$post = $db->escape(removeEvilTags(trim($rte1)));
		
		if(!value_exists($subject) || !value_exists($post)) {
			message($lang_missingfields, $lang_missingfieldsinfo);
		}
		
		if($settings['htmloff']!=0) {
			$post = html($post);
		}

		//spam protection
		$query = $db->query("SELECT lastpidtime,lastpostby FROM ".$prefix."forums WHERE (fid='$info[fid]')");
		$floodctrl = $db->fetch_array($query);
		$now = $time - $settings['floodctrl'];
		if($now<=$floodctrl['lastpidtime'] && $_COOKIE['memberid']==$floodctrl['lastpostby']) {
			message($lang_floodctrlerror);
			quit();
		}
		
		@extract($_FILES);
		$fileupload['name'] = utf8_decode($fileupload['name']);
		//attachment error handling
		while(stristr($fileupload['name'], '.php')) {
			$fileupload['name'] = str_replace('.php', '', $fileupload['name']);
		}
		
		if($fileupload['name'] != "none" && !empty($fileupload['name']) && @is_uploaded_file($fileupload['tmp_name'])) {
			$attachment = 1;
			$ext = str_replace('.', '', strrchr($fileupload['name'],'.'));
			$filename = preg_replace("/[^\w\.]/", "_", substr("$fileupload[name]", 0, strlen($fileupload['name'])-strlen($ext)-1));
			
			if(preg_match("/\.(cgi|pl|js|asp|php|html|htm|jsp|shtml|dhtml|vb)/", $fileupload['name'])) {
				$fileupload['type'] = 'text/plain';
			}

			if(!stristr($settings['attachtypes'], $ext)) {
				message($lang_uploadfailed, $lang_filetypewrong);
			}
			
			if($fileupload['size']>$settings['attachmaxsize']) {
				message($lang_uploadfailed, $lang_filetoobig);
				quit();
			}
		}
		
		//setting pinned and locked values
		if(!empty($pinned) && $member['membercode']>=2) {
			$pin = 1;
		}
		if(!empty($locked) && $member['membercode']>=2) {
			$lock = 1;
		}
		$pin = @intval($pin);
		$lock = @intval($lock);
		$posticon = $db->escape($posticon);

		//inserting thread
		$db->unbuffered_query("INSERT INTO ".$prefix."threads VALUES (NULL, '$info[fid]', '".$_COOKIE['memberid']."', '$subject', '$posticon', '0', '0', '$lock', '$pin', '0', '".htmlspecialchars($_COOKIE['membercookie'])."', '$time')");
		$tid = $db->insert_id();
		
		//inserting post
		$db->unbuffered_query("INSERT INTO ".$prefix."posts VALUES (NULL, '$tid', '".$_COOKIE['memberid']."', '$subject', '$post', '$posticon', '$time', '$ip', '$disablesmilies')");
		$pid = $db->insert_id();
		
		//updating forum
		$db->unbuffered_query("UPDATE ".$prefix."forums SET topics=topics+1, lastpost='$subject', lastpostby='".$_COOKIE['memberid']."', lastpid='$tid', lastpidtime='$time' WHERE (fid='$info[fid]')");
		
		//updating user stats
		$db->unbuffered_query("UPDATE ".$prefix."users SET posts=posts+1, lastpost='$time' WHERE (uid='".$_COOKIE['memberid']."')");
		
		//uploading attachment
		if($attachment==1 && $settings['allowattach']==1) {
			$saveit = $settings['attachdir'] . $filename . '-' . $time . '.' . 'ext';

			copy($fileupload['tmp_name'], $saveit);
			$db->unbuffered_query("INSERT INTO `".$prefix."attachments` ( `aid` , `pid` , `filename` , `ext` , `type` , `size` , `downloads` ) VALUES (NULL, '$pid', '".utf8_encode($filename)."', '$ext', '$fileupload[type]', '$fileupload[size]', '0')");
		}
		
		//printing out a message
		message($lang_successfullyposted, $lang_forwardtopicview, "topic.php?fid=$info[fid]&tid=$tid");
	} else {
		##As the data was submitted by a form it has been escaped so we need to remove those slashes
		##The textbox is being prepared by the rtesafe function in the template
		$subject = stripslashes($subject);
		include($templatefolder.'/posting.dtf');
	}
}

if($sub == 'newpost') {	
	//checking access
	if(!access($member['username'], $member['membercode'], $info['viewstatus'], '', $info['replystatus'], $info['userlist'])) {
		bar($bar_seperator.'<a href="forums.php?fid='.$info['fid'].'">'.$info['name'].'</a>'.$bar_seperator.'<a href="topic.php?tid='.$info['tid'].'">'.$info['subject'].'</a>'.$bar_seperator.$bar_no_post_perm);
		include($templatefolder.'/error_forum_restrictions.dtf');
    include('./footer.php');
    exit();
	}
	
	//caching censors
	if($settings['censors']!=0) {
		bbcodecache();
		$info['subject'] = bbcode($info['subject'], 1);
	}

	//the bar
	bar($bar_seperator.'<a href="forums.php?fid='.$info['fid'].'">'.$info['name'].'</a>'.$bar_seperator.$info['subject']);

	//handling redirected forums
	if($info['redirect']!='') {
		message($lang_forumredirection, $lang_forumredirectiontxt, $info['redirect'], 4);
		quit();
	}
	
	//topic error handling and spam protection
	if($info['closed']==1) {
		message($lang_lockedthread, $lang_lockedthreadinfo);
		quit();
	}
	
	//guest info
	if(!$_COOKIE['membercookie'] || !$_COOKIE['memberid']) {
		$_COOKIE['membercookie'] = 'guest';
		$_COOKIE['memberid'] = 0;
	}
	
	##Previewing the post?
	if($preview==$lang_preview) {
		$postpreview = stripslashes($postpreview);
		$subjectpreview = stripslashes($subjectpreview);
		include($templatefolder.'/preview.dtf');
		$message = $rte1;
	}

	if($submit==$lang_post) {
		//spam protection
		$query = $db->query("SELECT lastpidtime,lastpostby FROM ".$prefix."forums WHERE (fid='$info[fid]')");
		$floodctrl = $db->fetch_array($query);
		$now = time() - $settings['floodctrl'];
		if($now<=$floodctrl['lastpidtime'] && $_COOKIE['memberid']==$floodctrl['lastpostby']) {
			message($lang_floodctrlerror);
			quit();
		}
		
		@extract($_FILES);
		$fileupload['name'] = utf8_decode($fileupload['name']);
		
		//attachment error handling
		while(stristr($fileupload['name'], '.php')) {
			$fileupload['name'] = str_replace('.php', '', $fileupload['name']);
		}
		
		if($fileupload['name'] != "none" && !empty($fileupload['name']) && @is_uploaded_file($fileupload['tmp_name'])) {
			$attachment = 1;
			$ext = str_replace('.', '', strrchr($fileupload['name'],'.'));
			$filename = preg_replace("/[^\w\.]/", "_", substr("$fileupload[name]", 0, strlen($fileupload['name'])-strlen($ext)-1));
			
			if(preg_match("/\.(cgi|pl|js|asp|php|html|htm|jsp|shtml|dhtml|vb)/", $fileupload['name'])) {
				$fileupload['type'] = 'text/plain';
			}
			
			if(!stristr($settings['attachtypes'], $ext)) {
				message($lang_uploadfailed, $lang_filetypewrong);
			}
			
			if($fileupload['size']>$settings['attachmaxsize']) {
				message($lang_uploadfailed, $lang_filetoobig);
				quit();
			}
		}

    ##linebreak for quickreply
    if($nl2br && $settings['htmloff']==0) {
		  $rte1 = nl2br(html($rte1));
    }

		//formating values
		$subject = removeEvilTags(html($db->escape(trim($subject))));
		$post = $db->escape(removeEvilTags(trim($rte1)));
		$posticon = $db->escape($posticon);
		
		if(!value_exists($post)) {
			message($lang_missingfields, $lang_missingfieldsinfo);
		}
		
		if($settings['htmloff']!=0) {
			$post = html($post);
		}

		//set thread to pinned/closed
		if($pinned!=$info['pinned'] && $member['membercode']>=2) {
			$pinned = @intval($pinned);
			$db->unbuffered_query("UPDATE ".$prefix."threads SET pinned='$pinned' WHERE (tid='$tid')");
		} 
		if($locked!=$info['closed'] && $member['membercode']>=2) {
			$locked = @intval($locked);
			$db->unbuffered_query("UPDATE ".$prefix."threads SET closed='$locked' WHERE (tid='$tid')");
		}

		//inserting post
		$db->query("INSERT INTO ".$prefix."posts VALUES (NULL, '$tid', '".$_COOKIE['memberid']."', '$subject', '$post', '$posticon', '$time', '$ip', '$disablesmilies')");
		$pid = $db->insert_id();
		
		//updating thread info
		$db->unbuffered_query("UPDATE ".$prefix."threads SET replies=replies+1, lastpostdate='$time', lastpostby='".htmlspecialchars($_COOKIE['membercookie'])."' WHERE (tid='$tid')");
		
		//updating forum info
		$db->unbuffered_query("UPDATE ".$prefix."forums SET replies=replies+1, lastpid='$tid', lastpost='$subject', lastpostby='".$_COOKIE['memberid']."', lastpidtime='$time' WHERE (fid='$info[fid]')");
		
		//updating user info
		$db->unbuffered_query("UPDATE ".$prefix."users SET posts=posts+1, lastpost='$time' WHERE (uid='".$_COOKIE['memberid']."')");
		
		//uploading attachment
		if($attachment==1 && $settings['allowattach']==1) {
			$saveit = $settings['attachdir'] . $filename . '-' . $time . '.' . 'ext';

			copy($fileupload['tmp_name'], $saveit);
			$db->unbuffered_query("INSERT INTO `".$prefix."attachments` ( `aid` , `pid` , `filename` , `ext` , `type` , `size` , `downloads` ) VALUES (NULL, '$pid', '".utf8_encode($filename)."', '$ext', '$fileupload[type]', '$fileupload[size]', '0')");
		}
		
		//sending out emails (subscriptions)
		$query = $db->query("SELECT s.*,u.username,u.email FROM ".$prefix."subscriptions s LEFT JOIN ".$prefix."users u ON (u.uid=s.uid) WHERE (s.tid='$tid')");
		while($subscription = $db->fetch_array($query)) {
			if($subscription['checked']!=0 && $subscription['uid']!=$_COOKIE['memberid']) {
				$db->unbuffered_query("UPDATE ".$prefix."subscriptions SET pid='$pid' WHERE (tid='$tid')");
				
				##Security Checks
				if(!isset($_SERVER['HTTP_USER_AGENT'])){
				   die("Forbidden - You are not authorized to view this page");
				}
				
				if(!$_SERVER['REQUEST_METHOD'] == "POST"){
				   die("Forbidden - You are not authorized to view this page");
				}
				
				##Server Conf.
				if(strtoupper(substr(PHP_OS, 0, 3) == 'WIN')) {
					$nl_tag = "\r\n";
				} elseif (strtoupper(substr(PHP_OS, 0, 3) == 'MAC')) {
					$nl_tag = "\r";
				} else {
					$nl_tag = "\n";
				}
				
				$url = $fullpath.'topic.php?tid='.$tid.'#'.$pid;
				
				##Fix for guest
				if($member['email']=='') {
					$member['email'] = 'dontreply@anycommunity.test';
				}

				##headers for email
				$headers = 'From: '.$member['username'].' <'.$member['email'].'>'.$nl_tag;
				$headers .= 'Reply-To: '.$member['username'].' <'.$member['email'].'>'.$nl_tag; 
				$headers .= 'X-Original-From: '.$settings['boardname'].$nl_tag;
				$headers .= 'X-Mailer: Deluxe Bulletin Board Mailer'.$nl_tag;
				$headers .= 'X-Sender: <'.$member['username'].'>'.$nl_tag;
				$headers .= 'X-AntiAbuse: Forum - '.$settings['boardname'].$nl_tag;
				$headers .= 'Return-Path: <'.$member['username'].'>'.$nl_tag;
				$headers .= 'Content-Type: text/plain; charset='.$lang_charset;

				@mail("$subscription[email]", "$lang_subemailtitle \"$info[subject]\"", "$lang_subemailtxt1 $subscription[username]$lang_subemailtxt2".$_COOKIE['membercookie']."$lang_subemailtxt3 \"$info[subject]\" $lang_subemailtxt4 $url $lang_subemailtxt5 $settings[boardname] $lang_subemailtxt6", $headers);
			}
			$db->unbuffered_query("UPDATE ".$prefix."subscriptions SET checked=0, pid='$pid' WHERE (uid='$subscription[uid]' && tid='$tid')");
		}

		$getreplies = $db->query("SELECT replies FROM ".$prefix."threads WHERE (tid='$info[tid]')");
		$replies = $db->result($getreplies, 0);
		$pagenum = ceil(($replies+1)/$settings['tppt']);

		message($lang_successfullyposted, $lang_forwardtopicview, "topic.php?fid=$info[fid]&tid=$tid&page=$pagenum");
	} else {
		if(isset($reply)) {
			$reply = @intval($reply);
			
			//quote someone
			$quotemessage = $db->query("SELECT p.message,p.subject,u.username FROM ".$prefix."posts p LEFT JOIN ".$prefix."users u ON (p.author=u.uid) WHERE (pid='$reply')");
			$the = $db->fetch_array($quotemessage);
			
			if($settings['htmloff']!=1) {
				##check for existing formatting -> else use css defined value
				$formatted = 0;
				$formatarray = array('<font', '<span style', '<h1', '<h2', '<h3', '<h4', '<h5', '<h6', '<adress', '<pre', '<p');
					
				foreach($formatarray as $element) {
					if(stristr($the['message'], $element)) {
						$formatted++;
					}
				}
									
				if($formatted==0) {
					$the['message']= '<span class="topic">'.$the['message'].'</span>';
				}

				$message = '<span class="misctext"><strong>&nbsp;&nbsp;&nbsp;'.$lang_quote.' '.$the['username'].'</strong></span><br /><table align="center" class="quote" width="90%"><tbody><tr><td>'.addslashes($the['message']).'</td></tr></tbody></table><br /><br />';
			} else {
				$message = "Quote:\n".addslashes($the['message'])."\n\n";
			}
			$subject = 'Re: '.addslashes($the['subject']);
		}
		
		##remove escaping chars from form
		$subject = stripslashes($subject);
		
		include($templatefolder.'/postreply.dtf');
		
		if($preview!=$lang_preview) {
			bbcodecache();
		}

		//show recent posts
		$threads = $db->query("SELECT u.username,u.membercode,u.posts,u.joineddate,u.customtitle,p.* FROM ".$prefix."posts p LEFT JOIN ".$prefix."users u ON (u.uid=p.author) WHERE (p.tid='$tid') ORDER BY p.postdate DESC LIMIT 0, $settings[tppt]");
		
		$avatar = '';
		$sig = '';

		while($open = $db->fetch_array($threads)) {
			$joineddate = gmdate($datecode, $open['joineddate'] + ($member['timeoffset'] * 3600));
			$time = gmdate($timecode, $open['postdate'] + ($member['timeoffset'] * 3600));
			$date = gmdate($datecode, $open['postdate'] + ($member['timeoffset'] * 3600));
			$posttime = "$date $lang_at $time";
			
			if($settings['htmloff']!=0) {
				$open['message'] = html($open['message']);
			}
			$open['subject'] = html($open['subject']);
			
			$message = bbcode($open['message'], $open['smiliesoff']);
			
			$customtitle = $open['customtitle'];
			if(modcheck($open['username'], $open['membercode'], $info['moderators'])) {
				$customtitle .= '<br />Moderating this forum';
			}		

			include($templatefolder.'/topicbreak.dtf');
			include($templatefolder.'/topics_light.dtf');
			$avatar = '';
			$sig = '';
		}
		include($templatefolder.'/topicbreak.dtf');
	}
}

if($sub == 'editpost') {
	$pid = @intval($pid);
	$getinfo = $db->query("SELECT t.tid,t.subject,t.closed,t.pinned,f.fid,f.name,f.poststatus,f.replystatus,f.moderators FROM ".$prefix."threads t LEFT JOIN ".$prefix."forums f ON (t.fid=f.fid) WHERE (tid='$tid')");
	$info = $db->fetch_array($getinfo);
	
	//caching censors
	if($settings['censors']!=0) {
		bbcodecache();
		$info['subject'] = bbcode($info['subject'], 1);
	}

	bar($bar_seperator.'<a href="forums.php?fid='.$info['fid'].'">'.$info['name'].'</a>'.$bar_seperator.'<a href="topic.php?tid='.$info['tid'].'">'.$info['subject'].'</a>'.$bar_seperator.$lang_edit);
	
	$getauthor = $db->query("SELECT u.uid,u.username,u.membercode FROM ".$prefix."posts p LEFT JOIN ".$prefix."users u ON (u.uid=p.author) WHERE (pid='$pid')");
	$author = $db->fetch_array($getauthor);
	// check permissions
	if(!$member['membercode'] || $member['membercode']=='' || $member['membercode']==0) {
		$perm=0;
	} elseif($member['membercode']==1 && ($settings['useredit']==0 || $_COOKIE['membercookie']!=$author['username'])) {
		$perm=0;
	} elseif(($member['membercode']==2 || $member['membercode']==3) && ($author['membercode']==4 || $author['membercode']==5)) {
		$perm=0;
	} elseif($member['membercode']==2 && !stristr($info['moderators'], $_COOKIE['membercookie']) && $_COOKIE['membercookie']!=$author['username']) {
		$perm=0;
	} elseif($info['poststatus']=='no' && $info['replystatus']=='no') {
		$perm=0;
	} else {
		$perm=1;
	}
	
	//if no authorization print a message
	if($perm==0) {
		message($lang_notallowedtoperform, $lang_ucancontactadmin);
		quit();
	}
	
	//handling redirected forums
	if($info['redirect']!='') {
		message($lang_forumredirection, $lang_forumredirectiontxt, $info['redirect'], 4);
		quit();
	}

	//check if thread is closed
	if($info['closed']==1) {
		message($lang_lockedthread, $lang_editlockedpost);
		quit();
	}
	
	//if first post in thread -> special db actions
	$check = $db->query("SELECT pid FROM ".$prefix."posts WHERE (tid='$tid') ORDER BY postdate ASC LIMIT 1");
	if($pid==$db->result($check)) {
		$firstp = 1;
	}
	
	##Previewing the post?
	if($preview==$lang_preview) {
		include($templatefolder.'/preview.dtf');
		$message = $rte1;
	}

	if($submit==$lang_post) {
		//delete thread/post
		if(!empty($delete)) {
			$check = $db->query("SELECT * FROM ".$prefix."posts WHERE (tid='$tid')");
			if($db->num_rows($check)<=1 || $firstp==1) {
				$x = -1; //-1 instead of 0 to fix thread info is being counted
				##deleting thread info
				$db->unbuffered_query("DELETE FROM ".$prefix."threads WHERE (tid='$tid')");
				##updating user post count
				$getusers = $db->query("SELECT u.uid,p.pid FROM ".$prefix."posts p LEFT JOIN ".$prefix."users u ON (p.author=u.uid) WHERE (p.tid='$tid')");
				while($fix = $db->fetch_array($getusers)) {
					##updating user profile
					$db->unbuffered_query("UPDATE ".$prefix."users SET posts=posts-1 WHERE (uid='$fix[uid]')");
					$x++;
					##deleting attachments
					$query = $db->query("SELECT a.filename,p.postdate FROM ".$prefix."attachments a LEFT JOIN ".$prefix."posts p ON (a.pid=p.pid) LEFT JOIN ".$prefix."users u ON (p.author=u.uid) WHERE (a.pid=p.pid && p.pid='$fix[pid]')");
					if($db->num_rows($query)!=0) {
						$theinfo = $db->fetch_array($query);
						$attachurl = $settings['attachdir'].utf8_decode($theinfo['filename']).'-'.$theinfo['postdate']. '.'.'ext';
						if(@unlink(@trim($attachurl)) || !file_exists($attachurl)) {
							$db->unbuffered_query("DELETE FROM ".$prefix."attachments WHERE (pid='$fix[pid]')");
						}
					}
				}
				##deleting posts
				$db->unbuffered_query("DELETE FROM ".$prefix."posts WHERE (tid='$tid')");
				$db->unbuffered_query("DELETE FROM ".$prefix."posts_archive WHERE (tid='$tid')");
				##deleting a possible redirection link
				$db->unbuffered_query("DELETE FROM ".$prefix."threads WHERE (moved='$tid')");
				
				##updating forum stats
				$getlp = $db->query("SELECT tid,subject,lastpostdate,lastpostby FROM ".$prefix."threads WHERE (fid='$info[fid]') ORDER BY lastpostdate DESC LIMIT 1");
				$lpinfo = $db->fetch_array($getlp);
				if(!$lpinfo['tid']) {
					$db->unbuffered_query("UPDATE ".$prefix."forums SET topics=0, replies=0, lastpost=NULL, lastpostby='0', lastpid='', lastpidtime='' WHERE (fid='$info[fid]')");
				} else {
				  if($lpinfo['lastpostby']=='guest') {
            $getlpuid = 0;
          } else {
          	$getlpuid = $db->query("SELECT uid FROM ".$prefix."users WHERE username='".$lpinfo['lastpostby']."'");
          }
					$db->unbuffered_query("UPDATE ".$prefix."forums SET topics=topics-1, replies=replies-".$x.", lastpost='".$db->escape($lpinfo['subject'])."', lastpostby='".$db->result($getlpuid)."', lastpid='$lpinfo[tid]', lastpidtime='$lpinfo[lastpostdate]' WHERE (fid='$info[fid]')");
				}
				
				##thread has been deleted -> forward to forums.php
				$forward_forum = 1;
			} else {
				##getting complete thread data for the page calculation before the post is deleted
				$getreplies = $db->query("SELECT pid FROM ".$prefix."posts WHERE (tid='$tid') ORDER BY pid ASC");
				
				##deleting attachment
				$query = $db->query("SELECT a.filename,p.postdate FROM ".$prefix."attachments a LEFT JOIN ".$prefix."posts p ON (a.pid=p.pid) LEFT JOIN ".$prefix."users u ON (p.author=u.uid) WHERE (a.pid=p.pid && p.pid='$pid')");
				if($db->num_rows($query)!=0) {
					$info = $db->fetch_array($query);
					$attachurl = $settings['attachdir'].utf8_decode($info['filename']).'-'.$info['postdate']. '.'.'ext';
					if(@unlink(@trim($attachurl)) || !file_exists($attachurl)) {
						$db->unbuffered_query("DELETE FROM ".$prefix."attachments WHERE (pid='$pid')");
					}
				}
				##deleting post
				$db->unbuffered_query("DELETE FROM ".$prefix."posts WHERE (pid='$pid')");
				$db->unbuffered_query("DELETE FROM ".$prefix."posts_archive WHERE (pid='$pid')");
				
        //correcting stats
				##thead
				$query = $db->query("SELECT u.username,p.postdate FROM ".$prefix."posts p LEFT JOIN ".$prefix."users u ON (p.author=u.uid) WHERE (p.tid='$tid') ORDER BY p.postdate DESC LIMIT 1");
				$newthreaddata = $db->fetch_array($query);
				if($newthreaddata['username']=='') {
					$newthreaddata['username']='guest';
				}
				$db->unbuffered_query("UPDATE ".$prefix."threads SET replies=replies-1, lastpostby='".$newthreaddata['username']."', lastpostdate='".$newthreaddata['postdate']."' WHERE (tid='$tid')");
				##user
				$db->unbuffered_query("UPDATE ".$prefix."users SET posts=posts-1 WHERE (uid='$author[uid]')");
				##forum
				$db->unbuffered_query("UPDATE ".$prefix."forums SET replies=replies-1 WHERE (fid='$info[fid]')");
				
				##updating forum stats
				$getlp = $db->query("SELECT tid,subject,lastpostdate,lastpostby FROM ".$prefix."threads WHERE (fid='$info[fid]') ORDER BY lastpostdate DESC LIMIT 1");
				$lpinfo = $db->fetch_array($getlp);
				if(!$lpinfo['tid']) {
					$db->unbuffered_query("UPDATE ".$prefix."forums SET topics=0, replies=0, lastpost=NULL, lastpostby='0', lastpid='', lastpidtime='' WHERE (fid='$info[fid]')");
				} else {
				  if($lpinfo['lastpostby']=='guest') {
            $getlpuid = 0;
          } else {
          	$getlpuid = $db->query("SELECT uid FROM ".$prefix."users WHERE username='".$lpinfo['lastpostby']."'");
          }
					$db->unbuffered_query("UPDATE ".$prefix."forums SET lastpost='".$db->escape($lpinfo['subject'])."', lastpostby='".$db->result($getlpuid)."', lastpid='$lpinfo[tid]', lastpidtime='$lpinfo[lastpostdate]' WHERE (fid='$info[fid]')");
				}
				
				##page calculation
				$x=0;
				while($replies = $db->fetch_array($getreplies)) {
					if($replies['pid']==$pid) {
						break;
					}
					$x++;
				}
				$pagenum = ceil($x/$settings['tppt']);
			}			
		} else {
			//pin/unpin thread
			if(!empty($pinned) && $member['membercode']>=2) {
				$db->unbuffered_query("UPDATE ".$prefix."threads SET pinned='1' WHERE (tid='$tid')");
			} else {
				$db->unbuffered_query("UPDATE ".$prefix."threads SET pinned='0' WHERE (tid='$tid')");
			}
			//close/open thread
			if(!empty($locked) && $member['membercode']>=2) {
				$db->unbuffered_query("UPDATE ".$prefix."threads SET closed='1' WHERE (tid='$tid')");
			} else {
				$db->unbuffered_query("UPDATE ".$prefix."threads SET closed='0' WHERE (tid='$tid')");
			}
			
			
			@extract($_FILES);
			$fileupload['name'] = utf8_decode($fileupload['name']);
			
			//delete attachment
			if($deleteatt || !empty($fileupload['name'])) {
  			$query = $db->query("SELECT a.aid,a.filename,p.postdate FROM ".$prefix."attachments a LEFT JOIN ".$prefix."posts p ON (a.pid=p.pid) LEFT JOIN ".$prefix."users u ON (p.author=u.uid) WHERE (a.pid=p.pid && p.pid='$pid')");
  			if($db->num_rows($query)!=0) {
  				$theinfo = $db->fetch_array($query);
  				$attachurl = $settings['attachdir'].utf8_decode($theinfo['filename']).'-'.$theinfo['postdate']. '.'.'ext';
  				if((@unlink(@trim($attachurl)) || !file_exists($attachurl))) {
  				  if($deleteatt) {
  				  	$db->unbuffered_query("DELETE FROM ".$prefix."attachments WHERE (pid='$pid')");
  				  }
  				}
  			}

    		//attachment error handling
    		while(stristr($fileupload['name'], '.php')) {
    			$fileupload['name'] = str_replace('.php', '', $fileupload['name']);
    		}
    		
    		if($fileupload['name'] != "none" && !empty($fileupload['name']) && @is_uploaded_file($fileupload['tmp_name'])) {
    			$attachment = 1;
    			$ext = str_replace('.', '', strrchr($fileupload['name'],'.'));
    			$filename = preg_replace("/[^\w\.]/", "_", substr("$fileupload[name]", 0, strlen($fileupload['name'])-strlen($ext)-1));
    			
    			if(preg_match("/\.(cgi|pl|js|asp|php|html|htm|jsp|shtml|dhtml|vb)/", $fileupload['name'])) {
    				$fileupload['type'] = 'text/plain';
    			}
    			
    			if(!stristr($settings['attachtypes'], $ext)) {
    				message($lang_uploadfailed, $lang_filetypewrong);
    			}
    			
    			if($fileupload['size']>$settings['attachmaxsize']) {
    				message($lang_uploadfailed, $lang_filetoobig);
    				quit();
    			}
    		}
    		
      	//uploading attachment
    		if($attachment==1 && $settings['allowattach']==1) {
    			$saveit = $settings['attachdir'] . $filename . '-' . $theinfo['postdate'] . '.' . 'ext';
    
    			copy($fileupload['tmp_name'], $saveit);
    			if($deleteatt) {
      			$db->unbuffered_query("INSERT INTO `".$prefix."attachments` ( `aid` , `pid` , `filename` , `ext` , `type` , `size` , `downloads` ) VALUES (NULL, '$pid', '$filename', '$ext', '$fileupload[type]', '$fileupload[size]', '0')");
    		  } else {
    		   	$db->unbuffered_query("UPDATE `".$prefix."attachments` SET filename='".utf8_encode($filename)."', ext='$ext', type='$fileupload[type]', size='$fileupload[size]' WHERE aid='$theinfo[aid]'");
    		  }
        }
  	 	}
			//updating post
			$subject = removeEvilTags(html($db->escape(trim($subject))));
			$post = $db->escape(removeEvilTags(trim($rte1)));

			$date = gmdate($datecode, $time + ($member['timeoffset'] * 3600));
			$time = gmdate($timecode, $time + ($member['timeoffset'] * 3600));
			$todaydate = "$date - $time";
			if($settings['editby']==1) {
				if($settings['htmloff']==0) {
					if($settings['edithistory']==1) {
						$edithostorytext = ' <a href="topic.php?sub=showhistory&amp;tid='.$tid.'&amp;pid='.$pid.'">('.$lang_showedithistory.')</a>';
					} else {
						$edithostorytext = '';
					}
					$post .= '<br /><br /><br /><span style="font-style: italic;">'.$lang_editedby.' '.$_COOKIE['membercookie'].' @ '.$todaydate.$edithostorytext.'</span>';
				} else {
					$post .= "\n\n\n $lang_editedby ".$_COOKIE['membercookie']." @ $todaydate";
				}
			}

			//edit history activated?
			if($settings['edithistory']==1) {
				$orgexist = $db->query("SELECT pid FROM ".$prefix."posts_archive WHERE (pid='$pid')");
				if(!$db->result($orgexist)) {
					$getoriginal = $db->query("SELECT * FROM ".$prefix."posts WHERE (pid='$pid')");
					$original = $db->fetch_array($getoriginal);
					
					$db->unbuffered_query("INSERT INTO ".$prefix."posts_archive VALUES ('$original[pid]', '$original[tid]', '$original[author]', '$original[subject]', '$original[message]', '$original[postdate]', '$original[smiliesoff]')");
				}
				
				$db->unbuffered_query("INSERT INTO ".$prefix."posts_archive VALUES ('$pid', '$tid', '".$_COOKIE['memberid']."', '$subject', '$post', '".time()."', '$disablesmilies')");
			}
			
			$db->unbuffered_query("UPDATE ".$prefix."posts SET message='$post', subject='$subject', picon='$posticon', smiliesoff='$disablesmilies' WHERE (tid='$tid' && pid='$pid')"); 
			
			$getreplies = $db->query("SELECT pid FROM ".$prefix."posts WHERE (tid='$tid') ORDER BY pid ASC");
			$x=0;
			while($replies = $db->fetch_array($getreplies)) {
				if($replies['pid']==$pid) {
					break;
				}
				$x++;
			}
			$pagenum = ceil(($x+1)/$settings['tppt']);
			
			//if first post in thread, threadtitle needs to be changed!
			if($firstp==1 && $subject!='') {
				$db->unbuffered_query("UPDATE ".$prefix."threads SET subject='$subject', picon='$posticon' WHERE (tid='$tid')"); 
			}
		}
		if(!$forward_forum) {
			message($lang_successfullyedited, $lang_forwardtopicview, "topic.php?tid=$tid&page=$pagenum");
		} else {
			message($lang_successfullyedited, $lang_forwardlastforumview, "forums.php?fid=$info[fid]");
		}
	} else {
		if($message=='') {
      $editmessage= $db->query("SELECT a.*,p.message,p.subject,p.smiliesoff,p.picon,t.closed,t.pinned FROM ".$prefix."threads t LEFT JOIN ".$prefix."posts p ON (p.tid=t.tid) LEFT JOIN ".$prefix."attachments a ON (a.pid=p.pid) WHERE (p.tid='$tid' && p.pid='$pid')");
			$edit = $db->fetch_array($editmessage);
			$message = addslashes($edit['message']);
			$subject=$edit['subject'];
		}
		include($templatefolder.'/postreply.dtf');
	}
}

include('./footer.php');

?>