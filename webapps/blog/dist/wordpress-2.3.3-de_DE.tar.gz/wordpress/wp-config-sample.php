<?php
// ** MySQL Einstellungen ** //
define('DB_NAME', 'Name_der_Datenbank');    // Der Name der Datenbank
define('DB_USER', 'MySQL_Benutzername');     // Ihr MySQL-Benutzername
define('DB_PASSWORD', 'MySQL_Passwort'); // Sowie das MySQL-Passwort
define('DB_HOST', 'localhost');    // Diesen Parameter m�ssen Sie in den allermeisten F�llen nicht �ndern
define('DB_CHARSET', 'utf8');
define('DB_COLLATE', '');

// Wenn Sie mehrere WordPress-Installationen in einer Datenbank haben,
// muss jede Installation ein eigenes "Tabellenpr�fix" bekommen
$table_prefix  = 'wp_';   // Bitte nur Zahlen, Buchstaben und/oder Unterstriche

// �ndern Sie den folgenden Parameter, wenn Sie eine �bersetzte Version von
// WordPress nutzen m�chten. F�r die gew�nschte Sprache muss eine MO-Datei in
// wp-content/languages liegen.
// Installieren Sie beispielsweise de_DE.mo in wp-content/languages und
// setzen Sie WPLANG auf 'de_DE', um WordPress auf deutsch zu haben.
define ('WPLANG', 'de_DE');

/* Ab hier sind keine weiteren �nderungen notwendig. Viel Spa� beim Bloggen! */

define('ABSPATH', dirname(__FILE__).'/');
require_once(ABSPATH.'wp-settings.php');
?>