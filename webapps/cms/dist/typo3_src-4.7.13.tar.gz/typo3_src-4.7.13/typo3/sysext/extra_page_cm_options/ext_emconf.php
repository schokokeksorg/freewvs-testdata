<?php

/***************************************************************
 * Extension Manager/Repository config file for ext "extra_page_cm_options".
 *
 * Auto generated 12-11-2012 19:48
 *
 * Manual updates:
 * Only the data in the array - everything else is removed by next
 * writing. "version" and "dependencies" must not be touched!
 ***************************************************************/

$EM_CONF[$_EXTKEY] = array(
	'title' => 'Extra Click Menu Options',
	'description' => 'Adds a submenu with extra options for page and tt_content click-menus.',
	'category' => 'be',
	'shy' => 1,
	'dependencies' => '',
	'conflicts' => '',
	'priority' => '',
	'loadOrder' => '',
	'module' => '',
	'doNotLoadInFE' => 1,
	'state' => 'stable',
	'internal' => 0,
	'uploadfolder' => 0,
	'createDirs' => '',
	'modify_tables' => '',
	'clearCacheOnLoad' => 0,
	'lockType' => '',
	'author' => 'Kasper Skaarhoj',
	'author_email' => 'kasperYYYY@typo3.com',
	'author_company' => 'Curby Soft Multimedia',
	'CGLcompliance' => '',
	'CGLcompliance_note' => '',
	'version' => '4.7.7',
	'_md5_values_when_last_written' => 'a:4:{s:31:"class.tx_extrapagecmoptions.php";s:4:"acf5";s:12:"ext_icon.gif";s:4:"955b";s:14:"ext_tables.php";s:4:"ac39";s:13:"locallang.xlf";s:4:"db7f";}',
	'constraints' => array(
		'depends' => array(
			'php' => '5.3.0-0.0.0',
			'typo3' => '4.7.0-0.0.0',
		),
		'conflicts' => array(
		),
		'suggests' => array(
		),
	),
	'suggests' => array(
	),
);

?>