<?php

if (! isset($wp_did_header)):
if ( !file_exists( dirname(__FILE__) . '/wp-config.php') ) {
	if (strpos($_SERVER['PHP_SELF'], 'wp-admin') !== false) $path = '';
	else $path = 'wp-admin/';

	require_once( dirname(__FILE__) . '/wp-includes/classes.php');
	require_once( dirname(__FILE__) . '/wp-includes/functions.php');
	require_once( dirname(__FILE__) . '/wp-includes/plugin.php');
	wp_die("Offenbar fehlt die Datei <code>wp-config.php</code>. WordPress braucht diese Datei zum Starten. Hilfe zu diesem Thema finden Sie <a href='http://codex.wordpress.org/Editing_wp-config.php'>im WordPress-Codex</a>. Sie k&ouml;nnen auch <a href='{$path}setup-config.php'>die <code>wp-config.php</code> online &uuml;ber einen Assistenten erstellen</a>, allerdings funktioniert dieser nicht auf allen Servern. Der sicherst Weg ist, die Datei manuell zu erstellen.", "WordPress &rsaquo; Fehler");
}

$wp_did_header = true;

require_once( dirname(__FILE__) . '/wp-config.php');

wp();
gzip_compression();

require_once(ABSPATH . WPINC . '/template-loader.php');

endif;
?>