<?php

/************************************************
 * DeluxeBB 1.3                                 *
 * Copyright (C) 2005-2009 Frank Nissel         *
 * http://www.DeluxeBB.com	                    *
 * For license information, please read the     *
 * license file in the docs/ folder! 			      *
 ************************************************/

$cssstyle = 'topic.css';
require('./header.php');

$tid = @intval($tid);

##guests allowed to see topics?
if($settings['guestforumview']==0 && usercheck()==FALSE) {
	require('./header_html.php');
	bar($bar_unknown_thread);
	message($lang_guestnoaccess, $lang_guestnoaccess2);
	quit();
}

$getinfo = $db->query("SELECT t.tid,t.subject,t.replies,t.closed,t.pinned,f.fid,f.name,f.password,f.userlist,f.viewstatus,f.poststatus,f.replystatus,f.moderators,f.redirect FROM ".$prefix."threads t, ".$prefix."forums f WHERE (t.fid=f.fid) && (t.tid='$tid') GROUP BY t.tid");
$info = $db->fetch_array($getinfo);

$temptitle = "$info[name] - $info[subject]";
$where = 'Viewing a topic: '.$db->escape($info['subject']);

##censoring
if($settings['censors']!=0) {
	bbcodecache();
	$info['subject'] = bbcode($info['subject'], 1);
}

if($topicseperatorimage!="") {
	$topicseperatorimage=$images."/".$topicseperatorimage;
} 

//security checks
if($info['password']!='') {
	if(!$_COOKIE['membercookie'] || $_COOKIE['membercookie']=='guest') {
		require('./header_html.php');
		$footer = FALSE;
		bar($bar_seperator.'<a href="forums.php?fid='.$info['fid'].'">'.$info['name'].'</a>'.$bar_seperator.$bar_forum_restr);
		include($templatefolder.'/error_forum_restrictions.dtf');
		quit();
	}

	if($action == 'pwverify') {
		if($pw != $info['password']) {
			require('./header_html.php');
			bar($bar_seperator.'<a href="forums.php?fid='.$info['fid'].'">'.$info['name'].'</a>'.$bar_seperator.$bar_wrong_pw);
			message($lang_badpassword, $lang_badpasswordinfo, "index.php");
			quit();
		} else {
			setcookie("fpw$info[fid]", $pw, time()+86400*7, $cp, $cd, $cs);
			redirect("topic.php?tid=$tid", 1);
			exit();
		}
	}
	
	if($_COOKIE['fpw'.$info['fid']]=='' || $info['password']!=$_COOKIE['fpw'.$info['fid']]) {
		require('./header_html.php');
		bar($bar_seperator.'<a href="forums.php?fid='.$info['fid'].'">'.$info['name'].'</a>'.$bar_seperator.$bar_pw_req);
		include($templatefolder.'/enterpw.dtf');
		quit();
	}
}

##checking if tid exists
if((!$tid && !$sub) || $info['fid']=='') {
	require('./header_html.php');
	bar($bar_unknown_thread);
	message($lang_topic_not_exist, $lang_forwardlastforumview, "forums.php?fid=$info[fid]");
	quit();
}

##checking if user has access to topic
if(!access($member['username'], $member['membercode'], $info['viewstatus'], '', '', $info['userlist'])) {
	require('./header_html.php');
	bar($bar_seperator.'<a href="forums.php?fid='.$info['fid'].'">'.$info['name'].'</a>'.$bar_seperator.'<a href="topic.php?tid='.$info['tid'].'">'.$info['subject'].'</a>'.$bar_seperator.$bar_forum_restr);
	$footer = FALSE;
	include($templatefolder.'/error_forum_restrictions.dtf');
	quit();
}
//security checks end

//handling redirected forums
if($info['redirect']!='') {
	message($lang_forumredirection, $lang_forumredirectiontxt, $info['redirect'], 4);
	quit();
}

if(!$sub) {
	//marking thread as read
	lastvisit();
	
	//header
	require('./header_html.php');
	
	//updating hits
	$db->unbuffered_query("UPDATE ".$prefix."threads SET views=views+1 WHERE (tid='$tid')");
	$db->unbuffered_query("UPDATE ".$prefix."subscriptions SET checked=1 WHERE (tid='$tid' && uid='".$_COOKIE['memberid']."')");

	bar($bar_seperator.'<a href="forums.php?fid='.$info['fid'].'">'.$info['name'].'</a>'.$bar_seperator.$info['subject']);
	
	//calculating pages and navigation
	if($lastpost==1) {
		$page = ceil(($info['replies']+1)/$settings['tppt']);
	}
	$pageinfo = multipage($info['replies']+1, $page, $settings['tppt'], "topic.php?tid=$tid"); //+1 is for thread
	include($templatefolder.'/topic_header.dtf');

	//getting all post now
	$threads = $db->query("SELECT a.*,u.username,u.membercode,u.posts,u.customtitle,u.avatar,u.sig,u.joineddate,u.email,u.hideemail,u.icq,u.aim,u.msn,u.yim,u.site,p.* FROM ".$prefix."posts p LEFT JOIN ".$prefix."users u ON u.uid=p.author LEFT JOIN ".$prefix."attachments a ON a.pid=p.pid WHERE (p.tid='$tid') GROUP BY p.pid ORDER BY p.postdate LIMIT $pageinfo[0], $pageinfo[1]");

	//resetting values
	$avatar = '';
	$sig = '';
	$mod = '';

	//loading up bb code
	bbcodecache();

	//caching ranks
	prepareranks();
	
	//init topicstarter
	$x = 0;
	
	//displaying posts
	while($open = $db->fetch_array($threads)) {
		include($templatefolder.'/topicbreak.dtf');
	
		//user ranks
		if($settings['userranks']!=0) {
			$checktitle = '';
			switch ($open['membercode']) {
				case(2): $checktitle = "Moderator"; break;
				case(3): $checktitle = "Super Moderator"; break;
				case(4): $checktitle = "Administrator"; break;
				case(5): $checktitle = "Head Admin"; break;
			}
	
			if($checktitle!='') {
				$rankinfo = explode(",", $specialrank[$checktitle]);
			} elseif($open['author'] == 0) {
				$rankinfo = '';
			} else {
				foreach ($userrank as $key => $rinfo) {
					if($open['posts'] >= $key) {
						$rankinfo = explode(",", $rinfo);
					}
				}
			}
		}
		
		//formatting avatar
		if($rankinfo[4]!=0 || $settings['userranks']==0) {
			if($open['avatar']!='') {
				$open['avatar'] = '<img src="'.$open['avatar'].'" alt="Avatar" />';
			} else {
				$open['avatar'] = '';
			}
		}
		
		//formatting sig
		if($rankinfo[5]!=0 || $settings['userranks']==0) {
			if($open['sig']!='') {
				if($settings['sightml']!=1) {
					$donewline = 1; //now the bbcode function adds newline tags
					$open['sig'] = html($open['sig']);
				}
				$open['sig'] = bbcode($open['sig']);

				//check for existing formatting -> else use css defined value
				$formatted = 0;
				$formatarray = array('<font', '<span style', '<h1', '<h2', '<h3', '<h4', '<h5', '<h6', '<adress', '<pre', '<p');
		
				foreach($formatarray as $element) {
					if(stristr($open['sig'], $element)) {
						$formatted++;
					}
				}
						
				if($formatted==0) {
					$open['sig']= '<span class="misctext">'.$open['sig'].'</span>';
				}

				$sig = "<br /><br /><br /><hr style=\"height: 1px;\" size=\"1px\" />".$open['sig'];
			}
		}
		
		//formatting urls
		if(!stristr($open['site'], 'http://') && !stristr($open['site'], 'https://') && !stristr($open['site'], 'ftp://') && $open['site']!='') {
			$open['site'] = 'http://'.$open['site'];
		}
		//formatting dates
		$joineddate = gmdate($datecode, $open['joineddate'] + ($member['timeoffset'] * 3600));
		$time = gmdate($timecode, $open['postdate'] + ($member['timeoffset'] * 3600));
		$date = gmdate($datecode, $open['postdate'] + ($member['timeoffset'] * 3600));
		$posttime = "$date $lang_at $time";
		
		//formating message and subject
		if($settings['htmloff']!=0) {
			$open['message'] = html($open['message']);
		}
	
		//check for existing formatting -> else use css defined value
		$formatted = 0;
		$formatarray = array('<font', '<span style', '<h1', '<h2', '<h3', '<h4', '<h5', '<h6', '<adress', '<pre', '<p');

		foreach($formatarray as $element) {
			if(stristr($open['message'], $element)) {
				$formatted++;
			}
		}
		
		if($formatted==0) {
			$open['message']= '<span class="topic">'.$open['message'].'</span>';
		}

		$message = bbcode($open['message'],$open['smiliesoff']);
		$open['subject'] = bbcode($open['subject']);

		//checking for mods
		$customtitle = $open['customtitle'];
		if(modcheck($open['username'], $open['membercode'], $info['moderators'])) {
			$customtitle .= "<br />$lang_modthisforum";
		}

		//get attachments
		if($open['aid']!='') {
			$attachurl = $settings['attachdir'].utf8_decode($open['filename']).'-'.$open['postdate']. '.'.'ext';
			if($settings['attachimgpost']==1 && in_array(strtolower($open['ext']), array('bmp', 'gif', 'jpg', 'jpeg', 'png', 'tif', 'tiff'))) {
				if($avatarsize = @getimagesize($attachurl)) {
					$message .= '<span class="topic"><br /><br /><br />'.$lang_attachedimage.'<br /><br /><a href="javascript:display(\''.utf8_encode($attachurl).'\')"><img src="'.utf8_encode($attachurl).'" alt="Attached image" /></a></span>';					
				}
			} else {
				$message .= "<span class=\"topic\"><br /><br /><br />$lang_attachment <a href=\"topic.php?sub=attachment&tid=$open[tid]&pid=$open[pid]&filename=".$open[filename]."\">$open[filename].$open[ext]</a><br />$lang_downloadcount1 $open[downloads] $lang_downloadcount2</span>";
			}
		}
		
		//preparing output of topic page
		if($open['membercode']==1) {
			if($rankinfo[0]!='') {
				$status = $rankinfo[0];
			} else {
				$status = $lang_member;
			}
		} elseif($open['membercode']==2) {
			$status = $lang_moderator;
		} elseif($open['membercode']==3) {
			$status = $lang_supermoderator;
		} elseif($open['membercode']==4) {
			$status = $lang_administrator;
		} elseif($open['membercode']==5) {
			$status = $lang_administrator;
		} else {
			$status = $lang_anonymoususer;
		}
		
		if($open['username']=='') {
			$username = $lang_guest;
		} else {
			$username = '<a href="misc.php?sub=profile&amp;uid='.$open['author'].'">'.$open['username'].'</a>';
		}
		
		if($open['customtitle']!='') {
			$usertitle = $open['customtitle'].'<br />';
		} else {
			$usertitle = '';
		}
		
		//topic starter
		if(($x==0 || $open['author']==$topicstarter) && $open['author']!=0 && $settings['topicstarter']==1) {
      if($open['author']==$topicstarter) {
        $usertitle .= '<strong>'.$lang_topicstarter.'</strong><br /><br />';
      } else {
        $topicstarter = $open['author'];
        $x++;
        $usertitle .= '<br />';
      }
    } else {
      $usertitle .= '<br />';
    }
		
		for($i=0; $i<$rankinfo[2]; $i++) {
			$usertitle .= '<img src="'.$images.'/'.$rankinfo[3].'" alt="Star" />';
		}
		
		if($rankinfo[4]!=0 || $settings['userranks']==0) {
			$useravatar = $open['avatar'];
		} else {
			$useravatar = '';
		}
		
		if($open['author']!=0) { 
			$userposts = "$lang_posts $open[posts]";
		} else {
			$userposts = '';
		}
		
		if($open['author']!=0) {
			$userjoined = "$lang_joined $joineddate";
		} else {
			$userjoined = '';
		}
		
		if($open['author']!=0) {
			$userbuttons = '<a href="misc.php?sub=profile&amp;uid='.$open['author'].'"><img src="'.$images.'/userbuttons/profile.gif" alt="Profile" /></a>&nbsp;'; 
			if($open['hideemail']==0) {
				$userbuttons .= '<a href="mailto:'.$open['email'].'"><img src="'.$images.'/userbuttons/email.gif" alt="Email" /></a>&nbsp;'; 
			} elseif($open['hideemail']==2) {
				$userbuttons .= '<a href="misc.php?sub=emailuser&amp;uid='.$open['author'].'"><img src="'.$images.'/userbuttons/email.gif" alt="Email" /></a>&nbsp;';
			} 
			if($open['site']!='') {
				$userbuttons .= '<a href="'.$open['site'].'" target="blank"><img src="'.$images.'/userbuttons/site.gif" alt="Site" /></a>&nbsp;';
			} 
			if($settings['allowpm']==1) {
				$userbuttons .= '<a href="pm.php?sub=newpm&amp;uid='.$open['author'].'"><img src="'.$images.'/userbuttons/pm.gif" alt="PM" /></a>&nbsp;';
			}
		} else {
   		 	$userbuttons = '<img src="'.$images.'/blank.gif" alt=" " />';
		}

		include($templatefolder.'/topics.dtf');
		$avatar = '';
		$sig = '';
		$bgcolor = $nextbg;
	}
	$bgcolor = '';
	include($templatefolder.'/topicbreak.dtf');
	
	/* Rules */
	if($showrules) {
		if(!access($member['username'], $member['membercode'], $info['viewstatus'], $info['poststatus'], '', '')) {
			$rules = $lang_maynotpost."<br />";
		} else {
			$rules = $lang_maypost."<br />";
		}

		if(!access($member['username'], $member['membercode'], $info['viewstatus'], '', $info['replystatus'], '')) {
			$rules .= $lang_maynotreply."<br />";
		} else {
			$rules .= $lang_mayreply."<br />";
		}

		if((($settings['useredit']==1 && $_COOKIE['membercookie']!='') || $member['membercode']>1) && ($info['poststatus']!='no' && $info['replystatus']!='no')) {
			$rules .= $lang_mayedit;
		} else {
			$rules .= $lang_maynotedit;
		}

		if($settings['htmloff']==0) {
			$features = $lang_htmlenabled.'<br />';
		} else {
			$features = $lang_htmldisabled.'<br />';
		}
	
		if($settings['smilies']==1) {
			$features .= $lang_smilieson.'<br />';
		} else {
			$features .= $lang_smiliesoff.'<br />';
		}
		
		if($settings['allowattach']==1) {
			$features .= $lang_attachenabled;
		} else {
			$features .= $lang_attachdisabled;
		}
	}
		
	if(modcheck($member['username'], $member['membercode'], $info['moderators'], 1)) {
		$mod=1;
	}
	
	include($templatefolder.'/topic_footer.dtf');
}

//download an attachment
if($sub == 'attachment') {
	$query = $db->query("SELECT a.*,p.postdate FROM ".$prefix."attachments AS a, ".$prefix."posts AS p WHERE (a.pid=p.pid && p.pid='$pid' && a.filename='".$filename."')");
	$info = $db->fetch_array($query);
	
	$db->unbuffered_query("UPDATE ".$prefix."attachments SET downloads=downloads+1 WHERE (pid='$pid')");
	
	$attachurl = $settings['attachdir'].utf8_decode($info['filename']).'-'.$info['postdate']. '.'.'ext';
	
	if(checkbrowser() == 'IE' || checkbrowser() == 'OPERA') {
		$mime_type = 'application/octetstream';
  } else {
		$mime_type = 'application/octet-stream';
	}
	
	header('Content-Type: '.$mime_type.'; charset="utf-8"');
	
	if(checkbrowser() == 'IE') {
		header('Content-Disposition: inline; filename="' . utf8_decode($info['filename']) . '.' . $info['ext'] . '"');
		header("Content-Transfer-Encoding: binary");
		header('Expires: 0');
		header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
		header('Pragma: public');

	} else {
		header('Content-Disposition: attachment; filename="' . utf8_decode($info['filename']) . '.' . $info['ext'] . '"');
    header("Content-Transfer-Encoding: binary");
		header('Expires: 0');
		header('Pragma: no-cache');
	}
		
	@readfile($attachurl);
	exit();
}
	
//viewing an ip
if($sub == 'viewip' && isset($tid) && isset($pid)) {
	$pid = @intval($pid);
	require('./header_html.php');
	bar($bar_seperator.'<a href="forums.php?fid='.$info['fid'].'">'.$info['name'].'</a>'.$bar_seperator.'<a href="topic.php?tid='.$info['tid'].'">'.$info['subject'].'</a>'.$bar_seperator.$bar_viewing_ip);

	if($member['membercode']>=2) {
		$getip = $db->query("SELECT ip FROM ".$prefix."posts WHERE (pid='$pid')");
		$theip = $db->result($getip, 0);
		##several ips
		if(strstr($theip, ', ')) {
			$ipx = $theip;
			$ips = explode(', ', $theip);
			for($x=0;$x<sizeof($ips);$x++) {
				if(@gethostbyaddr($ips[$x])!=$ips[$x] && @gethostbyaddr($ips[$x])!==FALSE) {
					$hostinfo = @gethostbyaddr($ips[$x]);
				} else {
					$hostinfo = $lang_hostadr_error;
				}
			}
		##cloaked ip
		} elseif($theip=='unknown') {
			$ipx = $lang_unknown_ip;
			$hostinfo = $lang_hostadr_error;
		} else {
			$ipx = $theip;
			if(@gethostbyaddr($ipx)!=$ipx && @gethostbyaddr($ipx)!==FALSE) {
				$hostinfo = @gethostbyaddr($ipx);
			} else {
				$hostinfo = $lang_hostadr_error;
			}
		}
		$footer = FALSE;
		include($templatefolder.'/admincp/viewip.dtf');
	} else {
		$footer = FALSE;
		include($templatefolder.'/error_forum_restrictions.dtf');
	}
}

// reporting an user
if($sub == 'report' && isset($tid) && isset($pid)) {
	$pid = @intval($pid);
	require('./header_html.php');
	bar($bar_seperator.'<a href="forums.php?fid='.$info['fid'].'">'.$info['name'].'</a>'.$bar_seperator.'<a href="topic.php?tid='.$info['tid'].'">'.$info['subject'].'</a>'.$bar_seperator.$bar_reporting);
	if($submit==$lang_send) {
		$timenow = time();
		$reason = $db->escape($reason);
		if($settings['htmloff']==0) {
			$msg = '<a href="topic.php?tid='.$tid.'#'.$pid.'">'.$lang_directlink.'</a><br />'.$lang_author.' '.$author.'<br /><br />'.$reason;
		} else {
			$msg = $lang_directlink.': '.$fullpath."topic.php?tid=$tid#$pid\n$lang_author $author\n\n$reason";
		}
		if(usercheck()) {
			$db->unbuffered_query("INSERT INTO ".$prefix."pm VALUES (NULL, '$settings[headadmin]', '".$_COOKIE['membercookie']."', 'Reporting a post', '$msg', 'exclamation.gif', 'no', '$timenow', 'inbox')");
		} else {
			message($lang_wronguserorpass, $lang_wronguserorpassinfo, "misc.php?sub=login");
			quit();
		}
		message($lang_successfullyreported, $lang_forwardlastthread, "topic.php?tid=$tid");
	} else {
		$getauthor = $db->query("SELECT u.username FROM ".$prefix."users u LEFT JOIN ".$prefix."posts p ON (p.author=u.uid) WHERE (pid='$pid')");
		$author = $db->result($getauthor, 0);
		
		include($templatefolder.'/report.dtf');
	}
}

// subscription
if($sub == 'subscribe' && isset($tid)) {
	require('./header_html.php');
	##handle guests
	if(!$_COOKIE['membercookie'] || $_COOKIE['membercookie']=='') {
		bar($bar_seperator.'<a href="forums.php?fid='.$info['fid'].'">'.$info['name'].'</a>'.$bar_seperator.'<a href="topic.php?tid='.$info['tid'].'">'.$info['subject'].'</a>'.$bar_seperator.$bar_subscribing);
		$footer = FALSE;
		include($templatefolder.'/error_forum_restrictions.dtf');
		quit();
	}
	bar($bar_seperator.'<a href="forums.php?fid='.$info['fid'].'">'.$info['name'].'</a>'.$bar_seperator.'<a href="topic.php?tid='.$info['tid'].'">'.$info['subject'].'</a>'.$bar_seperator.$bar_subscribing);
	
	$check = $db->query("SELECT * FROM ".$prefix."subscriptions WHERE (uid='".$_COOKIE['memberid']."' && tid='$tid')");
	//subscribing
	if($db->result($check, 0)==0) {
		$getpid = $db->query("SELECT MAX(pid) FROM ".$prefix."posts WHERE (tid='$tid')");
		$maxpid = $db->result($getpid, 0);
		$db->unbuffered_query("INSERT INTO ".$prefix."subscriptions VALUES ('$tid', '$maxpid', '".$_COOKIE['memberid']."', '0')");
		message($lang_successfullysubscribed, $lang_forwardlastthread, "topic.php?tid=$tid");
	//Unsubscribing
	} else {
		message($lang_subscrexists, $lang_forwardsubscrcp, "cp.php");
	}
}

// print view
if($sub == 'print' && isset($tid)) {
	$title = "$settings[boardname] - $temptitle --- powered by DeluxeBB";
	include($templatefolder.'/print_header.dtf');
	
	$threads = $db->query("SELECT a.*,u.username,u.membercode,u.posts,u.customtitle,u.avatar,u.sig,u.joineddate,u.email,u.hideemail,u.icq,u.aim,u.msn,u.yim,p.* FROM ".$prefix."posts p LEFT JOIN ".$prefix."users u ON u.uid=p.author LEFT JOIN ".$prefix."attachments a ON a.pid=p.pid WHERE (p.tid='$tid') GROUP BY p.pid ORDER BY p.postdate");

	//resetting values
	$avatar = '';
	$sig = '';
	$mod = '';

	bbcodecache();

	//displaying posts
	while($open = $db->fetch_array($threads)) {
		//formatting dates
		$joineddate = gmdate($datecode, $open['joineddate'] + ($member['timeoffset'] * 3600));
		$time = gmdate($timecode, $open['postdate'] + ($member['timeoffset'] * 3600));
		$date = gmdate($datecode, $open['postdate'] + ($member['timeoffset'] * 3600));
		$posttime = "$date $lang_at $time";
		//formating message and subject
		$open['subject'] = removeEvilTags($open['subject']); //translating html chars
		$message = bbcode($open['message'], $open['smiliesoff']);
		
		//checking for mods
		$customtitle = $open['customtitle'];
		if(modcheck($open['username'], $open['membercode'], $info['moderators'])) {
			$customtitle .= "<br />$lang_modthisforum";
		}
		echo '<hr style="color:'.$tablebordercolor.'; background-color:'.$tablebordercolor.'; height:1px; width:'.$tablewidth.';" size="1px" />';

		include($templatefolder.'/print_fields.dtf');
		$avatar = '';
		$sig = '';
	}
	$bgcolor = '';
	echo '<hr style="color:'.$tablebordercolor.'; background-color:'.$tablebordercolor.'; height:1px; width:'.$tablewidth.';" size="1px" />';
	
}

if($sub=='showhistory' && isset($pid)) {
	$pid = @intval($pid);
	$x = 0;
	
	require('./header_html.php');
	bar($bar_seperator.'<a href="forums.php?fid='.$info['fid'].'">'.$info['name'].'</a>'.$bar_seperator.'<a href="topic.php?tid='.$info['tid'].'">'.$info['subject'].'</a>'.$bar_seperator.$lang_edithistory);

	if($settings['edithistory']==0) {
		message($lang_function_disabled);
	}

	include($templatefolder.'/edithistory_header.dtf');
			
	$getchanges = $db->query("SELECT * FROM ".$prefix."posts_archive WHERE (pid='$pid') ORDER BY postdate");
	while($version = $db->fetch_array($getchanges)) {
		$x++;
		
		//formating message and subject
		if($settings['htmloff']!=0) {
			$version['message'] = html($version['message']);
		}
		
		//time of edit
		$time = gmdate($timecode, $version['postdate'] + ($member['timeoffset'] * 3600));
		$date = gmdate($datecode, $version['postdate'] + ($member['timeoffset'] * 3600));
		$posttime = "$date $lang_at $time";
	
		//check for existing formatting -> else use css defined value
		$formatted = 0;
		$formatarray = array('<font', '<span style', '<h1', '<h2', '<h3', '<h4', '<h5', '<h6', '<adress', '<pre', '<p');

		foreach($formatarray as $element) {
			if(stristr($version['message'], $element)) {
				$formatted++;
			}
		}
				
		if($formatted==0) {
			$version['message']= '<span class="topic">'.$version['message'].'</span>';
		}
		
		$version['message'] = bbcode($version['message'],$version['smiliesoff']);
		$version['subject'] = bbcode($version['subject']);
		include($templatefolder.'/edithistory_fields.dtf');
	}
	include($templatefolder.'/edithistory_footer.dtf');
	//$footer = FALSE;
}
	
include('./footer.php');

?>