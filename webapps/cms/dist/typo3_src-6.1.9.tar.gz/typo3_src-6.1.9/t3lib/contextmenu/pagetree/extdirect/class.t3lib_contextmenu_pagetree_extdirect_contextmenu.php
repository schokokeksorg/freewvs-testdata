<?php
/*
 * @deprecated since 6.0, the classname t3lib_contextmenu_pagetree_extdirect_ContextMenu and this file is obsolete
 * and will be removed with 6.2. The class was renamed and is now located at:
 * typo3/sysext/backend/Classes/ContextMenu/Pagetree/Extdirect/ContextMenuConfiguration.php
 */
require_once \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath('backend') . 'Classes/ContextMenu/Pagetree/Extdirect/ContextMenuConfiguration.php';
?>