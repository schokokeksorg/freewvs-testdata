<div id="content">
  {snippet:notices}

  <section id="box-page" class="box">
    <?php echo $content; ?>
  </section>

</div>