<?php
/*
 * @deprecated since 6.0, the classname t3lib_cacheHash and this file is obsolete
 * and will be removed with 6.2. The class was renamed and is now located at:
 * typo3/sysext/frontend/Classes/Page/CacheHashCalculator.php
 */
require_once \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath('frontend') . 'Classes/Page/CacheHashCalculator.php';
?>