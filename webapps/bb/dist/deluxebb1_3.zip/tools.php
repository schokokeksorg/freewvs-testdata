<?php

/************************************************
 * DeluxeBB 1.3                                 *
 * Copyright (C) 2005-2009 Frank Nissel         *
 * http://www.DeluxeBB.com	                    *
 * For license information, please read the     *
 * license file in the docs/ folder! 			      *
 ************************************************/


/* function updating online users */
function online($where, $alwaysinvisible) {
	global $db, $prefix, $ip, $_COOKIE, $invisible;
	$where = $db->escape($where);
	$time = time();
	if($invisible==1 || $alwaysinvisible==1) {
		$storemembercookie = $_COOKIE['membercookie'];
		$_COOKIE['membercookie'] = 'invisible';
	}
	if($_COOKIE['membercookie']!='') {
		$query = $db->query("SELECT name FROM ".$prefix."online WHERE (name='".$_COOKIE['membercookie']."')");
		$update = $db->fetch_array($query);
		if($update['name']!='') {
			$db->unbuffered_query("UPDATE ".$prefix."online SET time='$time', wherein='$where' WHERE (name='".$_COOKIE['membercookie']."')");
		} else {
			$db->unbuffered_query("INSERT INTO ".$prefix."online VALUES ('".$_COOKIE['membercookie']."', '$time', '$where', '$ip')");
		}
	} else {
		$query = $db->query("SELECT ip FROM ".$prefix."online WHERE (ip='$ip')");
		$update = $db->result($query);
		if($update['ip']!='') {
			$db->unbuffered_query("UPDATE ".$prefix."online SET time='$time', wherein='$where', name='guest' WHERE (ip='$ip' && name='guest')");
		} else {
			$db->unbuffered_query("INSERT INTO ".$prefix."online VALUES ('guest', '$time', '$where', '$ip')");
		}
	}
	$minutes = 15;
	$getonline = $db->query("SELECT name,time,ip FROM ".$prefix."online");
	$expirytime = $time - ($minutes * 60);

	while($expired = $db->fetch_array($getonline)) {
		if($expirytime > $expired['time']) {
			$db->unbuffered_query("DELETE from ".$prefix."online WHERE (ip='$expired[ip]' || name='$expired[name]') && time<='$expirytime'");
		}
	}
	if($invisible==1 || $alwaysinvisible==1) {
		$_COOKIE['membercookie'] = $storemembercookie;
	}
}

/* get micro time */
function getmicrotime() { 
    list($usec, $sec) = explode(" ",microtime()); 
    return ((float)$usec + (float)$sec); 
}

/* generate a random password */
function generatepw($min, $max, $type=0) {
	global $newpass;
	for($i=0;$i<rand($min,$max);$i++) {
		$num = rand(48,122);
		if(($num > 97 && $num < 122)) {
			$newpass.=chr($num);
		} else if(($num > 65 && $num < 90)) {
			$newpass.=chr($num);
		} else if(($num > 48 && $num < 57)) {
			$newpass.=chr($num);
		} else if($num == 95) {
			$newpass.=chr($num);
		} else {
			$i--;
		} 
	}

	if($type==0) {
		return md5($newpass);
	} elseif($type==1) {
		return $newpass;
	}
}

/* bb code parser */
function bbcodecache() {
	global $db, $prefix, $images, $codecache, $codecache2, $settings, $smiliepath;
	
	$x=0;
	$caddition="WHERE (enabled='yes'";

	if($settings['smilies']==1) {
		$caddition .= " && (type='smilie'";
		$x=1;
	}  
	if($settings['censors']==1) {  
		if($x==1) {
			$caddition .= " || type='censor'"; 
		} else {
			$caddition .= " && (type='censor'";
			$x=1;
		}
	}
	if($x==1) {
		$caddition .= ")";
	}
	$caddition .= ")";
	$codecache = array();

	$query = "SELECT * FROM ".$prefix."replacements ".$caddition;
	$query2 = $db->query($query);
	while($bbc=$db->fetch_array($query2)) {
		$bbcode=$bbc['tag'];
		$orig_bbcodereplacement=$bbc['replacement'];
		$type=$bbc['type'];

		if($type == "censor") {
			$bbcode = $db->escape($bbcode);
			$codecache[$bbcode] = $orig_bbcodereplacement;
		}

		if($type == "smilie" && file_exists($smiliepath."/".$orig_bbcodereplacement)) {
			$codecache2[$bbcode] = '<img src="'.$smiliepath.'/'.$orig_bbcodereplacement.'" alt="Smilie" />';
		}
	}
}

function bbcode($text, $s=0) {
	global $codecache,$codecache2,$settings,$images,$donewline;
		
	##initialising
	$patterns = array();
	$replacements = array();
	
	##censors first
	if($settings['censors']!=0) {
		foreach($codecache as $pattern => $replacement) {
			$patterns[] = $pattern;
			$replacements[] = $replacement;
		}
		
		$finalremove=$text;
		
		for ($x=0; $x < count($patterns); $x++) {
			while(stristr($finalremove,$patterns[$x])) {
				$occ=strpos(strtolower($finalremove),strtolower($patterns[$x]));
				$piece_front=substr($finalremove,0,$occ);
				$piece_back=substr($finalremove,($occ+strlen($patterns[$x])));
				$finalremove=$piece_front . $replacements[$x] . $piece_back;
			}
		}
		$text = $finalremove;
	}
	
	##smilies
	if($s==0 && $settings['smilies']!=0) {
		foreach($codecache2 as $pattern => $replacement){
			$text = str_replace($pattern,$replacement,$text);
		}
	}
	
	##new line?
	if($settings['htmloff']==1 || $donewline==1) {
		$text = nl2br($text);
	}
	
	##wordwrap? different wrap functions depending on html on/off
	if($settings['wrap']==1) {
		if($settings['htmloff']==1) {
			$text = textwrap($text, $settings['wraplength']);
		} else {
			$text = preg_replace('`>([^<]*)<`e', 'htmlwrap(\'\1\', $settings[wraplength])', $text);
		}
	}	
	
	return $text;
}

function cachelists() {
	global $db,$prefix,$settings,$posticonlist,$smilielist;

	$posticonlist=array();
	$smilielist=array();

	$x=0;
	$caddition="WHERE (enabled='yes' && inmenu='yes' && (type='posticon'";
	if($settings['smilies']==1) {
		 $caddition .= " || type='smilie'";
	}  
	if($settings['censors']==1) {
		$caddition .= " || type='censor'";
	}  
	$caddition .= "))";

	$repla = $db->query("SELECT * FROM ".$prefix."replacements ".$caddition);
	while($repl=$db->fetch_array($repla)) {
		$key = $repl['tag'];
		if($repl['type']=='smilie') {
			$key = $db->escape($key);
			$smilielist[$key]=$repl['replacement'];
		}
		if($repl['type']=='posticon') {
			$posticonlist[]=$repl['replacement'];
		}
	}
}

/* check if $var is an valid email adress */
function isemail($var) {
	if(ereg("[A-Za-z0-9_-]+([\.]{1}[A-Za-z0-9_-]+)*@[A-Za-z0-9-]+([\.]{1}[A-Za-z0-9-]+)+", $var)) {
		$list = array('"', '\\', ', ', '|##|', "'");
		foreach($list as $element) {
			if(strstr($var, $element)) {
				return FALSE;
			}
		}
		return TRUE;
	} else {
		return FALSE;
	}
}

/* check if $val is clearly defined */
function value_exists($val) {
	if(!$val || $val == '' || $val == '0') {
		return FALSE;
	} else {
		return TRUE;
	}
}

/* redirect to page x after y seconds */
function redirect($url, $sec=2) {
	$msec = $sec*1000;
	print <<<EOT
	<script type="text/javascript" language="JavaScript">
	function redirect() {
	 window.location.replace("$url");
	}
	setTimeout("redirect();", $msec);
	</script>
EOT;
exit();
}

/* Check if a member has access to a special forum */
function access($membername, $code, $viewstatus='', $poststatus='', $replystatus='', $userlist='') {
	global $settings,$_COOKIE;
	$x = FALSE;
	
	//echo 'membername= '.$membername.'<br />'.'code= '.$code.'<br />'.'viewstatus= '.$viewstatus.'<br />'.'poststatus= '.$poststatus.'<br />'.'replystatus= '.$replystatus.'<br />'.'userlist= '.$userlist;
	
	if($viewstatus!='') {
		if(!is_numeric($code)) {
			$code=0;
		}

		if($viewstatus=='no') { $vreq=6; }
		if($viewstatus=='ad') { $vreq=4; }
		if($viewstatus=='mo') { $vreq=2; }
		if($viewstatus=='me') { $vreq=1; }
		if($viewstatus=='all') { $vreq=0; }
		
		if(!($code>=$vreq)) {
			return FALSE;
			exit();
		} else {
			$x = TRUE;
		}
	}

	if($poststatus!='') {
		if(($membername=='guest'||$_COOKIE['membercookie']==''||$_COOKIE['memberid']==0) && $settings['guestposting']==0) {
			return FALSE;
			exit();
		}
		
		if(!is_numeric($code)) {
			$code=0;
		}
		
		if($poststatus=='no') { $preq=6; }
		if($poststatus=='ad') { $preq=4; }
		if($poststatus=='mo') { $preq=2; }
		if($poststatus=='me') { $preq=1; }
		if($poststatus=='all') { $preq=0; }
		
		if(!($code>=$preq)) {
			return FALSE;
			exit();
		} else {
			$x = TRUE;
		}
	}
	if($replystatus!='') {
		if(($membername=='guest'||$_COOKIE['membercookie']==''||$_COOKIE['memberid']==0) && $settings['guestposting']==0) {
			return FALSE;
			exit();
		}
		
		if(!is_numeric($code)) {
			$code=0;
		}

		if($replystatus=='no') { $preq=6; }
		if($replystatus=='ad') { $preq=4; }
		if($replystatus=='mo') { $preq=2; }
		if($replystatus=='me') { $preq=1; }
		if($replystatus=='all') { $preq=0; }
		
		if(!($code>=$preq)) {
			return FALSE;
			exit();
		} else {
			$x = TRUE;
		}
	}

	if($userlist!='') {
		if(eregi($membername."(,|$)", $userlist) && $membername!="") {  
			$x = TRUE;
		} else {
			return FALSE;
			exit();
		}
	}
	return $x;
}

/* Check if a member is moderating a special forum */
function modcheck($username, $code, $modlist='', $who=0) {	
	if($who!=0) {
		if($code!="") {
			if($code=="5"||$code=="4"||$code=="3") {
				$x = TRUE;
			}
		} else {
			return FALSE;
			exit();
		}
	}
	
	if($modlist!="" && $username!="") {
		if(eregi(urlencode($username)."(,|$)", urlencode($modlist))) {
			$x=TRUE;
		} else {
			if($x==TRUE) {
				$x=TRUE;
			} else {
				return FALSE;
				exit();
			}
		}
	} else {
		if($x==TRUE) {
			$x=TRUE;
		} else {
			return FALSE;
			exit();
		}
	}
	return $x;
}

/* Check if user is a member */
function usercheck() {
	global $_COOKIE;

	if(!$_COOKIE['membercookie'] || $_COOKIE['membercookie']=='' || $_COOKIE['membercookie']=='guest' || !$_COOKIE['memberid'] || $_COOKIE['memberid']=='' || $_COOKIE['memberpw']=='') {
		return FALSE;
	} else {
		return TRUE;
	}
}

/* Display two strings, format is stored in message.php */
function message($text1, $text2='', $redirect='', $sec=2, $tag1='strong', $tag2='u') {
	global $tablebordercolor,$tdbgcolor,$footer,$templatefolder,$versionname;

	$footer=FALSE;
	
	include($templatefolder.'/message.dtf');

	if($redirect!='') {
		echo '</body></html>';
		redirect($redirect, $sec);
	} else {
		quit();
	}
}

/* Stop the script, and add closing tags */
function quit() {
	global $footer,$versionname,$templatefolder;
	include('./footer.php');
	exit();
}

/* Get the structure of a table */
function get_table_def($table, $crlf) {
    global $drop, $db;
    $schema_create = '';
	if(!empty($drop)) {
		$schema_create .= "DROP TABLE IF EXISTS $table;$crlf";
	}
	
	$getstructure = $db->query("SHOW CREATE TABLE $table");
    $structure = $db->fetch_array($getstructure, MYSQL_NUM);
	
	$schema_create .= $structure[1].';'.$crlf;
	
	return $schema_create;
}
	
/* Get the content of a table */
function get_table_content($table, $crlf) {
	global $db;
	##fix newlines
	$search = array("\x00", "\x0a", "\x0d", "\x1a");
	$replace = array('\0', '\n', '\r', '\Z');

	$dump='';
	$result = $db->query("SELECT * FROM ".$table);
	while($row = $db->fetch_array($result)) {
		$dump .= "INSERT INTO $table VALUES (";
		$z=0;
		foreach($row as $x=>$y) {
			$y = $db->escape($y);
			$y = str_replace($search, $replace, $y);
			
			if($z==sizeof($row)-1) {
				$dump .= "'$y');$crlf";
			} else {
				$dump .= "'$y', ";
			}
			$z++;
		}
	}
	return $dump;
}

// Get all members online and format them for who-is-online
function formatonline() {
	global $prefix,$db,$lang_legend;
	$memberonline=0; $guestonline=0; $invisibleonline=0;
	
	$pplonline = array();

	$getinfo = $db->query("SELECT o.name,u.membercode FROM ".$prefix."online AS o, ".$prefix."users AS u WHERE (u.username = o.name)");
	while($online = $db->fetch_array($getinfo)) {
		if($online['name']=='guest') {
			$guestonline++;
		} elseif($online['name']=='invisible') {
			$invisibleonline++;
		} else {
			$memberonline++;
			$pplonline[$online['name']] = $online['membercode'];
		}
	}
	$totalonline = $guestonline + $memberonline + $invisibleonline;

	natsort($pplonline);
	reset($pplonline);

	$currentonline = "<font size=\"1\">";
	foreach($pplonline as $a=>$b) {
		if($b==1) {
			$pre = '';
			$suf = '';
		} elseif($b==2) {
			$pre = '<strong>';
			$suf = '</strong>';
		} elseif($b==3) {
			$pre = '<strong><em>';
			$suf = '</em></strong>';
		} elseif($b==4) {
			$pre = '<strong><u>';
			$suf = '</u></strong>';
		} elseif($b==5) {
			$pre = '<strong><u><em>';
			$suf = '</em></u></strong>';
		}
		$currentonline .= '&gt;&gt; <a href="misc.php?sub=profile&amp;name='.urlencode($a).'">'.$pre.$a.$suf.'</a> ';
	}
	$currentonline .= "</font>";

	return array(0 => $currentonline,
				 1 => $guestonline,
				 2 => $memberonline,
				 3 => $invisibleonline,
				 4 => $totalonline);
}

function checkrestrictions($where) {
	global $db, $prefix, $settings, $_COOKIE;

	if($_COOKIE['membercookie']==$settings['headadmin']) {
		return TRUE;
	}
	
	$query = $db->query("SELECT `".$where."` FROM ".$prefix."restrictions WHERE (name='".$_COOKIE['membercookie']."' && status='1')");
	if($db->num_rows($query)==0) {
		$query = $db->query("SELECT `".$where."` FROM ".$prefix."restrictions WHERE (name='default')");
	}

	$restrictions = $db->fetch_array($query);

	if($restrictions[$where]) {
		return TRUE;
	} else {
		return FALSE;
	}
}

//check for browser
function checkbrowser() {
	if(!empty($_SERVER['HTTP_USER_AGENT'])) {
		$value = $_SERVER['HTTP_USER_AGENT'];
	} else if(!empty($HTTP_SERVER_VARS['HTTP_USER_AGENT'])) {
		$value = $HTTP_SERVER_VARS['HTTP_USER_AGENT'];
	} else {
		$value = $HTTP_USER_AGENT;
	}

	if(eregi('Opera', $value)) {
		return 'Opera';
	} else if(eregi('MSIE', $value)) {
		return 'IE';
	} else if(eregi('Mozilla', $value)) {
		return 'Mozilla';
	} else {
		return FALSE;
	}
}
function ejav($email,$type,$extra){
	$str = explode('@',$email);
	$str1 = $str[0];
	$str2 = $str[1];

	if($type == 'ah'){
		$nstr .= "<a href=\"mailto:";
	}

	$l1 = strlen($str1);
	$count='0';
	while($count < $l1) {
		$nstr .= '&#'.ord($str1[$count]).';';
		$count++;
	}

	$nstr .= "&#".ord('@').';';

	$l2 = strlen($str2);
	$count='0';
	while($count < $l2) {
		$nstr .= '&#'.ord($str2[$count]).';';
		$count++;
	}
	if($type == 'ah') {
		$nstr .= "\"$extra>";
	}

	return $nstr;
}

//do email_pro
function eout($dat){
	preg_match_all("/[A-Za-z0-9_-]+([\.]{1}[A-Za-z0-9_-]+)*@[A-Za-z0-9-]+([\.]{1}[A-Za-z0-9-]+)+/i",$dat,$matches);
	for($i=0; $i <count($matches[0]); $i++){
		$dat = str_replace($matches[0][$i],ejav($matches[0][$i],'em',''),$dat);	
	}
	return $dat;	
}

//do gzip
function gzout($type) {
	global $data, $HTTP_ACCEPT_ENCODING, $settings;
	
	$contents = ob_get_contents();
	if($type=='pe' || $type=='pegz') {
		$contents = eout($contents);
	}
	if($type=='gz' || $type=='pegz') {
		if (strpos($HTTP_ACCEPT_ENCODING, 'x-gzip') !== false) { $enc = 'x-gzip'; }
		if (strpos($HTTP_ACCEPT_ENCODING,'gzip') !== false) { $enc = 'gzip'; }
	    
	    if(!function_exists('gzcompress')) {
		    $enc = '';
	    }
	   
	    if($enc) {
		    $level = $settings['gzlevel'];
					
		    $data = "\x1f\x8b\x08\x00\x00\x00\x00\x00";
			$size = strlen($contents);
			$crc = crc32($contents);
			$data .= gzcompress($contents, $level);
			$data = substr($data, 0, strlen($data) - 4); //remove old crc
			$data .= pack("V",$crc) . pack("V", $size);
		    
		    ob_end_clean();
		    Header('Content-Encoding: ' . $enc);
		    Header('Content-Length: ' . strlen($data));
		    Header('Vary: Accept-Encoding');
		    echo $data;
		} else {
			ob_end_clean();
			echo $contents;
			exit();
		}
	} else {
		ob_end_clean();
		echo $contents;
		exit();
	}
}	

//this function is used to find out if the user has already read a topic or not
function lastvisit() {
	global $images,$image,$_COOKIE;
	$url = getenv('REQUEST_URI');
	$image = '<img src="'.$images.'/folder.gif" alt="Folder" />';
	
	if(preg_match("/forums.php/i",$url)) {
		global $open, $settings;
		$thetid = '-'.$open['tid'].'-';
		if($_COOKIE['lastvisitb'] < $open['lastpostdate'] && !strstr($_COOKIE['oldtopics'], $thetid)) {
			$image = '<img src="'.$images.'/red_folder.gif" alt="Red folder" />';
		} else {
			if($open['replies']>=$settings['hottopic']) {
				$image = '<img src="'.$images.'/hot_folder.gif" alt="Hot folder" />';
			} else {
				$image = '<img src="'.$images.'/folder.gif" alt="Folder" />';
			}
		}
		return $image;
	} elseif(preg_match("/topic.php/i",$url)) {
		global $tid, $cp, $cd, $cs, $member;
		$thetid = "-".$tid."-";
		if(!strstr($_COOKIE['oldtopics'], $tid)) {
			$oldtopics_add = $_COOKIE['oldtopics'] . $thetid;
			setcookie('oldtopics', $oldtopics_add, time()+($member['markposts']*60), $cp, $cd, $cs);
		}
	} else {
		global $post;
		if($_COOKIE['lastvisitb']==0 && value_exists($_COOKIE['lastvisita'])) {
			$_COOKIE['lastvisitb'] = $_COOKIE['lastvisita'];
		}
		if($_COOKIE['lastvisitb'] < $post['lastpidtime']) {
			$image = '<img src="'.$images.'/red_folder.gif" alt="Red folder" />';
		} else {
			$image = '<img src="'.$images.'/folder.gif" alt="Folder" />';
		}
		return $image;
	}
}

function multipage($totalrows, $page=1, $pagelimit=20, $pagename='', $add='') {
	global $lang_page;
	if(!$page || $page=='') {
		$page=1;
	}
	
	$fpagenum = ceil($totalrows/$pagelimit);
	if($fpagenum != 1 && $totalrows!=0) {
		$multipage = $page;
		if(($page - 4) < 0) {
			$page_minimum = 0;
		} else {
			$page_minimum = $page - 4;
		}
		for($x = $page; $x > $page_minimum; $x--) {
			if($x != $page) {
				$multipage = "<a href=\"$pagename&amp;page=$x$add\">$x</a>&nbsp;" . $multipage;
			}
		}
		if(($page + 3) > $fpagenum) {
			$page_maximum = $fpagenum;
		} else {
			$page_maximum = $page+3;
		}
		for($x = $page; $x < $page_maximum+1; $x++) {
			if($x != $page) {
				$multipage .= "&nbsp;<a href=\"$pagename&amp;page=$x$add\">$x</a>";
			}
		}
		$pagelinks = "$lang_page&nbsp;<a href=\"$pagename&amp;page=1$add\">&laquo;</a>&nbsp;$multipage&nbsp;<a href=\"$pagename&amp;page=$fpagenum$add\">&raquo;</a>";
	} elseif($totalrows=='' || $totalrows==0 || $fpagenum==1) {
		$pagelinks = '';
	}

	$page_start = ($pagelimit) * ($page - 1);
	
	return array(0 => $page_start,
				 1 => $pagelimit,
				 2 => $pagelinks);
}

function html($text, $direction=0) {
	//initialising arrays for translation
	$array1 = array("<",
					">",
					"chr(161)",
					"chr(162)",
					"chr(163)",
					"chr(169)",
					"chr(255)",
					"\""
					);

	$array2 = array("&lt;",
					"&gt;",
					"&iexcl;",
					"&cent;",
					"&copy;",
					"&pound;",
					"&yuml;",
					"&quot;"				
					);
	if($direction==0) {
		$text = str_replace($array1, $array2, $text);
	} else {
		$text = str_replace($array2, $array1, $text);
	}
	
	return $text;
}

function bar($add='') {
	global $lang_backto, $tablewidth, $bar_show, $bar_mainpage, $settings, $templatefolder;
	$barmsg = $bar_mainpage.$add;
	include($templatefolder.'/bar.dtf');
	return;
}

//Returns bytes from Mb, Kb and in PHP5.1 even Gb
function return_bytes($input) {
	$last = strtolower($input{strlen(trim($input))-1});
	switch($last) {
		case 'g':
			$input *= 1024;
		case 'm':
			$input *= 1024;
		case 'k':
			$input *= 1024;
	}
	return $input;
}

function rteSafe($strText) {
	//returns safe code for preloading in the RTE
	$tmpString = $strText;
	
	//convert all types of single quotes
	$tmpString = str_replace("'", "&#39;", $tmpString);
	
	//replace carriage returns & line feeds
	$tmpString = str_replace(chr(10), " ", $tmpString);
	$tmpString = str_replace(chr(13), " ", $tmpString);
	
	return $tmpString;
}

##Thanks to Helthem from o2php.com for the code!
function htmlwrap($string,$length=100,$break="<br />") {
	$msg = explode(' ', str_replace('\"', '"', $string));
	foreach($msg as $k => $t) {
		$msg[$k] = preg_replace('`([[:alpha:]]{' . $length . '})`', '\1' . $break, $t); 
	}
	return '>' . implode(' ', $msg) . '<';
}

function textwrap($string,$length=100,$break="\n") {
	$string = preg_replace('/([^\s]{'.$length.'})/i',"$1$break",$string);
	return $string;
}

function removeEvilTags($source) {
  global $settings;
	$source = preg_replace('#(<[^>]+[\x00-\x20\"\'\/])(on|xmlns)[^>]*>#iUu', "$1>", $source);
	$source = preg_replace('#([a-z]*)[\x00-\x20]*=[\x00-\x20]*([\`\'\"]*)[\\x00-\x20]*j[\x00-\x20]*a[\x00-\x20]*v[\x00-\x20]*a[\x00-\x20]*s[\x00-\x20]*c[\x00-\x20]*r[\x00-\x20]*i[\x00-\x20]*p[\x00-\x20]*t[\x00-\x20]*:#iUu','$1=$2nojavascript...',$source);
  $source = preg_replace('#([a-z]*)[\x00-\x20]*=([\'\"]*)[\x00-\x20]*v[\x00-\x20]*b[\x00-\x20]*s[\x00-\x20]*c[\x00-\x20]*r[\x00-\x20]*i[\x00-\x20]*p[\x00-\x20]*t[\x00-\x20]*:#iUu','$1=$2novbscript...',$source);
	$source = preg_replace('#(<[^>]+)style[\x00-\x20]*=[\x00-\x20]*([\`\'\"]*).*expression[\x00-\x20]*\([^>]*>#iU',"$1>",$source);
	$source = preg_replace('#(<[^>]+)style[\x00-\x20]*=[\x00-\x20]*([\`\'\"]*).*behaviour[\x00-\x20]*\([^>]*>#iU',"$1>",$source);
	do {
		$oldssource = $source;
		$source = preg_replace('#</*(applet|meta|xml|blink|link|style|script|embed|object|iframe|frame|frameset|ilayer|layer|bgsound|textarea|title|base)[^>]*>#i',"",$source);
	} while ($oldssource != $source);
	if($settings['htmloff']==0) {
  	return preg_replace('/
/u', ' ', $source);
  } else {
    return $source;
  }
}

function prepareranks() {
	global $db,$prefix,$specialrank,$userrank;
	$specialrank = array();
	//Fix if there is no rank for first posts
	$userrank[0] = '';
	$userranks = $db->query("SELECT * FROM ".$prefix."ranks");
	while($ranks = $db->fetch_array($userranks)) {
		if($ranks['title'] == 'Moderator' || $ranks['title'] == 'Super Moderator' || $ranks['title'] == 'Administrator' || $ranks['title'] == 'Head Admin') {
			//Ranks for Moderators + Admins
			$specialrank[$ranks['title']] = "$ranks[title],$ranks[posts],$ranks[stars],$ranks[starimage],$ranks[allowavatar],$ranks[allowsig]";
		} else {
			//Ranks for all other users
			$userrank[$ranks['posts']] = "$ranks[title],$ranks[posts],$ranks[stars],$ranks[starimage],$ranks[allowavatar],$ranks[allowsig]";
		}
	}
}
?>