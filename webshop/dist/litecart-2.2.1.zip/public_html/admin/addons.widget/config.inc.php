<?php

  return $widget_config = array(
    'name' => language::translate('title_addons', 'Add-ons'),
    'file' => 'addons.inc.php',
    'priority' => 3,
  );
