<?php
$PHORUM["DATA"]["LANG"]["example_language"]["HelloWorld"] = "Hallo, Welt!";
?>
