<?php
/**
 * @author Stéphane LaFlèche <stephane.l@vanillaforums.com>
 * @copyright 2009-2019 Vanilla Forums Inc.
 * @license GPL-2.0-only
 */

class RichEditorStylesController extends VanillaController {
    public function index() {
        $this->render();
    }

    public function rendered() {
        $this->render();
    }
}
