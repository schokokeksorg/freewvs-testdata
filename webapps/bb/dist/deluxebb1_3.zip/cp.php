<?php

/************************************************
 * DeluxeBB 1.3                                 *
 * Copyright (C) 2005-2009 Frank Nissel         *
 * http://www.DeluxeBB.com	                    *
 * For license information, please read the     *
 * license file in the docs/ folder! 			      *
 ************************************************/


$footer = TRUE;
$cssstyle = 'cp.css';
require('./header.php');
$temptitle = $lang_memcplong;
$where = "Member Cp";
require('./header_html.php');

$_COOKIE['memberid'] = @intval($_COOKIE['memberid']);

if(!usercheck()) {
	message($lang_wronguserorpass, $lang_wronguserorpassinfo, "index.php");
	quit();
}

if (!$sub) {
	##get pm info
	$getpm = $db->query("SELECT hasread,type FROM ".$prefix."pm WHERE (whoto='".$_COOKIE['membercookie']."' && (type='inbox'||type='outbox'))");
	$count=0;$readmsg=0;$outboxmsg=0;
	while($pm = $db->fetch_array($getpm)) {
		if($pm['hasread']=='no' && $pm['type']='inbox') { $count++; }
		if($pm['hasread']=='yes' && $pm['type']='inbox') { $readmsg++; }
		if($pm['type']=='outbox') { $outboxmsg++; }
	}
	$registered = gmdate($datecode, $member['joineddate'] + ($member['timeoffset'] * 3600));
	##subscription info
	$getsub = $db->query("SELECT s.*,t.subject,t.picon,t.views,t.replies FROM ".$prefix."subscriptions s LEFT JOIN ".$prefix."threads t ON (s.tid=t.tid) WHERE (s.uid='".$_COOKIE['memberid']."') ORDER BY t.lastpostdate DESC");
	
	bar($bar_memcp);
	include($templatefolder.'/cp/header.dtf');
	include($templatefolder.'/cp/index.dtf');
}

if ($sub == 'updatesub') {
	bar($bar_unsub);
	if($submit == $lang_unsubscribe) {
		for($x=0;$x<sizeof($delete);$x++) {
			$delete[$x] = @intval($delete[$x]);
			$db->unbuffered_query("DELETE FROM ".$prefix."subscriptions WHERE (tid='$delete[$x]' && uid='".$_COOKIE['memberid']."')");
		}
		message($lang_successfullyunsubscribedm, $lang_forwardmemcp, "cp.php");
	}
}

if ($sub == 'password') {
	bar($bar_change_pw);
	if($submit==$lang_update) {
		if($oldpass != "" || $newpass != "" || $confirmnewpass != "") {
			$checkname = $db->query("SELECT pass FROM ".$prefix."users WHERE (username='".$_COOKIE['membercookie']."' && uid='".$_COOKIE['memberid']."' && pass='".$_COOKIE['memberpw']."')");
			$checkpass = $db->result($checkname, 0);
			if($newpass != $confirmnewpass) {
				message($lang_sorryerror, $lang_checkifcorrect);
				quit();
			}
			
			$oldpass = md5(trim($oldpass));
			$newpass = md5(trim($newpass));
			
			if ($oldpass != $checkpass) { 
				message($lang_sorryerror, $lang_checkifcorrect);
			} else {
				$db->unbuffered_query("UPDATE ".$prefix."users SET pass='$newpass' WHERE (username='".$_COOKIE['membercookie']."')");
				message($lang_successfullypw, $lang_forwardmainpage, "misc.php?sub=logout");
			}
		}
	} else {
		include($templatefolder.'/cp/header.dtf');
		include($templatefolder.'/cp/password.dtf');
	}
}

if ($sub == 'settings') {
	bar($bar_change_ps);
	
	if ($submit==$lang_update) {
		if(!isemail($xemail)) {
			message($lang_erroremail, $lang_erroremailinfo);
		} else {
			##Checking user input			
			$vars = array('xemail', 'xmsn', 'xaim', 'xyim', 'xlocation', 'xsite', 'xthetimeoffset', 'xthetimeformat', 'xthedateformat', 'skinx', 'languagex');
			for($x=0;$x<count($vars);$x++){
				${$vars[$x]} = $db->escape(html(${$vars[$x]}));
		  	}
	
		  	if($xicq!='') {
				$xicq = @intval($xicq);
			}
			$xhideemail = @intval($xhideemail);
			$invisiblebrowse = @intval($invisiblebrowse);
			$pmnotify = @intval($pmnotify);
			if(!is_numeric($markposts)) {
				$markposts = 15;
			}
			
			if($settings['emailver']==1 && $member['email']!=$xemail) {
			  $sendmail = 1;
				$createrndnum = generatepw(10, 10, 1);
				$valnum = "'".$createrndnum."'";
			} else {
		  	$sendmail = 0;
				$valnum = 'NULL';
			}
			
			$db->unbuffered_query("UPDATE ".$prefix."users SET email='$xemail', msn='$xmsn', icq='$xicq', aim='$xaim', yim='$xyim', location='$xlocation', site='$xsite', skin='$skinx', language='$languagex', hideemail='$xhideemail', timeoffset='$xthetimeoffset', dateformat='$xthedateformat', timeformat='$xthetimeformat', pmnotify='$pmnotify', markposts='$markposts', invisible='$invisiblebrowse', valnum=$valnum WHERE (username='".$_COOKIE['membercookie']."' && uid='".$_COOKIE['memberid']."' && pass='".$_COOKIE['memberpw']."')");
			
			if($settings['perstitleedit']==1) {
				$xperstitle = $db->escape(html($xperstitle));
				$db->unbuffered_query("UPDATE ".$prefix."users SET customtitle='$xperstitle' WHERE (username='".$_COOKIE['membercookie']."' && uid='".$_COOKIE['memberid']."' && pass='".$_COOKIE['memberpw']."')");
			}
			
			if($invisiblebrowse==1) {
				$db->unbuffered_query("DELETE from ".$prefix."online WHERE (name='".$_COOKIE['membercookie']."')");
			} else {
				$db->unbuffered_query("DELETE from ".$prefix."online WHERE (name='invisible' && ip='$ip')");
			}
			
			if($sendmail==1) {
				##getting headadmin email
				$getemail = $db->query("SELECT email FROM ".$prefix."users WHERE (username='".$settings['headadmin']."')");
				$heademail = $db->fetch_array($getemail);

				##Security Checks
				if(!isset($_SERVER['HTTP_USER_AGENT'])){
				   die("Forbidden - You are not authorized to view this page");
				}
				
				if(!$_SERVER['REQUEST_METHOD'] == "POST"){
				   die("Forbidden - You are not authorized to view this page");
				}
				
				##Server Conf.
				if(strtoupper(substr(PHP_OS, 0, 3) == 'WIN')) {
					$nl_tag = "\r\n";
				} elseif (strtoupper(substr(PHP_OS, 0, 3) == 'MAC')) {
					$nl_tag = "\r";
				} else {
					$nl_tag = "\n";
				}

				$to = "<$email>";
		
				$headers = 'From: '.$settings['boardname'].' <'.$heademail['email'].'>'.$nl_tag;
				$headers .= 'Reply-To: '.$settings['boardname'].' <'.$heademail['email'].'>'.$nl_tag; 
				$headers .= 'X-Original-From: '.$settings['boardname'].$nl_tag;
		   	$headers .= 'X-Mailer: Deluxe Bulletin Board Mailer'.$nl_tag;
		    $headers .= 'X-Sender: <'.$heademail['email'].'>'.$nl_tag;
				$headers .= 'X-AntiAbuse: Forum - '.$settings['boardname'].$nl_tag;
				$headers .= 'Return-Path: <'.$heademail['email'].'>'.$nl_tag;
				$headers .= 'Content-Type: text/plain; charset='.$lang_charset;
				
				require('./header_html.php');
				
				if(!eregi("\r",$to) && !eregi("\n",$to) && isemail($heademail['email'])){	
					$url = $fullpath.'misc.php?sub=valemail&valmem='.$uid.'&valnum='.$createrndnum;
					@mail($to, "$lang_valemailtitle \"$settings[boardname]\"", "$lang_valemailtxt1 $name $lang_valemailtxt2 $ip $lang_valemailtxt3 \"$settings[boardname]\" $lang_valemailtxt4 $url $lang_valemailtxt5 $settings[boardname] $lang_valemailtxt6", $headers);
				}
				message($lang_emailvermsg, '', 'index.php');
			} else {
			 	message($lang_successfullycontact, $lang_forwardmemcp, 'cp.php');
			}
		}
	} else {
		$dir = opendir("lang");
		while ($langfile = readdir($dir)) {
			if(is_file("lang/$langfile")) {
				$langfile = str_replace(".php", "", $langfile);
				if($langfile == "$member[language]") {
					$languagelist .= "<option value=\"$langfile\" selected=\"selected\">$langfile</option>\n";
				} else {
					$languagelist .= "<option value=\"$langfile\">$langfile</option>\n";
				}
			}
		}
		$query = $db->query("SELECT skinname FROM ".$prefix."skins");
		while($skininfo = $db->fetch_array($query)) {
			if($skininfo['skinname'] == $member['skin']) {
				$skinlist .= "<option value=\"$skininfo[skinname]\" selected=\"selected\">$skininfo[skinname]</option>\n";
			} else {
				$skinlist .= "<option value=\"$skininfo[skinname]\">$skininfo[skinname]</option>\n";
			}
		}
		
		if(date("I")) {
			$gmdateoffset = 3600;
		}
		$gmtime = gmdate($timecode, $time + $gmdateoffset);
		$gmtimemsg = "$lang_curgmttime $gmtime";
		if($member['timeformat'] == "24") {
			$check24 = "checked=\"checked\"";
		} else {
			$check12 = "checked=\"checked\"";
		}
		
		$dateformat = array('d.m.y', #24.12.00
						   'd.m.Y', #24.12.2000
						   'd/m/y', #24/12/00
						   'd/m/Y', #24/12/2000
						   'm/d/y', #12/24/00
						   'm/d/Y', #12/24/2000
						   'd-m-y', #24-12-00
						   'd-m-Y', #24-12-2000
						   'm-d-y', #12-24-00
						   'm-d-Y', #12-24-2000
						   'Y-m-d', #2000-12-24
						   'j M Y', #24 Dec 2000
						   'j F Y', #24 December 2000
						   'j F Y l', #24 December 2000 Sunday
						   'M jS, Y', #Dec 24th, 2000
						   'F j, Y', #December 24, 2000
						   'F jS Y', #December 24th 2000
						   'D M jS, Y', #Sun Dec 24th, 2000
						   'D M j', #Sun Dec 24
						   'l F jS, Y', #Sunday December 24th, 2000
						   'l M jS, Y' #Sunday Dec 24th, 2000
						   );
	
		foreach($dateformat as $id => $code) {
			$selected = '';
			if($code == $member['dateformat']) {
				$selected = ' selected="selected"';
			}
			$dateformatlist .= "<option value=\"$code\"$selected>".gmdate($code, 977619600)."</option>\n";
		}

		if($member['membercode']==1) {
			$status = $lang_member;
		} elseif($member['membercode']==2) {
			$status = $lang_moderator;
		} elseif($member['membercode']==3) {
			$status = $lang_supermoderator;
		} elseif($member['membercode']==4) {
			$status = $lang_administrator;
		} elseif($member['membercode']==5) {
			$status = $lang_headadministrator;
		}
		
		if($settings['userranks']!=0) {
			##caching ranks
			prepareranks();
			
			$checktitle = '';
			switch ($member['membercode']) {
				case(2): $checktitle = "Moderator"; break;
				case(3): $checktitle = "Super Moderator"; break;
				case(4): $checktitle = "Administrator"; break;
				case(5): $checktitle = "Head Admin"; break;
			}
		
			if($checktitle!='') {
				$rankinfo = explode(",", $specialrank[$checktitle]);
			} else {
				foreach ($userrank as $key => $rinfo) {
					if($member['posts'] >= $key) {
						$rankinfo = explode(",", $rinfo);
					}
				}
			}
		}
		
		//fixing daylight savings
		if(date("I")) {
			$member['timeoffset']--;
		}

		include($templatefolder.'/cp/header.dtf');
		include($templatefolder.'/cp/settings.dtf');
	}
}

if ($sub == 'avatar') {
	bar($bar_change_av);
	if($submit==$lang_update) {
		##if no avatar
		if(!value_exists($avatar)) {
			$db->unbuffered_query("UPDATE ".$prefix."users SET avatar='' WHERE (username='".$_COOKIE['membercookie']."' && uid='".$_COOKIE['memberid']."' && pass='".$_COOKIE['memberpw']."')");
			message($lang_successfullyavatar, $lang_forwardmemcp, "cp.php");
			quit();
		}
		$avatar = $db->escape($avatar);
		##checking url
		if(!ereg("^(http|https|ftp)://.*\.(gif|jpg|jpeg|png)$",$avatar)) {
			message($lang_avatarwrongtype, $lang_plscorrectavatar);
		}
		##getting avatar size
		$avatarsize = @getimagesize($avatar);
		if($avatarsize===FALSE) {
			message($lang_avatarurlwrong, $lang_avatarurlwrong2);
		}
		##checking size
		if(($avatarsize[0] > $settings['avatarw']) || ($avatarsize[1] > $settings['avatarh'])) {
			message($lang_avatartoolarge, $lang_plscorrectavatar);
		}
		if(($avatarsize[0] < $settings['avatarwlow']) || ($avatarsize[1] < $settings['avatarhlow'])) {
			message($lang_avatartoosmall, $lang_plscorrectavatar);
		}
		$db->unbuffered_query("UPDATE ".$prefix."users SET avatar='$avatar' WHERE (username='".$_COOKIE['membercookie']."' && uid='".$_COOKIE['memberid']."' && pass='".$_COOKIE['memberpw']."')");
		message($lang_successfullyavatar, $lang_forwardmemcp, "cp.php");
	} else {
		if(value_exists($member['avatar'])) {
			$avatarpic = '<img src="'.$member['avatar'].'" alt="Avatar" />';
		} else {
			$avatarpic = '<font size="1"><em>'.$lang_noavatar.'</em></font>';
		}
		
		if($settings['userranks']!=0) {
			##caching ranks
			prepareranks();
			
			$checktitle = '';
			switch ($member['membercode']) {
				case(2): $checktitle = "Moderator"; break;
				case(3): $checktitle = "Super Moderator"; break;
				case(4): $checktitle = "Administrator"; break;
				case(5): $checktitle = "Head Admin"; break;
			}
	
			if($checktitle!='') {
				$rankinfo = explode(",", $specialrank[$checktitle]);
			} else {
				foreach ($userrank as $key => $rinfo) {
					if($member['posts'] >= $key) {
						$rankinfo = explode(",", $rinfo);
					}
				}
			}
		}

		include($templatefolder.'/cp/header.dtf');
		include($templatefolder.'/cp/avatar.dtf');
	}
}

if ($sub == 'sig') {
	bar($bar_change_sig);
	if ($submit==$lang_update) {
		$post = trim($rte1);
		//counting lines
		if($settings['sightml']==1) {
			$lines = preg_split('=<br */?>=i', $post);
			$lines2 = preg_split('=<p */?>=i', $post);
			$siglines = count(array_filter($lines)) + count(array_filter($lines2))-1;
			$post = removeEvilTags($post);
		} else {
			$lines = explode("\n", $post);
			$siglines = count($lines);
			$post = html($post);
		}

		if($siglines > $settings['siglength']) {
			message($lang_sigtoolong, $lang_plscorrectsig);
			quit();
		}
		
		$db->unbuffered_query("UPDATE ".$prefix."users SET sig='".$db->escape($post)."' WHERE (username='".$_COOKIE['membercookie']."' && uid='".$_COOKIE['memberid']."' && pass='".$_COOKIE['memberpw']."')");
		message($lang_successfullysig, $lang_forwardmemcp, "cp.php");
	} else {
		bbcodecache();
		cachelists();
		if($settings['sightml']==1) { 
			$html1=$lang_enabled;
		} else {
			$html1=$lang_disabled;
		}
		if($member['sig']!='') {
			if($settings['sightml']==1) {
				$sig = bbcode($member['sig'], 1);
			} else {
				$donewline = 1; //now the bbcode function adds newline tags
				$member['sig'] = html($member['sig']);
				$sig = bbcode($member['sig']);
			}
		} else {
			$sig = "<em>$lang_nosig</em>";
		}
		
		if($settings['userranks']!=0) {
			##caching ranks
			prepareranks();

			$checktitle = '';
			switch ($member['membercode']) {
				case(2): $checktitle = "Moderator"; break;
				case(3): $checktitle = "Super Moderator"; break;
				case(4): $checktitle = "Administrator"; break;
				case(5): $checktitle = "Head Admin"; break;
			}
	
			if($checktitle!='') {
				$rankinfo = explode(",", $specialrank[$checktitle]);
			} else {
				foreach ($userrank as $key => $rinfo) {
					if($member['posts'] >= $key) {
						$rankinfo = explode(",", $rinfo);
					}
				}
			}
		}
		
		$member['sig'] = addslashes($member['sig']);
		
		include($templatefolder.'/cp/header.dtf');
		include($templatefolder.'/cp/sig.dtf');
	}
}

include('./footer.php');

?>