<?php

if (!defined("PHORUM_ADMIN")) return;

define("LOGVIEWER_FILTER_MODE", 1);
include("logviewer.php");
?>

