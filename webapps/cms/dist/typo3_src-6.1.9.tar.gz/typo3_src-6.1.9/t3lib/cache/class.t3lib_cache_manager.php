<?php
/*
 * @deprecated since 6.0, the classname t3lib_cache_Manager and this file is obsolete
 * and will be removed with 6.2. The class was renamed and is now located at:
 * typo3/sysext/core/Classes/Cache/CacheManager.php
 */
require_once __DIR__ . '/../../typo3/sysext/core/Classes/Cache/CacheManager.php';
?>