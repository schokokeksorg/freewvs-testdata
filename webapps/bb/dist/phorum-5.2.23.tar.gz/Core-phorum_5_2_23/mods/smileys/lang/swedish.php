﻿<?php
$PHORUM["DATA"]["LANG"]["mod_editor_tools"] = array(
    'smiley'        => 'Infoga smiley',
    'subjectsmiley' => 'Infoga smiley till rubriken',
    'smileys help'  => 'Smileys  hjälp',

    # Text for the smileys disable option in the posting editor.
    'disable'      => 'Disable smileys for this message'
);
?>
