<?php
$PHORUM["DATA"]["LANG"]["mod_editor_tools"] = array(
    # Button descriptions.
    'help'         => 'Informace n�pov�dy',
);
?>
