<?php

$hostname = "localhost";
$dbname = "deluxebb";
$dbusername = "root";
$dbpassword = "";
$prefix = "deluxebb_";
$fullpath = "http://localhost/deluxebb/";
$logs = 1;

?>