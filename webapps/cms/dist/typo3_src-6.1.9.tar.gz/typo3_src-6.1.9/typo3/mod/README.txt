typo3/mod/

TYPO3 modules, old repository.
The history of this directory is that it contained all the modules which belongs to the core. 
When the extension manager came, most of the modules were moved out from here and into extensions.
You will still find a few modules here, such as the Extension Manager and Web>Access module.
Further, other core modules may be configured in here. One of them is the "Web>List" module which has its main code positioned in typo3/db_list.php (for historical reasons).

Generally, this directory is not expanded with new stuff anymore. All modules developed today are created in extensions.
