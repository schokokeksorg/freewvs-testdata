<?php
/*
 * @deprecated since 6.0, the classname t3lib_collection_Collection and this file is obsolete
 * and will be removed with 6.2. The class was renamed and is now located at:
 * typo3/sysext/core/Classes/Collection/CollectionInterface.php
 */
require_once \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath('core') . 'Classes/Collection/CollectionInterface.php';
?>