<?php

/************************************************
 * DeluxeBB 1.3                                 *
 * Copyright (C) 2005-2009 Frank Nissel         *
 * http://www.DeluxeBB.com	                    *
 * For license information, please read the     *
 * license file in the docs/ folder! 			      *
 ************************************************/


$footer = TRUE;
$cssstyle = 'misc.css';
require('./header.php');

if($sub == 'login') {
	$redirect = removeEvilTags($redirect);
	$where = "Log-In";
	$temptitle = $lang_login;
	$maintenance = 1;
	if($submit==$lang_login) {
		##Escaping $name and converting back html chars
		$name = $db->escape(html($name));
		$checkname = $db->query("SELECT pass FROM ".$prefix."users WHERE (username = '$name')");
		$checkpass = $db->fetch_array($checkname);
		if(!$db->num_rows($checkname) > 0) {
			require('./header_html.php');
			bar($bar_login_error);
			message($lang_wronguserorpass, $lang_wronguserorpassinfo, "misc.php?sub=login");
			quit();
		}
		
		$password = md5($password);
		if($password != $checkpass['pass']) {
			require('./header_html.php');
			bar($bar_login_error);
			message($lang_wronguserorpass, $lang_wronguserorpassinfo, "misc.php?sub=login");
		} else {
			$getinfo = $db->query("SELECT username,uid,valnum FROM ".$prefix."users WHERE (username='$name')");
			$info = $db->fetch_array($getinfo);

			if($info['valnum']!='') {
				require('./header_html.php');
				bar($bar_login_error);
				message($lang_emailvererror1);
			} else {
        if(!$expiry) {
          $expiry = 29030400; //1 Year
        }
				setcookie("membercookie", $info['username'], time()+$expiry, $cp, $cd, $cs);
				setcookie("memberid", $info['uid'], time()+$expiry, $cp, $cd, $cs);
				setcookie("memberpw", $password, time()+$expiry, $cp, $cd, $cs);
				if($invisiblemode==1) {
					setcookie("invisible", 1, time()+$expiry, $cp, $cd, $cs);
				}
				require('./header_html.php');
				$db->unbuffered_query("DELETE FROM ".$prefix."online WHERE (ip='$ip' && name='guest')");
				$footer = FALSE;
				bar($bar_login_success);

				if($redirect=='') {
					$redirect = 'index.php';
				} else {
					if(stristr($redirect, 'http://') || stristr($redirect, 'https://') || stristr($redirect, 'ftp://') || stristr($redirect, 'www.')) {
						exit();
					}
					$redirect = urldecode($redirect);
				}
				
				message($lang_successfullylogin, $lang_forwardmainpage, $redirect, 1);
			}
		}
	} else {
		require('./header_html.php');
		bar($bar_login);
		include($templatefolder.'/login_form.dtf');
	}
}

if($sub == 'logout') {
	$maintenance = 1;
	$db->unbuffered_query("DELETE FROM ".$prefix."online WHERE (name='".$_COOKIE['membercookie']."')");
	$time = time()-29030400;
  if(is_array($_COOKIE) && !empty($_COOKIE)) {
		foreach($_COOKIE as $a=>$b) {
			setcookie("$a", '', $time, $cp, $cd, $cs);
		}
	} else {
		setcookie("membercookie", "", $time, $cp, $cd, $cs);
		setcookie("memberid", "", $time, $cp, $cd, $cs);
		setcookie("invisible", 0, $time, $cp, $cd, $cs);
	}
	$footer=FALSE;
	$temptitle = $lang_logout;
	require('./header_html.php');
	bar($bar_logout);
	message($lang_successfullylogout, $lang_forwardmainpage, "index.php", 1);
}

if($sub == 'register') {
	$temptitle = $lang_register;
	$where = 'Registering';
	
	##security validation
	$vars = array('name', 'hideemail', 'xthetimeoffset', 'xthetimeformat', 'languagex', 'xthetimeoffset', 'dateformatlist', 'languagelist');
	for($x=0;$x<count($vars);$x++) {
		${$vars[$x]} = html($db->escape(${$vars[$x]}));
	}
	
	$name = trim($name);
	$hideemail = @intval($hideemail);
	$time = time();

	if($submit==$lang_register) {
	  if($settings['captcha']==1) {
      ##Captcha Verification
      include("./classes/securimage.php");
      $img = new Securimage();
      $valid = $img->check($seccode);

      if($valid == false) {
      	require('./header_html.php');
  			bar($bar_reg_error);
        message("You entered the wrong code", "Please go back and try again");
      }
    }

		if($name == 'guest' || $name == 'invisible') {
			require('./header_html.php');
			bar($bar_reg_error);
			message($lang_namenotallowed, $lang_chooseanother);
		}
		$list = array('"', '\\', ',', '|##|', "'", '  ');
		foreach($list as $element) {
			if(strstr($name, $element)) {
				require('./header_html.php');
				bar($bar_reg_error);
				message("$lang_invalidchars $element", $lang_chooseanother);
			}
		}

		##Checking if user is banned 
    $isbanned = $db->query("SELECT * FROM ".$prefix."banned WHERE type='name'");
    while($bannednames = $db->fetch_array($isbanned)) {
      if(stristr($name, $bannednames['value'])) {
        require('./header_html.php');
        bar($bar_reg_error);
        message($lang_usernamebanned, $lang_usernamebannedtxt);
      }
		}
		##Checking if email is banned 
    $isbanned2 = $db->query("SELECT * FROM ".$prefix."banned WHERE type='email'");
    while($bannedemails = $db->fetch_array($isbanned2)) {
      if(stristr($email, $bannedemails['value'])) {
        require('./header_html.php');
        bar($bar_reg_error);
        message($lang_emailbanned, $lang_usernamebannedtxt);
      }
		}
		
		if($pass!=$pass2) {
			require('./header_html.php');
			include($templatefolder.'/register_form.dtf');
		} elseif($name==''||$pass==''||$email=='') {
			require('./header_html.php');
			bar($bar_reg_error);
			message($lang_missingfields, $lang_missingfieldsinfo);
			quit();
		} elseif(!isemail($email)) {
			require('./header_html.php');
			bar($bar_reg_error);
			message($lang_erroremail, $lang_erroremailinfo);
			quit();
		} else {
			$check = $db->query("SELECT username FROM ".$prefix."users WHERE (username='$name')");
			if($db->num_rows($check) > 0) {
				require('./header_html.php');
				bar($bar_reg_error);
				message($lang_nametaken, $lang_nametakeninfo);
				quit();
			}
			if($settings['duplicateemail']==0) {
				$check = $db->query("SELECT email FROM ".$prefix."users WHERE (email='$email')");
				if($db->num_rows($check) > 0) {
					require('./header_html.php');
					bar($bar_reg_error);
					message($lang_duplicateemail, $lang_duplicateemailinfo);
					quit();
				}
			}
			
			##preparing password for database
			$pass = md5($pass);

			if($settings['emailver']==1) {
				$createrndnum = generatepw(10, 10, 1);
				$valnum = "'".$createrndnum."'";
			} else {
				$valnum = 'NULL';
			}
			
			$db->unbuffered_query("INSERT INTO ".$prefix."users VALUES (NULL, '$name', '$pass', '$email', 1, NULL, NULL, NULL, '', NULL, NULL, NULL, '0', '0', NULL, 'default', '$languagex', '$time', '$hideemail', NULL, '$xthetimeoffset', '$xthedateformat', '$xthetimeformat', '$ip', '$time', '0', '15', '0', $valnum)");
			$uid = $db->insert_id();
			$db->unbuffered_query("UPDATE ".$prefix."boardstats SET whatof=whatof+1, whenof='$name' WHERE (nameof='members')");
			if($settings['pmwelcome']!=0 && $settings['allowpm']!=0) {
				$message = str_replace('$boardname', "$settings[boardname]", $settings['pmwelcometxt']);
				$db->unbuffered_query("INSERT INTO ".$prefix."pm VALUES (NULL, '$name', 'System Mailer', 'Welcome!', '".addslashes($message)."', 'thumbup.gif', 'no', '$time', 'inbox')");
			}
			
			if($settings['emailver']==1) {
				##getting headadmin email
				$getemail = $db->query("SELECT email FROM ".$prefix."users WHERE (username='".$settings['headadmin']."')");
				$heademail = $db->fetch_array($getemail);

				##Security Checks
				if(!isset($_SERVER['HTTP_USER_AGENT'])){
				   die("Forbidden - You are not authorized to view this page");
				}
				
				if(!$_SERVER['REQUEST_METHOD'] == "POST"){
				   die("Forbidden - You are not authorized to view this page");
				}
				
				##Server Conf.
				if(strtoupper(substr(PHP_OS, 0, 3) == 'WIN')) {
					$nl_tag = "\r\n";
				} elseif (strtoupper(substr(PHP_OS, 0, 3) == 'MAC')) {
					$nl_tag = "\r";
				} else {
					$nl_tag = "\n";
				}

				$to = "<$email>";
		
				$headers = 'From: '.$settings['boardname'].' <'.$heademail['email'].'>'.$nl_tag;
				$headers .= 'Reply-To: '.$settings['boardname'].' <'.$heademail['email'].'>'.$nl_tag; 
				$headers .= 'X-Original-From: '.$settings['boardname'].$nl_tag;
		   	$headers .= 'X-Mailer: Deluxe Bulletin Board Mailer'.$nl_tag;
		    $headers .= 'X-Sender: <'.$heademail['email'].'>'.$nl_tag;
				$headers .= 'X-AntiAbuse: Forum - '.$settings['boardname'].$nl_tag;
				$headers .= 'Return-Path: <'.$heademail['email'].'>'.$nl_tag;
				$headers .= 'Content-Type: text/plain; charset='.$lang_charset;
				
				require('./header_html.php');
				
				if(!eregi("\r",$to) && !eregi("\n",$to) && isemail($heademail['email'])){	
					$url = $fullpath.'misc.php?sub=valemail&valmem='.$uid.'&valnum='.$createrndnum;
					@mail($to, "$lang_valemailtitle \"$settings[boardname]\"", "$lang_valemailtxt1 $name $lang_valemailtxt2 $ip $lang_valemailtxt3 \"$settings[boardname]\" $lang_valemailtxt4 $url $lang_valemailtxt5 $settings[boardname] $lang_valemailtxt6", $headers);

					bar($bar_reg_success);
					message($lang_emailvermsg);
				} else {
					bar($bar_reg_error);
					message($lang_badmailinput, $lang_badmailinput2);
					quit();
				}
			} else {
				$db->unbuffered_query("DELETE FROM ".$prefix."online WHERE (ip='$ip' && name='guest')");
				$ctime = time()+29030400;
				
				setcookie("membercookie", $name, $ctime, $cp, $cd, $cs);
				setcookie("memberid", $uid, $ctime, $cp, $cd, $cs);
				setcookie("memberpw", $pass, $ctime, $cp, $cd, $cs);
				
				require('./header_html.php');
				bar($bar_reg_success);
				
				if(!$redirect) {
  				message($lang_successfullyreg, $lang_forwardmainpage, "index.php?");
				} else {
        	message($lang_successfullyreg, $lang_forumredirectiontxt, $redirect);
        }
			}
		}
	} else {
		$dir = opendir("lang");
		while ($langfile = readdir($dir)) {
			if(is_file("lang/$langfile")) {
				$langfile = str_replace(".php", "", $langfile);
				if($langfile==$settings['language']) {
					$languagelist .= "<option value=\"$langfile\" selected=\"selected\">$langfile</option>\n";
				} else {
					$languagelist .= "<option value=\"$langfile\">$langfile</option>\n";
				}
			}
		}
		
		if(date("I")) {
			$gmdateoffset = 3600;
		}
		$gmtime = gmdate($timecode, $time + $gmdateoffset);
		$gmtimemsg = "$lang_curgmttime $gmtime";
		if($settings['timeformat']==24) {
			$check24 = "checked=\"checked\"";
		} else {
			$check12 = "checked=\"checked\"";
		}
		
		$dateformat = array('d.m.y', #24.12.00
				   'd.m.Y', #24.12.2000
				   'd/m/y', #24/12/00
				   'd/m/Y', #24/12/2000
				   'm/d/y', #12/24/00
				   'm/d/Y', #12/24/2000
				   'd-m-y', #24-12-00
				   'd-m-Y', #24-12-2000
				   'm-d-y', #12-24-00
				   'm-d-Y', #12-24-2000
				   'Y-m-d', #2000-12-24
				   'j M Y', #24 Dec 2000
				   'j F Y', #24 December 2000
				   'j F Y l', #24 December 2000 Sunday
				   'M jS, Y', #Dec 24th, 2000
				   'F j, Y', #December 24, 2000
				   'F jS Y', #December 24th 2000
				   'D M jS, Y', #Sun Dec 24th, 2000
				   'D M j', #Sun Dec 24
				   'l F jS, Y', #Sunday December 24th, 2000
				   'l M jS, Y' #Sunday Dec 24th, 2000
				   );
	
		foreach($dateformat as $id => $code) {
			$selected = '';
			if($code == $member['dateformat']) {
				$selected = ' selected="selected"';
			}
			$dateformatlist .= "<option value=\"$code\"$selected>".gmdate($code, 977619600)."</option>\n";
		}
		
		require('./header_html.php');
		bar($bar_register);
		include($templatefolder.'/register_form.dtf');
	}
}

if($sub == 'lostpw') {
	$temptitle = $lang_lostpw;
	require('./header_html.php');
	
	$name = $db->escape($name);
	
	if($settings['allowlostpw']==0) {
		bar($bar_lostpw);
		message($lang_function_disabled, $lang_lostpwdisabled);
	}
	
	
	if($submit==$lang_reset) {
		bar($bar_lostpw);
		if(!isemail($email)) {
			message($lang_erroremail, $lang_erroremailinfo);
		}

		$query = $db->query("SELECT username,email FROM ".$prefix."users WHERE (username='".urlencode($name)."' && email='$email')");
		$memberx = $db->fetch_array($query);

		if(!$memberx['username'] || !$memberx['email']) {
			message($lang_usernotexist);
			quit();
		}
		
		##Generating a new pw and update the database
		$newmd5pw = generatepw("6", "12");
		$db->unbuffered_query("UPDATE ".$prefix."users SET pass='$newmd5pw' WHERE (username='$memberx[username]' && email='$memberx[email]')");

		##Sending mail out now
		if(!isset($_SERVER['HTTP_USER_AGENT'])){
		   die("Forbidden - You are not authorized to view this page");
		}
		
		if(!$_SERVER['REQUEST_METHOD'] == "POST"){
		   die("Forbidden - You are not authorized to view this page");
		}
		
		##Server Conf.
		if(strtoupper(substr(PHP_OS, 0, 3) == 'WIN')) {
			$nl_tag = "\r\n";
		} elseif (strtoupper(substr(PHP_OS, 0, 3) == 'MAC')) {
			$nl_tag = "\r";
		} else {
			$nl_tag = "\n";
		}

		##getting headadmin email
		$getemail = $db->query("SELECT email FROM ".$prefix."users WHERE (username='".$settings['headadmin']."')");
		$heademail = $db->fetch_array($getemail);

		$headers = 'From: '.$settings['boardname'].' <'.$heademail['email'].'>'.$nl_tag;
		$headers .= 'Reply-To: '.$settings['boardname'].' <'.$heademail['email'].'>'.$nl_tag; 
		$headers .= 'X-Original-From: '.$settings['boardname'].$nl_tag;
		$headers .= 'X-Mailer: Deluxe Bulletin Board Mailer'.$nl_tag;
		$headers .= 'X-Sender: <'.$heademail['email'].'>'.$nl_tag;
		$headers .= 'X-AntiAbuse: Forum - '.$settings['boardname'].$nl_tag;
		$headers .= 'X-Priority: 2'.$nl_tag;
		$headers .= 'Return-Path: <'.$heademail['email'].'>'.$nl_tag;
		$headers .= 'Content-Type: text/plain; charset='.$lang_charset;

		mail("$memberx[email]", "$lang_lostpwemailtitle", "$lang_lostpwemailtxt1 $memberx[username] $lang_lostpwemailtxt2 $ip $lang_lostpwemailtxt3 \"$settings[boardname]\" $lang_lostpwemailtxt4 $fullpath $lang_lostpwemailtxt5 $newpass $lang_lostpwemailtxt6", $headers);
		message($lang_successfully_resetpw, $lang_successfully_resetpwinfo, "misc.php?sub=login");
	} else {
		bar($bar_lostpw);
		include($templatefolder.'/lostpw_form.dtf');
	}
}

if($sub == 'memberlist') {
	$temptitle = $lang_memberlist;
	$where = 'Memberlist';
	require('./header_html.php');
	bar($bar_memberlist);
	
	$searchuser = $db->escape(removeEvilTags(trim($searchuser)));
	
	if($settings['guestmemfunctions']==0 && usercheck()==FALSE) {
		message($lang_guestnoaccess, $lang_guestnoaccess2);
		quit();
	}
	
	if(!$submit && !$custom) {
		//doing multipage
		$getnum = $db->query("SELECT username FROM ".$prefix."users WHERE (username!='guest' && username!='invisible')");
		$totalrows = $db->num_rows($getnum);
		$pageinfo = multipage($totalrows, $page, $settings['ompp'], 'misc.php?sub=memberlist');

		include($templatefolder.'/memberlist_header.dtf');
		
		$getmembers = $db->query("SELECT * FROM ".$prefix."users WHERE (username!='guest' && username!='invisible') ORDER BY username ASC LIMIT ".$pageinfo['0'].", ".$pageinfo['1']);
		
		while ($members = $db->fetch_array($getmembers)) {
			if($members['hideemail']==0) {
				$email = '<a href="mailto:'.$members['email'].'"><img src="'.$images.'/userbuttons/email.gif" alt="Email" /></a>';
			} elseif($members['hideemail']==2) {
				$email = '<a href="misc.php?sub=emailuser&amp;uid='.$members['uid'].'"><img src="'.$images.'/userbuttons/email.gif" alt="Email" /></a>';
			}
			if($members['site']) {
				if(!stristr($members['site'], 'http://') && !stristr($members['site'], 'https://') && !stristr($members['site'], 'ftp://')) {
					$members['site'] = 'http://'.$members['site'];
				}
				$site = '<a href="'.$members['site'].'" target="_blank"><img src="'.$images.'/userbuttons/site.gif" alt="Site" /></a>';
			}
			if($members['membercode']==1) {
				$status = $lang_member;
			} elseif($members['membercode']==2) {
				$status = $lang_moderator;
			} elseif($members['membercode']==3) {
				$status = $lang_supermoderator;
			} elseif($members['membercode']==4) {
				$status = $lang_administrator;
			} elseif($members['membercode']==5) {
				$status = $lang_headadministrator;
			}
			$name = "<a href=\"misc.php?sub=profile&amp;uid=$members[uid]\">$members[username]</a>";
			$joineddate = gmdate($datecode, $members['joineddate'] + ($member['timeoffset'] * 3600));
			
			include($templatefolder.'/memberlist_fields.dtf');
			
			$site = '';
			$email = '';
			$members['location'] = '';
		}
		include($templatefolder.'/memberlist_footer.dtf');
	} else {
	  $qorder = "";
	  $qfilter = "";
		if($order == "name") { $qorder = "ORDER BY username"; }
		if($order == "regdate") { $qorder = "ORDER BY joineddate"; }
		if($order == "posts") { $qorder = "ORDER BY posts"; }
		if($order == "lastpost") { $qorder = "ORDER BY lastpost"; }
		if($filter == "all") { $qfilter = ""; }
		if($filter == "ad") { $qfilter = "WHERE (membercode>=4)"; }
		if($filter == "admo") { $qfilter = "WHERE (membercode>=2)"; }
		if($filter == "mo") { $qfilter = "WHERE (membercode=3||membercode=2)"; }
		if($filter == "me") { $qfilter = "WHERE (membercode=1)"; }
		if($searchuser!="" && $filter!="all") {
			$qfilter .= " && (username LIKE '%$searchuser%')";
		} elseif($searchuser!="" && $filter=="all") {
			$qfilter = "WHERE (username LIKE '%$searchuser%')";
		}
		if($filter!='all' || $searchuser!='') {
			$qfilter .= " && (username!='guest' && username!='invisible')";
		} else {
			$qfilter = "WHERE (username!='guest' && username!='invisible')";
		}
		if($sort!='ASC' && $sort!='DESC') {
			$sort = 'ASC';
		}
		//doing multipage	
		$getnum = $db->query("SELECT membercode FROM ".$prefix."users ".$qfilter);
		$totalrows = $db->num_rows($getnum);
		$pageinfo = multipage($totalrows, $page, $settings['ompp'], 'misc.php?sub=memberlist&amp;custom=1', "&amp;order=$order&amp;filter=$filter&amp;searchuser=$searchuser&amp;sort=$sort");
		
		include($templatefolder.'/memberlist_header.dtf');
		
		$getsel = $db->query("SELECT * FROM ".$prefix."users ".$qfilter." ".$qorder." ".$sort." LIMIT ".$pageinfo[0].",".$pageinfo[1]);
		while($members = $db->fetch_array($getsel)) {
			if($members['hideemail']==0) {
				$email = '<a href="mailto:'.$members['email'].'"><img src="'.$images.'/userbuttons/email.gif" alt="Email" /></a>';
			} elseif($members['hideemail']==2) {
				$email = '<a href="misc.php?sub=emailuser&amp;uid='.$members['uid'].'"><img src="'.$images.'/userbuttons/email.gif" alt="Email" /></a>';
			}
			if($members['site']) {
				if(!stristr($members['site'], 'http://') && !stristr($members['site'], 'https://') && !stristr($members['site'], 'ftp://')) {
					$members['site'] = 'http://'.$members['site'];
				}
				$site = '<a href="'.$members['site'].'" target="_blank"><img src="'.$images.'/userbuttons/site.gif" alt="Site" /></a>';
			}
			if($members['membercode']==1) {
				$status = $lang_member;
			} elseif($members['membercode']==2) {
				$status = $lang_moderator;
			} elseif($members['membercode']==3) {
				$status = $lang_supermoderator;
			} elseif($members['membercode']==4) {
				$status = $lang_administrator;
			} elseif($members['membercode']==5) {
				$status = $lang_headadministrator;
			}
			$name = "<a href=\"misc.php?sub=profile&amp;uid=$members[uid]\">$members[username]</a>";
			$joineddate = gmdate($datecode, $members['joineddate'] + ($member['timeoffset'] * 3600));
			
			if($members['username'] != 'guest' && $members['username'] != 'invisible') {
				include($templatefolder.'/memberlist_fields.dtf');
			}
			$site = '';
			$email = '';
			$members['location'] = '';
		}
		include($templatefolder.'/memberlist_footer.dtf');
	}
}

if($sub == 'profile') {
	$uid = @intval($uid);
	$name = $db->escape($name);
	
	if(isset($uid) && $uid!=0) {
		$add = "WHERE (uid='$uid')";
	} else {
		$add = "WHERE (username='$name')";
	}

	$getmember = $db->query("SELECT * FROM ".$prefix."users $add");
	$x = $db->fetch_array($getmember);

	$temptitle = $lang_profileinfofor.' '.$x['username'];
	$where = 'Profile of '.$x['username'];

	require('./header_html.php');

	bar($bar_profile.' '.$x['username']);
	
	if($settings['guestmemfunctions']==0 && usercheck()==FALSE) {
		message($lang_guestnoaccess, $lang_guestnoaccess2);
		quit();
	}

	if($db->num_rows($getmember)==0 || $name=='guest' || $uid=0) {
		message($lang_profilenotexist, $lang_forwardmainpage, "index.php");
		quit();
	}

	$list = array('msn','icq','aim','yim','location');
	foreach($list as $element) {
		if($x["$element"]=="") {
			$x["$element"] = "<em>$lang_noinfo</em>";
		}
	}

	if($x['lastpost']==0||$x['lastpost']=='')	{
		$lastpost = "<em>$lang_haventposted</em>";
	} else {
		$lastpost = gmdate($datecode, $x['lastpost'] + ($member['timeoffset'] * 3600));
	}
	
	if($x['membercode']==1) {
		$status = $lang_member;
	} elseif($x['membercode']==2) {
		$status = $lang_moderator;
	} elseif($x['membercode']==3) {
		$status = $lang_supermoderator;
	} elseif($x['membercode']==4) {
		$status = $lang_administrator;
	} elseif($x['membercode']==5) {
		$status = $lang_headadministrator;
	}
	
	if($x['customtitle']=='') {
		$x['customtitle'] = '<em>'.$lang_nocustomtitle.'</em>';
	}
	
	if($x['hideemail']==1) {
		$x['email'] = "<em>$lang_private</em>";
	} elseif($x['hideemail']==2) {
		$x['email'] = "<a href=\"misc.php?sub=emailuser&amp;uid=$x[uid]\">$lang_sendanemail</a>";
	} else {
		$x['email'] = "<a href=\"mailto:$x[email]\">$x[email]</a>";
	}
	
	if($x['site']!='') {
		if(!stristr($x['site'], 'http://') && !stristr($x['site'], 'https://') && !stristr($x['site'], 'ftp://')) {
			$x['site'] = 'http://'.$x['site'];
		}
		$site = "<a href=\"$x[site]\" target=\"blank\">$lang_visithomepage</a>";
	} else {
		$site = "<em>$lang_noinfo</em>";
	}
	
	##caching ranks
	prepareranks();
	
	//user ranks
	if($settings['userranks']!=0) {
		$checktitle = '';
		switch ($open['membercode']) {
			case(2): $checktitle = "Moderator"; break;
			case(3): $checktitle = "Super Moderator"; break;
			case(4): $checktitle = "Administrator"; break;
			case(5): $checktitle = "Head Admin"; break;
		}

		if($checktitle!='') {
			$rankinfo = explode(",", $specialrank[$checktitle]);
		} elseif($x['uid'] == 0) {
			$rankinfo = '';
		} else {
			foreach ($userrank as $key => $rinfo) {
				if($x['posts'] >= $key) {
					$rankinfo = explode(",", $rinfo);
				}
			}
		}
	}

	if($rankinfo[4]!=0 || $settings['userranks']==0) {
		if(!$x['avatar']||$x['avatar']=="") {
			$topavatar = '<em>'.$lang_noavatar.'</em>';
		} else {
			$topavatar = '<img src="'.$x['avatar'].'" alt="Avatar" />';
		}
	} else {
		$topavatar = '<em>'.$lang_noavatar.'</em>';
	}
	
	if($rankinfo[5]!=0 || $settings['userranks']==0) {
		if(!$x['sig']) {
			$sig = "<em>$lang_nosig</em>";
		} else {
			bbcodecache();
			$sig = $x['sig'];
			if($settings['sightml']!=1) {
				$donewline = 1; //now the bbcode function adds newline tags
				$sig = html($sig);
			}
			$sig = bbcode($sig);
		}
	} else {
		$sig = "<em>$lang_nosig</em>";
	}
	
	/* doing stats */
	$getallposts = $db->query("SELECT COUNT(pid) FROM ".$prefix."posts");
	$allposts = $db->result($getallposts, 0);

	//joineddate
	$joineddate = gmdate($datecode, $x['joineddate'] + ($member['timeoffset'] * 3600));
	
	//lastactive
	$lastactive = gmdate($datecode, $x['lastactive'] + ($member['timeoffset'] * 3600));
	
	//posts per day
	$ppd = $x['posts'] / ((time() - $x['joineddate']) / 86400);
	$ppd = number_format($ppd, 2);
	
	//% of total posts
	if($allposts!=0) {
		$percentoftotal = ($x['posts']/$allposts) * 100;
	}
	$percentoftotal = number_format($percentoftotal, 2);
	
	include($templatefolder.'/profile.dtf');
}

if($sub == 'viewposts' && isset($uid) && $uid!=0) {
	$uid = @intval($uid);
	//doing multipage
	$getnum = $db->query("SELECT COUNT(*) AS count, u.username FROM ".$prefix."forums f LEFT JOIN ".$prefix."threads t ON (f.fid=t.fid) LEFT JOIN ".$prefix."posts p ON (t.tid=p.tid) LEFT JOIN ".$prefix."users u ON (p.author=u.uid) WHERE ((p.author='$uid' || t.author='$uid') && f.password='' && f.redirect='' && u.uid='$uid' && t.moved=0) GROUP BY t.tid");
	$totalrows = $db->fetch_array($getnum);
	$rows = $db->num_rows($getnum);
	$pageinfo = multipage($rows, $page, $settings['ompp'], 'misc.php?sub=viewposts', "&amp;uid=$uid");
	
	//now sending headers
	$temptitle = $lang_viewingpostsof.' '.$totalrows['username'];
	$where = 'Viewing posts of '.$totalrows['username'];
	
	require('./header_html.php');
	bar($bar_view_posts.' '.$totalrows['username']);

	if($settings['guestmemfunctions']==0 && usercheck()==FALSE) {
		message($lang_guestnoaccess, $lang_guestnoaccess2);
		quit();
	}
	
	if($name=='guest') {
		message($lang_profilenotexist, $lang_forwardmainpage, 'index.php');
		quit();
	}

	if($settings['censors']!=0) {
		bbcodecache();
	}
	
	include($templatefolder.'/viewposts_header.dtf');
	
	$getinfo = $db->query("SELECT t.*,f.viewstatus,f.userlist,u.uid,u.username FROM ".$prefix."forums f LEFT JOIN ".$prefix."threads t ON (f.fid=t.fid) LEFT JOIN ".$prefix."posts p ON (t.tid=p.tid) LEFT JOIN ".$prefix."users u ON (t.author=u.uid) WHERE ((p.author='$uid' || t.author='$uid') && f.password='' && f.redirect='' && t.moved=0) GROUP BY t.tid ORDER BY t.lastpostdate DESC LIMIT ".$pageinfo[0].",".$pageinfo[1]);
	while($open = $db->fetch_array($getinfo)) {
		if(access($member['username'], $member['membercode'], $open['viewstatus'], '', '', $open['userlist'])) {
			##censoring
			if($settings['censors']!=0) {
				$open['subject'] = bbcode($open['subject'], 1);
			}
			
			$open['subject'] = $open['subject'];
			$date = gmdate($datecode, $open['lastpostdate'] + ($member['timeoffset'] * 3600));
			$time = gmdate($timecode, $open['lastpostdate'] + ($member['timeoffset'] * 3600));
			$thetime = "$date $lang_at $time";
			
			if($open['author']!=0) {
				$authorinfo = '<a href="misc.php?sub=profile&amp;uid='.$open['author'].'">'.$open['username'].'</a>';
			} else {
				$authorinfo = $lang_guest;
			}

			if($open['lastpostby']!='guest') {
				$lastpostinfo = '<a href="misc.php?sub=profile&amp;name='.$open['lastpostby'].'">'.$open['lastpostby'].'</a><br />'.$thetime;
			} else {
				$lastpostinfo = $lang_guest.'<br />'.$thetime;
			}
			include($templatefolder.'/viewposts_fields.dtf');
		}
	}
	include($templatefolder.'/viewposts_footer.dtf');
}

if($sub == 'stats') {
	$temptitle = $lang_statstext;
	$where = 'Stats';
	require('./header_html.php');
	bar($bar_stats);
	
	if($settings['guestmemfunctions']==0 && usercheck()==FALSE) {
		message($lang_guestnoaccess, $lang_guestnoaccess2);
		quit();
	}
	
	##caching censors
	if($settings['censors']!=0) {
		bbcodecache();
	}
	
	##If a user doesnt have the permissions for that forum how many alternative topics should it try to load?
	$buffer = 5;
	
	// first member
	$getfirst = $db->query("SELECT joineddate FROM ".$prefix."users WHERE joineddate!=0 ORDER BY joineddate LIMIT 0, 1");
	$first = $db->fetch_array($getfirst);
	
	// newest member
	$getnewestmember = $db->query("SELECT whenof FROM ".$prefix."boardstats WHERE (nameof = 'members')");
	$newestmember = $db->result($getnewestmember, 0);
	
	// most online
	$getrecordonline = $db->query("SELECT whatof,whenof FROM ".$prefix."boardstats WHERE (nameof = 'recordonline')");
	$recordonline = $db->fetch_array($getrecordonline);
	$date = gmdate($datecode, $recordonline['whenof'] + ($member['timeoffset'] * 3600));
	$time = gmdate($timecode, $recordonline['whenof'] + ($member['timeoffset'] * 3600));
	$mostonline = "$recordonline[whatof] $lang_seton $date $lang_at $time";
	
	// num of users
	$getallmembers = $db->query("SELECT COUNT(*) FROM ".$prefix."users WHERE (username!='guest' && username!='invisible')");
	$num_members = $db->result($getallmembers, 0);
	
	// num of forums
	$getallforums = $db->query("SELECT COUNT(fid) FROM ".$prefix."forums");
	$num_forums = $db->result($getallforums, 0);
	
	// num of threads and replies
	$getallthreads = $db->query("SELECT COUNT(tid) FROM ".$prefix."threads");
	$num_threads = $db->result($getallthreads, 0);
	$getallposts = $db->query("SELECT COUNT(pid) FROM ".$prefix."posts");
	$num_posts = $db->result($getallposts, 0)-$num_threads;
	
	// posts per member
	$allposts = $num_posts+$num_threads; 
	$ppmd = ($allposts / $num_members);
	
	// posts per thread	
	if($num_threads!=0) {
		$pptd = ($num_posts / $num_threads);
	} else {
		$pptd=0;
	}
	
	// threads per forum
	if($num_forums!=0) {
		$tpfd = ($num_threads / $num_forums);
	} else {
		$tpfd=0;
	}
	
	// posts per day
	if($allposts!=0) {
		$ppd = $allposts / ((time() - $first['joineddate']) / 86400);
	}
	
	// % of all members who posted
	$count=0;
	$getmem = $db->query("SELECT posts FROM ".$prefix."users WHERE (username!='guest' && username!='invisible')");
	while($mem = $db->fetch_array($getmem)) {
		if($mem['posts']>0) {
			$count++;
		}
	}
	$pomwp = ($count/$num_members)*100;
	
	// average ammount of new members per day
	$mpd = $num_members / ((time() - $first['joineddate']) / 86400);
	
	// avarage length of posts
	$query = $db->query("SELECT message FROM ".$prefix."posts");
	while($x = $db->fetch_array($query)) {
		$sl = strlen($x['message']);
		$wl += $sl;
	}
	if($allposts!=0) {
		$avl = $wl / $allposts;
	} else {
		$avl=0;
	}
	
	// top 5 posters
	$topfivep = '';
	$query = $db->query("SELECT username,uid,posts FROM ".$prefix."users WHERE (username!='guest' && username!='invisible' && posts!='0') ORDER BY posts DESC LIMIT 0, 5");
	while($the = $db->fetch_array($query)) {
		$topfivep .= "<a href=\"misc.php?sub=profile&amp;uid=$the[uid]\">$the[username]</a> - $the[posts]<br />";
	}	
	
	$max = 5 + $buffer;
	
	// top 5 most viewed topics
	$num = 0;
	$topfivevt = '';
	$query = $db->query("SELECT tid,fid,subject,views FROM ".$prefix."threads WHERE (views!='0' && moved=0) ORDER BY views DESC LIMIT 0, $max");
	while($the = $db->fetch_array($query)) {
		if($num<5) {
			$getfinfo = $db->query("SELECT viewstatus,userlist FROM ".$prefix."forums WHERE (fid='$the[fid]' && password='' && redirect='')");
			$finfo = $db->fetch_array($getfinfo);
			if(access($_COOKIE['membercookie'], $member['membercode'], $finfo['viewstatus'], '', '', $finfo['userlist'])) {
				$num++;
				##censoring
				if($settings['censors']!=0) {
					$the['subject'] = bbcode($the['subject'], 1);
				}
				$topfivevt .= "<a href=\"topic.php?tid=$the[tid]\">$the[subject]</a> - $the[views]<br />";
			}
		}
	}
	
	// top 5 most replied to topics
	$num = 0;
	$topfiver = '';
	$query = $db->query("SELECT tid,fid,subject,replies FROM ".$prefix."threads WHERE (replies!='0' && moved=0) ORDER BY replies DESC LIMIT 0, $max");
	while($the = $db->fetch_array($query)) {
		if($num<5) {
			$getfinfo = $db->query("SELECT viewstatus,userlist FROM ".$prefix."forums WHERE (fid='$the[fid]' && password='')");
			$finfo = $db->fetch_array($getfinfo);
			if(access($_COOKIE['membercookie'], $member['membercode'], $finfo['viewstatus'], '', '', $finfo['userlist'])) {
				$num++;
				##censoring
				if($settings['censors']!=0) {
					$the['subject'] = bbcode($the['subject'], 1);
				}
				$topfiver .= "<a href=\"topic.php?tid=$the[tid]\">$the[subject]</a> - $the[replies]<br />";
			}
		}
	}
	
	// 5 latest topics
	$num = 0;
	$fivelatest = '';
	$query = $db->query("SELECT tid,fid,subject,lastpostdate FROM ".$prefix."threads WHERE moved=0 ORDER BY lastpostdate DESC LIMIT 0, $max");
	while($the = $db->fetch_array($query)) {
		if($num<5) {
			$getfinfo = $db->query("SELECT viewstatus,userlist FROM ".$prefix."forums WHERE (fid='$the[fid]' && password='' && redirect='')");
			$finfo = $db->fetch_array($getfinfo);
			if(access($_COOKIE['membercookie'], $member['membercode'], $finfo['viewstatus'], '', '', $finfo['userlist'])) {
				$num++;
				##censoring
				if($settings['censors']!=0) {
					$the['subject'] = bbcode($the['subject'], 1);
				}
				$date = gmdate($datecode, $the['lastpostdate'] + ($member['timeoffset'] * 3600));
				$time = gmdate($timecode, $the['lastpostdate'] + ($member['timeoffset'] * 3600));
				$thetime = "$date $lang_at $time";
				$fivelatest .= "<a href=\"topic.php?tid=$the[tid]\">$the[subject]</a> - $thetime<br />";
			}
		}
	}
	
	// members online in last 24 hours
	$timestamp = time() - 86400;
	$lastonline24 = '';
	$counter = 0;
	$query = $db->query("SELECT username,uid FROM ".$prefix."users WHERE (username!='guest' && username!='invisible' && lastactive>='$timestamp') ORDER BY username ASC");
	$num_rows = $db->num_rows($query);
	while($the = $db->fetch_array($query)) {
		$counter++;
		$lastonline24 .= '<a href="misc.php?sub=profile&amp;uid='.$the['uid'].'">'.$the['username'].'</a>';
		if($num_rows > $counter) {
			$lastonline24 .= ', ';
		}
	}	
		
	// general format
	$ppm = number_format($ppmd, 2);
	$ppt = number_format($pptd, 2);
	$tpf = number_format($tpfd, 2);
	$mpd = number_format($mpd, 2);
	$avl = number_format($avl, 2);
	$ppd = number_format($ppd, 2);
	$pomwp = number_format($pomwp, 2);
	include($templatefolder.'/stats.dtf');
}

if($sub == "search") {
	$temptitle = 'Search';
	$where = $lang_search;
	require('./header_html.php');
	
	##escaping
	$text = $db->escape($text);

	bar($bar_search);
	
	if($settings['guestmemfunctions']==0 && usercheck()==FALSE) {
		message($lang_guestnoaccess, $lang_guestnoaccess2);
		quit();
	}
	
	if($submit==$lang_search || $page) {
		##caching censors
		if($settings['censors']!=0) {
			bbcodecache();
		}
				
		//calculating the unixtime
		if($age!='beginning') {
			$stamp = time()-(86400*$age);
		} else {
			$stamp = 0;
		}
		$multipagestr .= '&age='.$age;
						
		//removing common words
		$text = trim($text);
		if($combine!='exact') {
			$text = str_replace($common_words. ' ', '', $text);
			$text = str_replace(' '.$common_words, '', $text);
		}
		
		//advanced search
		if($combine!='exact' && $regexp!=1) {
			$words = explode(' ', $text);
			$words = @array_filter($words);
			if($combine == 'all') {
				foreach($words as $x) {
					//where to search
					if($show=='both') {
						$additions .= " && (p.message LIKE '%$x%' || t.subject LIKE '%$x%')";
					} elseif($show=='titles') {
						$additions .= " && t.subject LIKE '%$x%'";
					} elseif($show=='posts') {
						$additions .= " && p.message LIKE '%$x%'";
					}
				}
			} else {
				$counter = 0;
				$additions .= ' && (';
				foreach($words as $x) {
					if($counter!=0) {
						$additions .= ' ||';
					}
					//where to search
					if($show=='both') {
						$additions .= "(p.message LIKE '%$x%' || t.subject LIKE '%$x%')";
					} elseif($show=='titles') {
						$additions .= "t.subject LIKE '%$x%'";
					} elseif($show=='posts') {
						$additions .= "p.message LIKE '%$x%'";
					}
					$counter++;
				}
				$additions .= ')';
			}
		} elseif($regexp==1) {
			$multipagestr .= '&regexp=1';
			if($show=='both') {
				$additions .= " && (p.message REGEXP '$text' || t.subject REGEXP '$text')";
			} elseif($show=='titles') {
				$additions .= " && t.subject REGEXP '$text'";
			} elseif($show=='posts') {
				$additions .= " && p.message REGEXP '$text'";
			}
		} elseif($combine=='exact') {
			if($show=='both') {
				$additions .= " && (p.message LIKE '%$text%' || t.subject LIKE '%$text%')";
			} elseif($show=='titles') {
				$additions .= " && t.subject LIKE '%$text%'";
			} elseif($show=='posts') {
				$additions .= " && p.message LIKE '%$text%'";
			}
		}
		$multipagestr .= '&amp;text='.$text.'&amp;show='.$show.'&amp;combine='.$combine;

		
		//not containing
		if($notcontaining!='') {
			$notcontaining = $db->escape($notcontaining);
			$counter = 0;
			$words = explode(' ', $notcontaining);
			$words = @array_filter($words);
			$additions .= ' && (';
			foreach($words as $x) {
				if($counter!=0) {
					$additions .= ' ||';
				}
				//where to search
				if($show=='both') {
					$additions .= " (p.message NOT LIKE '%$x%' && t.subject NOT LIKE '%$x%')";
				} elseif($show=='titles') {
					$additions .= " t.subject NOT LIKE '%$x%'";
				} elseif($show=='posts') {
					$additions .= " p.message NOT LIKE '%$x%'";
				}
				$counter++;
			}
			$additions .= ')';
			$multipagestr .= '&amp;notcontaining='.$notcontaining;
		}
		
		//user
		if($user!='') {
			$user = $db->escape($user);
			if($usercheck=='exact') {
				$additions .= " && u.username='$user'";
			} else {
				$additions .= " && u.username LIKE '%$user%'";
			}
			$multipagestr .= '&amp;user='.urlencode($user).'&amp;usercheck='.$usercheck;
		}

		if($theforum!='allforums') {
			$theforum = $db->escape($theforum);
			$additions .= " && t.fid = '$theforum'";
		}
		$multipagestr .= '&theforum='.$theforum;
		
		//sort
		$x = '';
		$y = '';
		if($order == 'username') { $x = 'u.username'; }
		if($order == 'title') { $x = 't.subject'; }
		if($order == 'postdate') { $x = 't.lastpostdate'; }
		if($order == 'replies') { $x = 't.replies'; }
		if($order == 'views') { $x = 't.views'; }
		if($ascdesc == 'asc') { $y = 'ASC'; }
		if($ascdesc == 'desc') { $y = 'DESC'; }
		$sort = 'ORDER BY '.$x.' '.$y;
		$multipagestr .= '&amp;order='.$order.'&amp;ascdesc='.$ascdesc;
		
		//permissions
		if($member['membercode']==(4||5)) {
			$additions .= " && (f.viewstatus != 'no'";
    } elseif($member['membercode']==(2||3)) {
    	$additions .= " && ((f.viewstatus != 'no' && f.viewstatus != 'ad')";
    } elseif($member['membercode']==1) {
      $additions .= " && ((f.viewstatus = 'me' || f.viewstatus = 'all')";
		} else {
		  $additions .= " && (f.viewstatus = 'all'";
    }
    $additions .= " && (f.userlist LIKE '".$member['username'].", ' || f.userlist LIKE ', ".$member['username']."' || f.userlist='".$member['username']."' || f.userlist=''))";
		
		//setting up multipage and getting number of matches b4 we do the main query
		$getnum = $db->query("SELECT count(*) FROM ".$prefix."forums f LEFT JOIN ".$prefix."threads t ON (f.fid=t.fid) LEFT JOIN ".$prefix."posts p ON (t.tid=p.tid) LEFT JOIN ".$prefix."users u ON (t.author=u.uid) WHERE (t.lastpostdate>='$stamp' && f.redirect='' && f.password=''".$additions.") GROUP BY t.tid");
		$totalrows = $db->num_rows($getnum);
		$pageinfo = multipage($totalrows, $page, $settings['ompp'], 'misc.php?sub=search', $multipagestr);
		
		//THE query
		$query = $db->query("SELECT t.*,f.viewstatus,f.userlist,u.uid,u.username FROM ".$prefix."forums f LEFT JOIN ".$prefix."threads t ON (f.fid=t.fid) LEFT JOIN ".$prefix."posts p ON (t.tid=p.tid) LEFT JOIN ".$prefix."users u ON (t.author=u.uid) WHERE (t.lastpostdate>='$stamp' && f.redirect='' && f.password=''".$additions." && t.moved='0') GROUP BY t.tid ".$sort." LIMIT ".$pageinfo[0].",".$pageinfo[1]);
		
		//displaying results
		include($templatefolder.'/search_header.dtf');
		while($results = $db->fetch_array($query)) {
			$date = gmdate($datecode, $results['lastpostdate'] + ($member['timeoffset'] * 3600));
			$time = gmdate($timecode, $results['lastpostdate'] + ($member['timeoffset'] * 3600));
			$thetime = "$date $lang_at $time";
			if(access($member['username'], $member['membercode'], $results['viewstatus'], '', '',  $results['userlist'])) {
				if($results['author']!=0) {
					$author = "<a href=\"misc.php?sub=profile&amp;uid=$results[author]\">$results[username]</a>";
				} else {
					$author = $lang_guest;
				}
				if($results['lastpostby']!='guest') {
					$lastpost = "<a href=\"misc.php?sub=profile&amp;name=".urlencode($results['lastpostby'])."\">$results[lastpostby]</a>";
				} else {
					$lastpost = $lang_guest;
				}
				
				##censoring
				if($settings['censors']!=0) {
					$results['subject'] = bbcode($results['subject'], 1);
				}

				include($templatefolder.'/search_fields.dtf');
			}
		}
		include($templatefolder.'/search_footer.dtf');	
	} else {
		$getcat = $db->query("SELECT name,cid FROM ".$prefix."categories ORDER BY ordered,cid ASC");
		$flist = "<option value=\"\">------------------------------</option>\n";
		while($cat = $db->fetch_array($getcat)) {
			$cat['name'] = stripslashes($cat['name']);
			$flist .= "<option value=\"\">$cat[name]</option>\n";
			$getf = $db->query("SELECT fid,name,viewstatus,userlist FROM ".$prefix."forums WHERE (cid='$cat[cid]') ORDER BY ordered,fid ASC");
			while($f = $db->fetch_array($getf)) {
				if(access($member['username'], $member['membercode'], $f['viewstatus'], '', '',  $f['userlist'])) {
					$flist .= "<option value=\"$f[fid]\">---".stripslashes($f['name'])."</option>\n";
				}
			}
		}
		$flist .= "<option value=\"\">------------------------------</option>\n";
		include($templatefolder.'/search.dtf');
	}
}

if($sub == 'markread') {
	$temptitle = $lang_markread;
	setcookie("lastvisitb", $time, $time+($member['markposts']*60), $cp, $cd, $cs);
	require('./header_html.php');
	bar($bar_mark_posts);
	message($lang_postssuccessfullymarked, $lang_forwardmainpage, "index.php", 1);
}

if($sub == 'faq') {
	$temptitle = $lang_faq_long;
	$where = 'Faq';
	require('./header_html.php');
	bar($bar_faq);
	include($templatefolder.'/faq.dtf');
}

if($sub == 'online') {
	$temptitle = $lang_onlinelist;
	$where = 'Viewing Online List';
	require('./header_html.php');
	bar($bar_onlinelist);
	
	if($settings['guestmemfunctions']==0 && usercheck()==FALSE) {
		message($lang_guestnoaccess, $lang_guestnoaccess2);
		quit();
	}
	
	if($settings['showlocation']==0) {
		message($lang_function_disabled, $lang_forwardmainpage, "index.php", 2);
		quit();
	}

	include($templatefolder.'/onlinelist_header.dtf');
	$getmembers = $db->query("SELECT * FROM ".$prefix."online ORDER BY time DESC");

	while($members = $db->fetch_array($getmembers)) {
		$where = $members['wherein'];
		if($members['name']=='invisible') {
			$name = $lang_invisibleuser;
			$where = '&nbsp;';
		} elseif($members['name']=='guest') {
			$name = $lang_guest;
		} else {
			$name = '<a href="misc.php?sub=profile&amp;name='.urlencode($members['name']).'">'.$members['name'].'</a>';
		}
		
		
		$date = gmdate($datecode, $members['time'] + ($member['timeoffset'] * 3600));
		$time = gmdate($timecode, $members['time'] + ($member['timeoffset'] * 3600));
		$thetime = "$date $lang_at $time";
		
		include($templatefolder.'/onlinelist_fields.dtf');
	}
	include($templatefolder.'/onlinelist_footer.dtf');
}


if($sub == 'emailuser') {
	$temptitle = $lang_emailuser;
	$where = 'Email User';
	require('./header_html.php');
	
	if($settings['guestmemfunctions']==0 && usercheck()==FALSE) {
		bar($bar_emailuser);
		message($lang_guestnoaccess, $lang_guestnoaccess2);
		quit();
	}

	if(usercheck()==FALSE || !is_numeric($uid) || $uid==0) {
		bar($bar_identerror);
		message($lang_wronguserorpass, $lang_wronguserorpassinfo);
		quit();
	}
	
	if($submit!=$lang_send) {
		$getreceiver = $db->query("SELECT username FROM ".$prefix."users WHERE (uid='".$uid."')");
		$receiver = $db->fetch_array($getreceiver);
		
		bar($bar_emailuser);
		include($templatefolder.'/formemail.dtf');
	} else {
		##Security Checks
		if(!isset($_SERVER['HTTP_USER_AGENT'])){
		   die("Forbidden - You are not authorized to view this page");
		}
		
		if(!$_SERVER['REQUEST_METHOD'] == "POST"){
		   die("Forbidden - You are not authorized to view this page");
		}
		
		##Server Conf.
		if(strtoupper(substr(PHP_OS, 0, 3) == 'WIN')) {
			$nl_tag = "\r\n";
		} elseif (strtoupper(substr(PHP_OS, 0, 3) == 'MAC')) {
			$nl_tag = "\r";
		} else {
			$nl_tag = "\n";
		}

		##getting sender email
		$getsenderemail = $db->query("SELECT email,username FROM ".$prefix."users WHERE (username='".$_COOKIE['membercookie']."')");
		$senderemail = $db->fetch_array($getsenderemail);

		$getreceiveremail = $db->query("SELECT email FROM ".$prefix."users WHERE uid='".$uid."'");
		$receiveremail = $db->result($getreceiveremail,0);
		$to = "<$receiveremail>";

		$headers = 'From: '.$senderemail['username'].' <'.$senderemail['email'].'>'.$nl_tag;
		$headers .= 'Reply-To: '.$senderemail['username'].' <'.$senderemail['email'].'>'.$nl_tag; 
		$headers .= 'X-Original-From: '.$senderemail['username'].$nl_tag;
       	$headers .= 'X-Mailer: Deluxe Bulletin Board Mailer'.$nl_tag;
       	$headers .= 'X-Sender: <'.$senderemail['email'].'>'.$nl_tag;
		$headers .= 'X-AntiAbuse: Forum - '.$settings['boardname'].$nl_tag;
		$headers .= 'X-Priority: 2'.$nl_tag;
		$headers .= 'Return-Path: <'.$senderemail['email'].'>'.$nl_tag;
		$headers .= 'Content-Type: text/plain; charset='.$lang_charset;

		if(!eregi("\r",$to) && !eregi("\n",$to) && isemail($receiveremail) && isemail($senderemail['email'])){	
			@mail($to, $subject, $message, $headers);
		} else {
			message($lang_badmailinput, $lang_badmailinput2);
			quit();
		}
		
		bar($bar_emailuser);
		message($lang_emailsent, $lang_forwardmainpage, "index.php");
	}
}

if($sub == 'valemail') {
	$temptitle = $lang_login;
	$where = 'Validating Email';
	require('./header_html.php');
	
	$valnum = $db->escape($valnum);
	$valmem = @intval($valmem);
	
	if($valmem!='' && $valnum!='') {
		$checkname = $db->query("SELECT uid FROM ".$prefix."users WHERE (uid='$valmem' && valnum='$valnum')");
		$getquery = $db->fetch_array($checkname);
		if(!$db->num_rows($getquery)==1) {
			$db->unbuffered_query("UPDATE ".$prefix."users SET valnum=NULL WHERE (uid='$valmem')");
			
			bar($bar_validatingemail);
			message($lang_emailversuccess, $lang_forwardlogin, "misc.php?sub=login");
		} else {
			bar($bar_validatingemail);
			message($lang_emailvererror2);
		}
	} else {
		bar($bar_validatingemail);
		message($lang_emailvererror2);
	}
}		

require('./footer.php');

?>