<?php
  functions::draw_lightbox();

  $box_region = new ent_view();

  echo $box_region->stitch('views/box_region');
