<?php
$PHORUM["DATA"]["LANG"]["mod_smileys"] = array(
    'smiley'        => 'Smiley einfuegen',
    'subjectsmiley' => 'Smiley im Betreff einfuegen',
    'smileys help'  => 'Smileys Hilfe',

    # Text for the smileys disable option in the posting editor.
    'disable'      => 'Disable smileys for this message'
);
?>
