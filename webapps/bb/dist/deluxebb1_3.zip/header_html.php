<?php

/************************************************
/************************************************
 * DeluxeBB 1.3                                 *
 * Copyright (C) 2005-2009 Frank Nissel         *
 * http://www.DeluxeBB.com	                    *
 * For license information, please read the     *
 * license file in the docs/ folder! 			      *
 ************************************************/


online($where, $member['invisible']);
$title = "$settings[boardname] - $temptitle --- powered by DeluxeBB";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
     "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="<?php echo $lang_direction; ?>">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $lang_charset; ?>" />
<meta name="description" content="powered by DeluxeBB - www.deluxebb.com" />
<title><?php echo $title; ?></title>
<link href="<?php echo $images; ?>/css/main.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $images; ?>/css/<?php echo $cssstyle; ?>" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php echo $templatefolder; ?>/showimage.js"></script>
</head>
<!-- |-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|
     | This forum is coded by and          |
     | copyrighted to Frank Nissel         |
     | more information, news and updates: |
     | www.deluxebb.com                    |
     | for licence information read the    |
     | file which came with DeluxeBB!      |
     |-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-|-| -->
<body>
<a name="top"></a>

<?php
if($count) {
	include($templatefolder.'/newpm.dtf');
}

if($logourl!='') {
	if(!stristr($logourl, 'http://') && !stristr($logourl, 'https://')) {
		$logourl = $images.'/'.$logourl;
	}
$boardlogo = '<a href="index.php"><img src="'.$logourl.'" alt="Logo" /></a>';
}

if($member['membercode']>=4) {
	include($templatefolder.'/header_admin.dtf');
} elseif($member['membercode']==3||$member['membercode']==2||$member['membercode']==1) {
	include($templatefolder.'/header_loggedin.dtf');
	$offline++;
} else {
	include($templatefolder.'/header_notloggedin.dtf');
	$offline++;
}

if($settings['maintenance']==1 && $offline>0 && !isset($maintenance)) {
	bar($bar_maintenance);
	$footer = FALSE;
	$settings['maintenancemsg'] = nl2br($settings['maintenancemsg']);
	message($settings['maintenancemsg'], '', '', '', '');
	quit();
}

if(value_exists($banned)) {
	message($lang_youarebanned);
	quit();
}

?>