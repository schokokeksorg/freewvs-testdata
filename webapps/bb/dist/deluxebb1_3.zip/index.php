<?php

/************************************************
 * DeluxeBB 1.3                                 *
 * Copyright (C) 2005-2009 Frank Nissel         *
 * http://www.DeluxeBB.com	                    *
 * For license information, please read the     *
 * license file in the docs/ folder! 			      *
 ************************************************/


$footer = TRUE;
$cssstyle = 'index.css';
require('./header.php');
$temptitle = $lang_mainpage;
$where = "Main Page";
require('./header_html.php');

##navigation bar
bar();

##guests allowed to see forums?
if($settings['guestforumview']==0 && usercheck()==FALSE) {
	message($lang_guestnoaccess, $lang_guestnoaccess2);
	quit();
}

//initialising
$cfirst=0;
$cexist=0;

if($limit!='') {
	if(is_numeric($limit)) {
		$limit = " WHERE c.cid=".$limit;
	} else {
		$limit = '';
	}
}
//one query for all cats and forums
$categories2 = $db->query("SELECT c.name AS catname,c.cid,f.name,f.fid,f.topics,f.replies,f.viewstatus,f.lastpostby,f.description,f.lastpid,f.lastpidtime,f.password,f.userlist,f.moderators,u.username FROM ".$prefix."categories c LEFT JOIN ".$prefix."forums f ON (f.cid=c.cid) LEFT JOIN ".$prefix."users u ON (f.lastpostby=u.uid)".$limit." ORDER BY c.ordered,c.cid,f.ordered,f.fid");
while($post = $db->fetch_array($categories2)) {
	//create space between cats
	if($cexist!=$post['cid'] && $cfirst==1) {
		include($templatefolder.'/catbreak.dtf');
	}
	//create cat
	if($cexist!=$post['cid']) {
		include($templatefolder.'/categories.dtf');
		$cexist=$post['cid'];
		$cfirst=1;
	}
	
	$modbar = '';
	$display=1;
	if(!access($member['username'], $member['membercode'], $post['viewstatus'], '', '', $post['userlist']) || ((!$_COOKIE['membercookie'] || $_COOKIE['membercookie']=="") && $post['password']!='')) {
		if($settings['hideprivf']==1) {
			$display=0;
		} else {
			$image = '<img src="'.$images.'/lock_folder.gif" alt="Locked folder" />';
		}
	} else {
		$image = lastvisit();
	}
	if($display!=0) {
		//lastpost & moderator stuff
		if($post['lastpidtime'] != '') {
			$date = gmdate($datecode, $post['lastpidtime'] + ($member['timeoffset'] * 3600));
			$time = gmdate($timecode, $post['lastpidtime'] + ($member['timeoffset'] * 3600));
			$lp1 = "$date $lang_at $time";
		} else {
			$lp1 = $lang_noposts;
		}
		if($post['lastpostby']!=0) {
			$lp2 = "$lang_by <a href=\"misc.php?sub=profile&amp;uid=$post[lastpostby]\">".$post['username']."</a>";
		} elseif($post['topics']!=0) {
			$lp2 = "$lang_by $lang_guest";
		}
		if($post['lastpidtime'] != '') {
			$lp3 = '<a href="topic.php?tid='.$post['lastpid'].'&amp;lastpost=1"><img src="'.$images.'/lastpost.gif" alt="Lastpost" /></a>';
		} else {
			$lp3 = '<a href="#"><img src="'.$images.'/lastpost.gif" alt="Lastpost" /></a>';
		}
		if($post['moderators']!='' && $settings['showmod']!=0) {
			$mod = explode(", ", $post['moderators']);
			$modbar = "($lang_modlist ";
			for($x=0;$x<sizeof($mod);$x++) {
				if(sizeof($mod)-1==$x) {
					$modbar .= "<a href=\"misc.php?sub=profile&amp;name=".urlencode($mod[$x])."\">$mod[$x]</a>";
				} else {
					$modbar .= "<a href=\"misc.php?sub=profile&amp;name=".urlencode($mod[$x])."\">$mod[$x]</a>, ";
				}
			}
			$modbar .= ')';
		}
		include($templatefolder.'/forums.dtf');
	}
	$lp2 = '';
}

include($templatefolder.'/catbreak.dtf');

$currentonline = formatonline();

$getrecordonline = $db->query("SELECT * FROM ".$prefix."boardstats");
while($recordonline = $db->fetch_array($getrecordonline)) {
	if($recordonline['nameof']=='members') {
		$newestmem = $recordonline['whenof'];
		$memcount = $recordonline['whatof'];
	} elseif($recordonline['nameof']=='recordonline') {
		if($currentonline['4']>=$recordonline['whatof']) {
			$db->unbuffered_query("UPDATE ".$prefix."boardstats SET whatof='$currentonline[4]', whenof='".time()."' WHERE (nameof='recordonline')");
		}
	}
}

$getallthreads = $db->query("SELECT COUNT(tid) FROM ".$prefix."threads WHERE moved=0");
$num_threads = $db->result($getallthreads, 0);
$getallposts = $db->query("SELECT COUNT(pid) FROM ".$prefix."posts");
$num_posts = $db->result($getallposts, 0)-$num_threads;

if($currentonline[0]=='') {
	$currentonline[0]='&nbsp;';
}

if((($settings['guestmemfunctions']!=0 && usercheck()==FALSE) || usercheck()==TRUE) && $settings['allowonline']!=0) {
	include($templatefolder.'/stats_mainpage.dtf');
}

include('./footer.php');

?>