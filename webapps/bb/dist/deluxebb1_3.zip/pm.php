<?php

/************************************************
 * DeluxeBB 1.3                                 *
 * Copyright (C) 2005-2009 Frank Nissel         *
 * http://www.DeluxeBB.com	                    *
 * For license information, please read the     *
 * license file in the docs/ folder! 			      *
 ************************************************/

if(stristr($REQUEST_URI, 'post=')) {
	exit();
}

$cssstyle = 'pm.css';
require('./header.php');
$temptitle = $lang_pm;
$where = 'In Private Messenger';
require('./header_html.php');
bbcodecache();


##private messaging allowed?
if($settings['allowpm']==0) {
	bar($bar_pm);
	message($lang_function_disabled);
	quit();
}

if(!usercheck()) {
	bar($bar_pm_identerror);
	message($lang_wronguserorpass, $lang_wronguserorpassinfo, "index.php");
	quit();
}

if(!$sub) {
	bar($bar_pm);
	##initialising values
	$inbox_read=0;$inbox_notread=0;$outbox_read=0;$outbox_notread=0;$saves_read=0;$saves_notread=0;$track_notread=0;$track_read=0;
	$getpm = $db->query("SELECT type,hasread FROM ".$prefix."pm WHERE (whoto='".$_COOKIE['membercookie']."')");
	while($pm = $db->fetch_array($getpm)) {
		if($pm['type']=='inbox') {
			if($pm['hasread']=='no') {
				$inbox_notread++;
			} else {
				$inbox_read++;
			}
		} elseif($pm['type']=='outbox') {
			if($pm['hasread']=='no') {
				$outbox_notread++;
			} else {
				$outbox_read++;
			}
		} elseif($pm['type']=='saves') {
			if($pm['hasread']=='no') {
				$saves_notread++;
			} else {
				$saves_read++;
			}
		}
	}
	$getsent = $db->query("SELECT type,hasread FROM ".$prefix."pm WHERE (`from`='".$_COOKIE['membercookie']."' && type='inbox')");
	while($sentpm = $db->fetch_array($getsent)) {
		if($sentpm['hasread']=='no') {
			$track_notread++;
		} else {
			$track_read++;
		}
	}
	include($templatefolder.'/pm/index.dtf');
}

if($sub == 'folder') {
	if($name == 'inbox') {
		bar($bar_pm_inbox);
		
		//doing multipage
		$getnum = $db->query("SELECT pmid FROM ".$prefix."pm WHERE (whoto='".$_COOKIE['membercookie']."' && type='inbox')");
		$totalrows = $db->num_rows($getnum);
		$pageinfo = multipage($totalrows, $page, $settings['ompp'], 'pm.php?sub=folder&amp;name=inbox');

		include($templatefolder.'/pm/inbox_header.dtf');
		$getpm = $db->query("SELECT * FROM ".$prefix."pm WHERE (whoto='".$_COOKIE['membercookie']."' && type='inbox') ORDER BY hasread ASC,orderunixtime DESC LIMIT $pageinfo[0],$pageinfo[1]");
		while ($pm = $db->fetch_array($getpm)) {
			$date = gmdate($datecode, $pm['orderunixtime'] + ($member['timeoffset'] * 3600));
			$time = gmdate($timecode, $pm['orderunixtime'] + ($member['timeoffset'] * 3600));
			$senton = "$date $lang_at $time";
	   		$pm['subject'] = html(trim($pm['subject']));

			if($pm['subject']=='') {
				$pm['subject']=$lang_defaultpmtitle;
			}

			if($pm['hasread']=='no') {
				include($templatefolder.'/pm/inbox_fieldsnew.dtf');
			} else {
				include ($templatefolder.'/pm/inbox_fields.dtf');
			}
		}
		include($templatefolder.'/pm/inbox_deletefooter.dtf');
	}

	if($name == 'outbox') {
		bar($bar_pm_outbox);
		
		//doing multipage
		$getnum = $db->query("SELECT pmid FROM ".$prefix."pm WHERE (whoto='".$_COOKIE['membercookie']."' && type='outbox')");
		$totalrows = $db->num_rows($getnum);
		$pageinfo = multipage($totalrows, $page, $settings['ompp'], 'pm.php?sub=folder&amp;name=outbox');
		
		include($templatefolder.'/pm/outbox_header.dtf');
		$getpm = $db->query("SELECT * FROM ".$prefix."pm WHERE (whoto='".$_COOKIE['membercookie']."' && type='outbox') ORDER BY orderunixtime DESC LIMIT $pageinfo[0],$pageinfo[1]");
		while ($pm = $db->fetch_array($getpm)) {
			$date = gmdate($datecode, $pm['orderunixtime'] + ($member['timeoffset'] * 3600));
			$time = gmdate($timecode, $pm['orderunixtime'] + ($member['timeoffset'] * 3600));
			$senton = "$date $lang_at $time";
	   		$pm['subject'] = html(trim($pm['subject']));

			if($pm['subject']=='') {
				$pm['subject']=$lang_defaultpmtitle;
			}

			include($templatefolder.'/pm/outbox_fields.dtf');
		}
		include($templatefolder.'/pm/outbox_deletefooter.dtf');
	}
	
	if($name == 'saves') {
		bar($bar_pm_saves);
		
		//doing multipage
		$getnum = $db->query("SELECT pmid FROM ".$prefix."pm WHERE (whoto='".$_COOKIE['membercookie']."' && type='saves')");
		$totalrows = $db->num_rows($getnum);
		$pageinfo = multipage($totalrows, $page, $settings['ompp'], 'pm.php?sub=folder&amp;name=saves');

		include($templatefolder.'/pm/inbox_header.dtf');
		$getpm = $db->query("SELECT * FROM ".$prefix."pm WHERE (whoto='".$_COOKIE['membercookie']."' && type='saves') ORDER BY hasread ASC,orderunixtime DESC LIMIT $pageinfo[0],$pageinfo[1]");
	  	while ($pm = $db->fetch_array($getpm)) {
		  	$date = gmdate($datecode, $pm['orderunixtime'] + ($member['timeoffset'] * 3600));
			$time = gmdate($timecode, $pm['orderunixtime'] + ($member['timeoffset'] * 3600));
			$senton = "$date $lang_at $time";
	   		$pm['subject'] = html(trim($pm['subject']));

	   		if($pm['subject']=='') {
				$pm['subject']=$lang_defaultpmtitle;
			}

	   		if($pm['hasread']=='no') {
		   		include($templatefolder.'/pm/inbox_fieldsnew.dtf');
			} else {
	   			include($templatefolder.'/pm/inbox_fields.dtf');
   			}
	   	}
		include($templatefolder.'/pm/saves_deletefooter.dtf');
	}
	
	if($name == 'tracking') {
		bar($bar_pm_tracking);
		
		//doing multipage
		$getnum = $db->query("SELECT pmid FROM ".$prefix."pm WHERE (`from`='".$_COOKIE['membercookie']."' && type='inbox')");
		$totalrows = $db->num_rows($getnum);
		$pageinfo = multipage($totalrows, $page, $settings['ompp'], 'pm.php?sub=folder&amp;name=tracking');
		
		include($templatefolder.'/pm/tracking_header.dtf');
		$getpm = $db->query("SELECT * FROM ".$prefix."pm WHERE (`from`='".$_COOKIE['membercookie']."' && type='inbox') ORDER BY orderunixtime DESC, hasread ASC LIMIT $pageinfo[0],$pageinfo[1]");
		while ($pm = $db->fetch_array($getpm)) {
			$date = gmdate($datecode, $pm['orderunixtime'] + ($member['timeoffset'] * 3600));
			$time = gmdate($timecode, $pm['orderunixtime'] + ($member['timeoffset'] * 3600));
			$senton = "$date $lang_at $time";
	   		$pm['subject'] = html(trim($pm['subject']));

			if($pm['subject']=='') {
				$pm['subject']=$lang_defaultpmtitle;
			}
			
			if($pm['hasread']=='no') {
		   		include($templatefolder.'/pm/tracking_fieldsnew.dtf');
			} else {
	   			include($templatefolder.'/pm/tracking_fields.dtf');
   			}
		}
		include($templatefolder.'/pm/tracking_deletefooter.dtf');
	}	
}

if($sub == 'newpm') {
	$uid = @intval($uid);
	
	if($submit==$lang_send) {
		$subject = $db->escape(html(trim($subject)));
		$rte1 = $db->escape(removeEvilTags(trim($rte1)));

		$to = $db->escape(html($to));
		$posticon = $db->escape(html($posticon));
		
		if(!strstr($to, ', ')) {
			$checkname = $db->query("SELECT username FROM ".$prefix."users WHERE (username = '$to')");
			if($to == '' || $rte1 == '') {
				bar($bar_pm_missing_fields);
				message($lang_missingfields, $lang_missingfieldsinfo);
			} elseif(!$db->num_rows($checkname)) {
				bar($bar_pm_user_error);
				message($lang_pm_user_error, $to);		
			} else {
				$query = $db->query("SELECT count(pmid) FROM ".$prefix."pm WHERE (whoto='$to')");
	  			$num = $db->result($query);
				if($num>=$settings['maxpm']) {
					bar($bar_pm_quota);
					message($lang_pmfoldersfull, $to);
				}
				$timenow = time();
				##send pm
				$getid = $db->query("INSERT INTO ".$prefix."pm VALUES (NULL, '$to', '".$_COOKIE['membercookie']."', '$subject', '$rte1', '$posticon', 'no', '$timenow', 'inbox')");
				$pmid = $db->insert_id($getid);
				##outbox?
				if($saveoutbox=='1') {
					$db->unbuffered_query("INSERT INTO ".$prefix."pm VALUES (NULL, '".$_COOKIE['membercookie']."', '$to', '$subject', '$rte1', '$posticon', 'yes', '$timenow', 'outbox')");
				}
				##notifications
				$getnotifications = $db->query("SELECT `pmnotify`,`email` FROM `".$prefix."users` WHERE (`username`='$to')");
	  			$notification = $db->fetch_array($getnotifications);
				if($notification['pmnotify']==1) {
		  			if($subject=='') {
						$subject=$lang_defaultpmtitle;
					}

					##Security Checks
					if(!isset($_SERVER['HTTP_USER_AGENT'])){
					   die("Forbidden - You are not authorized to view this page");
					}
					
					if(!$_SERVER['REQUEST_METHOD'] == "POST"){
					   die("Forbidden - You are not authorized to view this page");
					}
					
					##Server Conf.
					if(strtoupper(substr(PHP_OS, 0, 3) == 'WIN')) {
						$nl_tag = "\r\n";
					} elseif (strtoupper(substr(PHP_OS, 0, 3) == 'MAC')) {
						$nl_tag = "\r";
					} else {
						$nl_tag = "\n";
					}
					
					$url = $fullpath.'pm.php?sub=view&pid='.$pmid;
					
					##headers for email
					$headers = 'From: '.$member['username'].' <'.$member['email'].'>'.$nl_tag;
					$headers .= 'Reply-To: '.$member['username'].' <'.$member['email'].'>'.$nl_tag; 
					$headers .= 'X-Original-From: '.$settings['boardname'].$nl_tag;
					$headers .= 'X-Mailer: Deluxe Bulletin Board Mailer'.$nl_tag;
					$headers .= 'X-Sender: <'.$member['username'].'>'.$nl_tag;
					$headers .= 'X-AntiAbuse: Forum - '.$settings['boardname'].$nl_tag;
					$headers .= 'Return-Path: <'.$member['username'].'>'.$nl_tag;
					$headers .= 'Content-Type: text/plain; charset='.$lang_charset;
					
		  			@mail("$notification[email]", "$lang_newpmemailtitle", "$lang_newpmemailtxt1 $to$lang_newpmemailtxt2".$_COOKIE['membercookie']."$lang_newpmemailtxt3 \"".stripslashes($subject)."\"$lang_newpmemailtxt4 $url $lang_newpmemailtxt5 $settings[boardname] $lang_newpmemailtxt6", $headers);
		  		}

				bar($bar_pm_successfully);
				message($lang_messagesent, $lang_forwardmainpm, "pm.php");
			}
		} else {
			if($to == '' || $rte1 == '') {
				bar($bar_pm_missing_fields);
				message($lang_missingfields, $lang_missingfieldsinfo);
			}

			##validating users
			$mto = explode(", ", $to);
			for($x=0,$y=0;$x<sizeof($mto),$mto[$x]!='';$x++) {
				$mto[$x] = trim($mto[$x]);
				$checkname = $db->query("SELECT uid FROM ".$prefix."users WHERE (username = '$mto[$x]')");

				if(!$db->num_rows($checkname)) {
					if($y!=0) {
						$member_missing .= ', '.$mto[$x];
					} else {
						$member_missing = $mto[$x];
					}
					$y++;
				}

				$query = $db->query("SELECT count(pmid) FROM ".$prefix."pm WHERE (whoto='$mto[$x]')");
	  			$num = $db->result($query);
				if($num>=$settings['maxpm']) {
					if($y!=0) {
						$member_full .= ', '.$mto[$x];
					} else {
						$member_full = $mto[$x];
					}
					$y++;
				}
			}
			
			if($member_missing!='') {
				bar($bar_pm_user_error);
				message($lang_pm_user_error, $member_missing);
			}
			
			if($member_full!='') {
				bar($bar_pm_quota);
				message($lang_pmfoldersfull, $member_full);
			}		
			
			for($x=0;$x<sizeof($mto) && $mto[$x]!='';$x++) {
				$timenow = time();

				##sending pm
				$getid = $db->query("INSERT INTO ".$prefix."pm VALUES (NULL, '$mto[$x]', '".$_COOKIE['membercookie']."', '$subject', '$rte1', '$posticon', 'no', '$timenow', 'inbox')");
				$pmid = $db->insert_id($getid);
				##notifications
				$getnotifications = $db->query("SELECT `pmnotify`,`email` FROM `".$prefix."users` WHERE (`username`='$mto[$x]')");
  				$notification = $db->fetch_array($getnotifications);
				if($notification['pmnotify']==1) {
		  			if($subject=='') {
						$subject=$lang_defaultpmtitle;
					}
					
					$url = $fullpath.'pm.php?sub=view&pid='.$pmid;
					
					##Security Checks
					if(!isset($_SERVER['HTTP_USER_AGENT'])){
					   die("Forbidden - You are not authorized to view this page");
					}
					
					if(!$_SERVER['REQUEST_METHOD'] == "POST"){
					   die("Forbidden - You are not authorized to view this page");
					}
					
					##Server Conf.
					if(strtoupper(substr(PHP_OS, 0, 3) == 'WIN')) {
						$nl_tag = "\r\n";
					} elseif (strtoupper(substr(PHP_OS, 0, 3) == 'MAC')) {
						$nl_tag = "\r";
					} else {
						$nl_tag = "\n";
					}
					
					##headers for email
					$headers = 'From: '.$member['username'].' <'.$member['email'].'>'.$nl_tag;
					$headers .= 'Reply-To: '.$member['username'].' <'.$member['email'].'>'.$nl_tag; 
					$headers .= 'X-Original-From: '.$settings['boardname'].$nl_tag;
					$headers .= 'X-Mailer: Deluxe Bulletin Board Mailer'.$nl_tag;
					$headers .= 'X-Sender: <'.$member['username'].'>'.$nl_tag;
					$headers .= 'X-AntiAbuse: Forum - '.$settings['boardname'].$nl_tag;
					$headers .= 'Return-Path: <'.$member['username'].'>'.$nl_tag;
					$headers .= 'Content-Type: text/plain; charset='.$lang_charset;
					
		  			@mail("$notification[email]", "New Private Message", "Hello $mto[$x],\n".$_COOKIE['membercookie']." has just sent you an pm with the title \"".stripslashes($subject)."\"\n\nYou can open the private message by clicking this url:\n$url\n\nRegardfull,\n"."The $settings[boardname] team", $headers);
		  		}
			}
			##outbox?
			if($saveoutbox=='1') {
				$db->unbuffered_query("INSERT INTO ".$prefix."pm VALUES (NULL, '".$_COOKIE['membercookie']."', '$to', '$subject', '$rte1', '$posticon', NULL, '$timenow', 'outbox')");
			}
			
			bar($bar_pm_successfully);
			message($lang_messagesent, $lang_forwardmainpm, "pm.php");
		}
	} else {
		$to = $db->escape(html($to));
		$posticon = $db->escape(html($posticon));

		if($reply!='') {
			$reply = @intval($reply);
			//quote someone
			$getinfo = $db->query("SELECT `from`,`subject`,`post` FROM ".$prefix."pm WHERE (pmid='$reply')");
			$replyinfo = $db->fetch_array($getinfo);
			$to = $replyinfo['from'];
			
			if($settings['htmloff']!=1) {
				$post = '<br /><br /><span class="misctext"><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Quote:</strong></span><br /><table align="center" border="1px" rules="all" cellpadding="3" cellspacing="1" width="90%" bgcolor="'.$topicaltcolor.'"><tbody><tr><td>'.addslashes($replyinfo['post']).'</td></tr></tbody></table><br /><br />';
			} else {
				$post = "Quote:\n".$replyinfo['post']."\n\n";
			}

			$subject = 'Re: '.$replyinfo['subject'];
		} elseif($uid!='' && $uid!=0) {
			$uid = @intval($uid);
			$getinfo = $db->query("SELECT `username` FROM ".$prefix."users WHERE (uid='$uid')");
			$to = $db->result($getinfo, 0);
		}

		bar($bar_newpm);
		cachelists();
		include($templatefolder.'/pm/newpm.dtf');
	}
}

if($sub == 'do') {
	if($submit==$lang_delete) {
		bar($bar_del_pm);
		$query = $db->query("SELECT pmid FROM ".$prefix."pm WHERE (whoto='".$_COOKIE['membercookie']."')");
		while($pm = $db->fetch_array($query)) {
			$delete = "delete$pm[pmid]";
			$delete = "${$delete}";
			if($delete!='') {
			  $delete = @intval($delete);
				$db->unbuffered_query("DELETE FROM ".$prefix."pm WHERE (whoto='".$_COOKIE['membercookie']."' && pmid='$delete')");
			}
		}
		if(isset($inbox)) {
			message($lang_successfullydeletedpm, $lang_forwardfolder, "pm.php?sub=folder&name=inbox");
		} elseif(isset($outbox)) {
			message($lang_successfullydeletedpm, $lang_forwardfolder, "pm.php?sub=folder&name=outbox");
		} else {
			message($lang_successfullydeletedpm, $lang_forwardfolder, "pm.php?sub=folder&name=saves");
		}
	} elseif(isset($submit2)) {
		bar($bar_move_pm);
		$query = $db->query("SELECT pmid FROM ".$prefix."pm WHERE (whoto='".$_COOKIE['membercookie']."')");
		while($pm = $db->fetch_array($query)) {
			$delete = "delete$pm[pmid]";
			$delete = "${$delete}";
			if($move!='') {
				$delete = @intval($delete);
				$db->unbuffered_query("UPDATE ".$prefix."pm SET type='saves' WHERE (pmid='$delete')");
			}
		}
		message($lang_successfullymovedpm, $lang_forwardsaves, "pm.php?sub=folder&name=saves");
	}
}

if($sub == 'view') {
	$pid = @intval($pid);
	
	$getpm = $db->query("SELECT * FROM `".$prefix."pm` WHERE (`pmid`='$pid' && `whoto`='".$_COOKIE['membercookie']."')");
	$pm = $db->fetch_array($getpm);
	
	##prevent users from viewing other pms
	if($db->num_rows($getpm)==0) {
		bar($bar_pm_not_exist);
		message($lang_pmnotexist, $lang_forwardfolder, "pm.php?sub=folder&name=inbox");
		quit();
	}
	
	$mem = $db->query("SELECT * FROM ".$prefix."users WHERE (username='".$pm['from']."')");
	if($db->num_rows($mem)!=0) {
		$themember = $db->fetch_array($mem);
	} else {
		$themember=array('username'=>$pm['from'],
						 'joineddate'=>0,
						 'timeoffset'=>0,
						 'posts'=>0);
	}
	
	##preparing user ranks
	if($settings['userranks']!=0) {
		##caching ranks
		prepareranks();
		
		$checktitle = '';
		##user ranks
		switch ($themember['membercode']) {
			case(2): $checktitle = "Moderator"; break;
			case(3): $checktitle = "Super Moderator"; break;
			case(4): $checktitle = "Administrator"; break;
			case(5): $checktitle = "Head Admin"; break;
		}
		if($checktitle!='') {
			$rankinfo = explode(",", $specialrank[$checktitle]);
		} else {
			foreach ($userrank as $key => $rinfo) {
				if($themember['posts'] >= $key) {
					$rankinfo = explode(",", $rinfo);
				}
			}
		}
	}
	
	##formating message and subject
	if($settings['htmloff']!=0) {
		$pm['post'] = html($pm['post']);
	}

	if($pm['subject']=='') {
		$pm['subject']=$lang_defaultpmtitle;
	} else {
		$pm['subject'] = html($pm['subject']);
	}
	
	if(!stristr($pm['post'], '<font size') && !stristr($pm['post'], '<span style')) {
		$pm['post']= '<span class="inputarea">'.$pm['post'].'</span>';
	}
	
	//check for existing formatting -> else use css defined value
	$formatted = 0;
	$formatarray = array('<font', '<span style', '<h1', '<h2', '<h3', '<h4', '<h5', '<h6', '<adress', '<pre', '<p');
		
	foreach($formatarray as $element) {
		if(stristr($pm['post'], $element)) {
			$formatted++;
		}
	}
						
	if($formatted==0) {
		$pm['post']= '<span class="inputarea">'.$pm['post'].'</span>';
	}
	
	$message = bbcode($pm['post']);
	
	$db->unbuffered_query("UPDATE ".$prefix."pm SET hasread='yes' WHERE (pmid ='$pid')");
	
	if ($themember['avatar'] == '') {
		$avatar = '';
	} else {
		$avatar = '<img src="'.$themember['avatar'].'" alt="Avatar" />';
	}
	if($pm['type'] == 'inbox') {
		$where = $lang_folder_inbox;
	} elseif($pm['type'] == 'outbox') {
		$where = $lang_folder_outbox;
	} else {
		$where = $lang_folder_saves;
	}
	
	if($themember['username']!='System Mailer') {
		$joineddate = @gmdate($datecode, $themember['joineddate'] + ($member['timeoffset'] * 3600));
	} else {
		$joineddate = @gmdate($datecode, time());
	}
	$date = gmdate($datecode, $pm['orderunixtime'] + ($member['timeoffset'] * 3600));
	$time = gmdate($timecode, $pm['orderunixtime'] + ($member['timeoffset'] * 3600));
	$sendtime = "$date $lang_at $time";
	
	//preparing user info
	if($themember['membercode']==1) {
		if($rankinfo[0]!='') {
			$status = $rankinfo[0];
		} else {
			$status = $lang_member;
		}
	} elseif($themember['membercode']==2) {
		$status = $lang_moderator;
	} elseif($themember['membercode']==3) {
		$status = $lang_supermoderator;
	} elseif($themember['membercode']==4) {
		$status = $lang_administrator;
	} elseif($themember['membercode']==5) {
		$status = $lang_administrator;
	} else {
		$status = $lang_anonymoususer;
	}
	
	if($themember['customtitle']!='') {
		$details = $themember['customtitle'].'<br /><br />';
	}
	for($i=0; $i<$rankinfo[2]; $i++){
		$details .= '<img src="'.$images.'/'.$rankinfo[3].'" alt="Star" />';
	}
	$details .= '<br /><br />';
	
	if($rankinfo[4]!=0 || $settings['userranks']==0) {
		$details .= $avatar.'<br />';
	}
	$details .= '<br />'.$lang_posts.' '.$themember['posts'].'<br />'.$lang_joined.' '.$joineddate;
	
	//formatting urls
	if(!stristr($themember['site'], 'http://') && !stristr($themember['site'], 'https://') && !stristr($themember['site'], 'ftp://') && $themember['site']!='') {
		$themember['site'] = 'http://'.$themember['site'];
	}
	
	if($themember['hideemail']==0) {
		$userbuttons = '<a href="mailto:'.$themember['email'].'"><img src="'.$images.'/userbuttons/email.gif" alt="Email" /></a>&nbsp;'; 
	} elseif($themember['hideemail']==2) {
		$userbuttons = '<a href="misc.php?sub=emailuser&amp;uid='.$themember['uid'].'"><img src="'.$images.'/userbuttons/email.gif" alt="Email" /></a>&nbsp;';
	}
	
	if($themember['site']!='') {
		$userbuttons .= '<a href="'.$themember['site'].'" target="blank"><img src="'.$images.'/userbuttons/site.gif" alt="Site" /></a>&nbsp;';
	} 

	bar($bar_pm.$bar_seperator.'<a href="pm.php?sub=folder&amp;name='.$pm['type'].'">'.$where.'</a>'.$bar_seperator.$pm['subject']);
	include($templatefolder.'/pm/view.dtf');
}

include('./footer.php');

?>