<?php

/************************************************
 * DeluxeBB 1.3                                 *
 * Copyright (C) 2005-2009 Frank Nissel         *
 * http://www.DeluxeBB.com	                    *
 * For license information, please read the     *
 * license file in the docs/ folder! 			      *
 ************************************************/


##Fix for superglobals
$list = array('_POST', '_GET', '_ENV', '_SERVER');
foreach($list as $element) {
    if(!empty($$element) && is_array($$element) ) {
        extract($$element, EXTR_SKIP);
    }
}

// support xml tags
@ini_set('short_open_tag', '0');

//enabling advanced debugging
@ini_set('display_errors', '1');

$version = '1.3';

if($PHP_SELF=='') {
	$PHP_SELF='install.php';
}

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>DeluxeBB <?php echo $version; ?> installer</title>
<style type="text/css">
<!--
* {
  text-align: left;
}
#header {
	background: url(images/_headerbg.gif) no-repeat;
}
#footer {
	background: url(images/_footerbg.gif) no-repeat;
	height: 100px;
	margin: 0px auto 5px auto;
	padding: 0px;
}
#logo {
  padding: 32px 0 0px 25px;
	margin: 0;
}
#logo img {
	border: none;
}
#main {
	background: #FFFFFF;
	margin: 0 auto;
	width: 766px;
}
#content {
	background: url(images/_contentbg.gif) repeat-y;
	margin: 0px;
	padding-top: 15px;
}
.content_1 {
	width: 700px;
	overflow: auto;
	padding: 5px;
	margin: 0 auto;
}
font {
	font-family: Trebuchet MS, Verdana, Arial;
  font-size: 12px;
}
a {
	color: #006699;
  text-decoration: none
}
a:hover {
	text-decoration: underline
}
.copyright {
	font: 11px Arial, Helvetica, sans-serif !important;
	color: #666666;
	margin: 20px auto 0px;
	width: 360px;
	padding: 0px;
  text-align: center;
}
.tblcl {
  padding: 0px;
  margin-left: 38px;
  width: 88%;
  background: #006699;
  align: center;
}
.tblcl caption {
  background: #006699;
  text-align: left;
  font-family: Trebuchet MS, Verdana, Arial;
  font-size: 12px;
  font-weight: bold;
  color: #ddd;
  padding: 3px;
}
.title {
  background: #006699;
  text-align: left;
  font-family: Trebuchet MS, Verdana, Arial;
  font-size: 12px;
  font-weight: bold;
  color: #ddd;
  padding: 3px;
}
.tdclalt {
  background: #fff;
  padding:5px;
}
.tdcl {
  background: #ccc;
  padding:5px;
}
.trcl {
  background: #FFFFFF;
}

-->
</style>
<script type="text/javascript" language="javascript">
<!--
function verify(input) { 
   var passed=false;
   if (input.sub.value=='') {
	 alert("Please choose an valid option");
     input.sub.focus();
   } else {
     passed=true;
   }
   return passed;
}
//-->
</script>
</head>
<!--
**********************************
* www.deluxebb.com               *
* copyright (c) to Frank Nissel  *
* 2008                           *
**********************************
-->
<body>

<div id="main">
  <div id="header">
    <h1 id="logo"><a href="install.php"><img src="images/_logo.gif" width="303" height="68" alt="DeluxeBB logo" /></a></h1>
  </div>
<div id="content">
<div class="content_1">
<?php
if(!$sub && !$submit && !$test) {
?>

<font size="1">&gt;&gt; <a href="<?php echo $PHP_SELF; ?>">Installation Main Page</a>
<br /><br /><br />

<strong>Welcome to the DeluxeBB setup...</strong><br />
Please pick an option below:<br /><br />
<form method="post" onsubmit="return verify(this)" action="<?php echo $PHP_SELF; ?>">
<hr style="border:dashed #000 1px; background-color:#fff;height:1px;margin-bottom:10px;">
<select name="sub">
<option value="install" selected="selected">Install DeluxeBB <?php echo $version; ?></option>
<option value="">---</option>
<option value="">Upgrade from</option>
<option value="9">DeluxeBB 1.2</option>
<option value="8">DeluxeBB 1.1</option>
<option value="7">DeluxeBB 1.09</option>
<option value="6">DeluxeBB 1.08</option>
<option value="5">DeluxeBB 1.07</option>
<option value="4">DeluxeBB 1.06</option>
<option value="3">DeluxeBB 1.05</option>
<option value="2">DeluxeBB 1.0b</option>
<option value="1">DeluxeBB 1.0</option>
</select>
<input type="submit" name="select" value="Select" /><hr style="border:dashed #000 1px; background-color:#fff;height:1px;margin-top:10px;">
</form>
<br /><br />
Please note: If you want to upgrade your board, please make sure you chose the correct version, else it could corrupt your database. Also please create a backup before running the upgrade.

</font>
</div>
<?php	
}

if($sub=="install") {
?>
<script type="text/javascript" language="javascript">
<!--
function verify(input) {
   var passed=false;
   if (input.hostname.value=='') {
	 alert("You forgot to fill out the hostname field!");
     input.hostname.focus();
   } else if (input.dbname.value=='') {
	 alert("Please fill out the database name field!");
     input.dbname.focus();
   } else if (input.fullpath.value=='') {
	 alert("Please enter the fullpath to your forum!");
     input.fullpath.focus();
   } else if (input.myusername.value=='') {
	 alert("Please fill out the username field!");
     input.myusername.focus();
   } else if (input.mypassword.value=='') {
	 alert("Please fill out the password field for the headadmin account!");
     input.mypassword.focus();
   } else if (input.mypassword.value != input.mypassword2.value) {
	 alert("Your passwords are not matching... Please type them in again");
     input.mypassword.focus();
   } else if (input.myemail.value=='') {
	 alert("You did not enter an email for yourself!");
     input.myemail.focus();
   } else {
     passed=true;
   }
   return passed;
}
//-->
</script>

<table width="90%" align="center">
<tr>
<td><font size="1">&gt;&gt; <a href="<?php echo $PHP_SELF; ?>">Installation Main Page</a> &gt;&gt; Enter Database information</font></td>
</tr>
</table>

<br />
<table class="tblcl">
<caption>Read Before Installing</caption>
<tr class="trcl">
<td class="tdcl"><font size="1">You have now reached the installer, fill in all
of the fields below, making sure that the <a href="http://www.mysql.com/">MySQL</a> info is correct.<br /><br />
If you are not sure about the database settings contact your host to find out!<br />
Hit the "Check Input" button to test if the installation will work with the details you filled into this form!<br />
If your installing locally you can mostly use <em>root</em> as username with no password as
database login!<br /><br />
If you get an error once you click setup, then read the error, press
your back button and double check all the infomation.<br />
When you have successfully installed goto the admin
center and you can customize,<br /> add, edit, delete stuff within there.
We hope you are pleased with <b>DeluxeBB</b>!</font></td>
</tr>

<tr class="trcl">
<td class="tdcl"><font size="1">If you have any problems visit our support forum <a href="http://www.deluxebb.com" target="_blank">here</a>.</font></td>
</tr>
</table>

<br />

<form method="post" onSubmit="return verify(this)" action="<?php echo $PHP_SELF; ?>">
<table class="tblcl">
<tr>
<td class="title" colspan="2"><font size="1">MySql Info:</font></td>
</tr>
<tr class="trcl">
<td class="tdcl" width="24%"><font size="1">Database Name:</font></td>
<td class="tdclalt" width="76%"><input type="text" name="dbname" size="50"></td>
</tr>
<tr class="trcl">
<td class="tdcl" width="24%"><font size="1">Database Username:</font></td>
<td class="tdclalt" width="76%"><input type="text" name="dbusername" size="50" value="root"></font></td>
</tr>
<tr class="trcl">
<td class="tdcl" width="24%"><font size="1">Database Password:</font></td>
<td class="tdclalt" width="76%"><input type="password" name="dbpassword" size="50"></td>
</tr>
<tr class="trcl">
<td class="tdcl" width="24%"><font size="1">Host:</font></td>
<td class="tdclalt" width="76%"><input type="text" name="hostname" size="50" value="localhost"></td>
</tr>
<tr>
<td class="title" colspan="2"><font size="1">Table Prefix:</font></td></tr>
<tr class="trcl">
<td class="tdcl" width="24%"><font size="1">Prefix:</font></td>
<td class="tdclalt" width="76%"><input type="text" name="prefix" size="50" value="deluxebb_"><br /><font size="1">This sets up a prefix for the MySql tables, so you can install several forums on one database...<br />
</font></td></tr>
<tr class="trcl">
<td class="tdcl" width="24%"><font size="1">Drop tables:</font></td>
<td class="tdclalt" width="76%"><input type="checkbox" name="droptables" value="1" /> <font size="1">If checked, all existing MySql tables using the prefix above will be dropped.</font></td>
</tr>
<tr>
<td class="title" colspan="2"><font size="1">Other settings:</font></td>
</tr>
<tr class="trcl">
<td class="tdcl" width="24%"><font size="1">Full Path:</font></td>
<td class="tdclalt" width="76%"><input type="text" name="fullpath" size="50" value="http://www.deluxebb.com/community/"><br /><font size="1">Full path to the forum, please dont forget the / at the end of the url,<br />if it is not correct there might be problems with the user authentication</font></td>
</tr>
<td class="title" colspan="2"><font size="1">Your Username Info:</font></td>
</tr>
<tr class="trcl">
<td class="tdcl" width="24%"><font size="1">Username:</font></td>
<td class="tdclalt" width="76%"><input type="text" name="myusername" size="50"><br /><font size="1">With this username you are granted permission to modify the board / delete posts and many more...</font></td>
</tr>
<tr class="trcl">
<td class="tdcl" width="24%"><font size="1">Password:</font></td>
<td class="tdclalt" width="76%"><input type="password" name="mypassword" size="50"></td>
</tr>
<tr class="trcl">
<td class="tdcl" width="24%"><font size="1">Confirm Password:</font></td>
<td class="tdclalt" width="76%"><input type="password" name="mypassword2" size="50"></td>
</tr>
<tr class="trcl">
<td class="tdcl" width="24%"><font size="1">Admin Email:</font></td>
<td class="tdclalt" width="76%"><input type="text" name="myemail" size="50"><br /><font size="1">Errors or abuse notices will be sent to this email!</font></td>
</tr>
<tr>
<td class="title" colspan="2"><input type="submit" value="Setup" name="submit" />&nbsp;<input type="submit" value="Test Input" name="test" /></td>
</tr>
</table>
</form>
</div>

<?php
}

if($sub<=100 && $sub!=0) {
?>
<table width="90%" align="center">
<tr>
<td><font size="1">&gt;&gt; <a href="<?php echo $PHP_SELF; ?>">Installation Main Page</a> &gt;&gt; Upgrading... please wait</font></td>
</tr>
</table>

<br />
<?php

require_once('settings/info.php');
require_once('classes/mysql.php');
$db = new db;
$db->connect($hostname, $dbname, $dbusername, $dbpassword);

$getsettings = $db->query("SELECT * FROM ".$prefix."settings WHERE (name = 'settings')");
$settings = $db->fetch_array($getsettings);

?>
<table class="tblcl">
<caption>Setting up the database for DeluxeBB:</caption>
<tr class="trcl">
<td class="tdcl"><font size="1">
<?php
if($sub<=1) {
	$todaydate=time();
	echo "<br/>Modifying table ".$prefix."settings: Updating dateformats";
	$db->query("UPDATE ".$prefix."settings SET dateformat='d.m.y'");
	echo "<br/>Modifying table ".$prefix."users: Updating dateformats";
	$db->query("UPDATE ".$prefix."users SET dateformat='d.m.y' WHERE username!='guest'");
	echo "<br/>Modifying table ".$prefix."users: Adding invisible browsing";
	$db->query("ALTER TABLE ".$prefix."users ADD `invisible` TINYINT( 1 ) DEFAULT NULL");
	$db->query("INSERT INTO ".$prefix."users VALUES ('', 'invisible', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '$todaydate', '', '', '', '', '', '', '', '', '', '')");
	echo "<br/>Modifying table ".$prefix."settings: Adding invisible browsing global on/off";
	$db->query("ALTER TABLE ".$prefix."settings ADD `invisible` TINYINT( 1 ) NOT NULL");
	$db->query("UPDATE ".$prefix."settings SET `invisible`='1' WHERE name='settings'");
	echo "<br/>Removing all BB code stuff from ".$prefix."replacements, restrictions, posts, settings: Got a nice WYSIWYG editor now ;)";
	$db->query("ALTER TABLE `".$prefix."replacements` DROP `alt_comment` , DROP `example` , DROP `image`, DROP `explanation`");
	$db->query("DELETE FROM ".$prefix."replacements WHERE (type='bbcode')");
	$db->query("ALTER TABLE `".$prefix."restrictions` DROP `editbbcode`");
	$db->query("ALTER TABLE `".$prefix."posts` DROP `bbcodeoff`");
	$db->query("ALTER TABLE `".$prefix."settings` CHANGE `ubbcode` `htmloff` TINYINT( 1 ) NOT NULL");
	$db->query("UPDATE ".$prefix."settings SET htmloff=0");
}
if($sub<=2) {
	echo "<br/>Reinstalling table ".$prefix."replacements: Fixing some last problems";
	$db->query("DROP TABLE IF EXISTS ".$prefix."replacements");
	$db->query("CREATE TABLE IF NOT EXISTS ".$prefix."replacements ( 
	  id smallint(5) unsigned NOT NULL auto_increment,
	  tag varchar(200) NOT NULL DEFAULT '' ,
	  replacement MEDIUMTEXT NOT NULL DEFAULT '' ,
	  type varchar(30) NOT NULL DEFAULT '' ,
	  inmenu char(3) NOT NULL DEFAULT '' ,
	  enabled char(3) NOT NULL DEFAULT '' ,
	  PRIMARY KEY (id)
	)");
		
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (1, ':D', 'bigsmile.gif', 'smilie', 'yes', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (2, ':-D', 'bigsmile.gif', 'smilie', 'no', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (3, ':d', 'bigsmile.gif', 'smilie', 'no', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (4, ':-d', 'bigsmile.gif', 'smilie', 'no', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (5, ':|', 'down.gif', 'smilie', 'yes', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (6, ':-|', 'down.gif', 'smilie', 'no', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (7, '(!)', 'exclamation.gif', 'smilie', 'yes', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (8, ';-)', 'wink.gif', 'smilie', 'yes', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (9, ';)', 'wink.gif', 'smilie', 'no', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (10, ':o', 'shocked.gif', 'smilie', 'yes', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (11, ':-o', 'shocked.gif', 'smilie', 'no', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (12, ':O', 'shocked.gif', 'smilie', 'no', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (13, ':-O', 'shocked.gif', 'smilie', 'no', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (14, ':(', 'sad.gif', 'smilie', 'yes', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (15, ':-(', 'sad.gif', 'smilie', 'no', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (16, '[cool]', 'cool.gif', 'smilie', 'yes', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (17, '[happy]', 'happy.gif', 'smilie', 'yes', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (18, ':x', 'mad.gif', 'smilie', 'yes', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (19, ':X', 'mad.gif', 'smilie', 'no', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (20, ':\\\', 'moarn.gif', 'smilie', 'yes', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (21, '(?)', 'question.gif', 'smilie', 'yes', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (22, ':)', 'smile.gif', 'smilie', 'no', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (23, ':P', 'tongue.gif', 'smilie', 'yes', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (24, ':p', 'tongue.gif', 'smilie', 'no', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (25, '', 'bigsmile.gif', 'posticon', 'yes', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (26, '', 'cool.gif', 'posticon', 'yes', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (27, '', 'exclamation.gif', 'posticon', 'yes', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (28, '', 'mad.gif', 'posticon', 'yes', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (29, '', 'question.gif', 'posticon', 'yes', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (30, '', 'sad.gif', 'posticon', 'yes', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (31, '', 'shocked.gif', 'posticon', 'yes', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (32, '', 'smile.gif', 'posticon', 'yes', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (33, '', 'wink.gif', 'posticon', 'yes', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (34, '', 'tongue.gif', 'posticon', 'yes', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (35, '', 'thumbup.gif', 'posticon', 'yes', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (36, '', 'thumbdown.gif', 'posticon', 'yes', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (37, 'fuck', 'f*ck', 'censor', '', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (38, 'suck', 's*ck', 'censor', '', 'yes')");
	$db->query("INSERT INTO `".$prefix."replacements` VALUES (39, 'nigger', 'colored man', 'censor', '', 'yes')");
}

if($sub<=3) {
	echo "<br/>Modifying table ".$prefix."settings: Adding textwrap feature";
	$db->query("ALTER TABLE `".$prefix."settings` ADD `wrap` TINYINT( 1 ) default NULL, ADD `wraplength` SMALLINT( 1 ) NOT NULL");
	$db->query("UPDATE ".$prefix."settings SET `wrap`=0");
	$db->query("UPDATE ".$prefix."settings SET `wraplength`=100");
	
	echo "<br/>Modifying table ".$prefix."skins: Updating skinning system / adding new skin";
	$db->query("ALTER TABLE `".$prefix."skins` DROP `font`, DROP `size`, DROP `color`, DROP `linkcolor`, DROP `bgcolor`, DROP `bgimage`, DROP `forummouseovercolor`, DROP `pinnedmouseover`");
	$db->query("ALTER TABLE `".$prefix."skins` ADD `templatefolder` VARCHAR( 100 ) NOT NULL AFTER `smiliepath`");
	$db->query("ALTER TABLE `".$prefix."skins` ADD `topicseperatorcolor` VARCHAR( 7 ) NOT NULL AFTER `topicaltcolor`, ADD `topicseperatorimage` VARCHAR( 100 ) NOT NULL AFTER `topicseperatorcolor`");
	$db->query("INSERT INTO `".$prefix."skins` VALUES ('deluxe', 'images/deluxe', 'images/smilies/standart', 'templates/deluxe', 'logo.png', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '')");

	
	$db->query("UPDATE ".$prefix."skins SET `templatefolder`='templates/default'");
	$getdata = $db->query("SELECT skinname,barbgcolor FROM `".$prefix."skins`");
	while($workdata = $db->fetch_array($getdata)) {
		$db->query("UPDATE ".$prefix."skins SET `topicseperatorcolor`='$workdata[barbgcolor]' WHERE `skinname`='$workdata[skinname]'");
	}
	
	echo "<br/>Modifying table ".$prefix."settings: Adding new features";
	$db->query("ALTER TABLE `".$prefix."settings` ADD `guestmemfunctions` TINYINT( 1 ), ADD `allowpm` TINYINT( 1 ), ADD `allowonline` TINYINT( 1 ), ADD `guestforumview` TINYINT( 1 ), ADD `allowlostpw` TINYINT( 1 ), ADD `showforumrules` TINYINT( 1 ), ADD `forumrules` TINYTEXT");
	$db->query("UPDATE ".$prefix."settings SET `guestmemfunctions`=1");
	$db->query("UPDATE ".$prefix."settings SET `allowpm`=1");
	$db->query("UPDATE ".$prefix."settings SET `allowonline`=1");
	$db->query("UPDATE ".$prefix."settings SET `guestforumview`=1");
	$db->query("UPDATE ".$prefix."settings SET `allowlostpw`=1");		
	$db->query("UPDATE ".$prefix."settings SET `showforumrules`=0");
	$db->query("UPDATE ".$prefix."settings SET `forumrules`='Text here'");
}

if($sub<=4) {
	echo "<br/>Modifying table ".$prefix."settings: Enlarging field for forum rules";
	$db->query("ALTER TABLE `".$prefix."settings` CHANGE `forumrules` `forumrules` MEDIUMTEXT DEFAULT NULL");
}

if($sub<=5) {
	echo "<br/>Modifying table ".$prefix."forums: Adding forum redirection feature";
	$db->query("ALTER TABLE `".$prefix."forums` ADD `redirect` VARCHAR(225) NOT NULL");
	$db->query("ALTER TABLE `".$prefix."forums` CHANGE `cid` `cid` INT(3) NULL DEFAULT NULL, CHANGE `topics` `topics` INT(6) NULL DEFAULT NULL, CHANGE `replies` `replies` INT(6) NULL DEFAULT NULL");
}
if($sub<=6) {
	echo "<br/>Modifying table ".$prefix."skins: Correcting a path";
	$db->query("UPDATE `".$prefix."skins` SET `smiliepath` = 'images/smilies/standart' WHERE `skinname` = 'deluxe'");
}
if($sub<=7) { ##from 1.09 to 1.1
	echo "<br/>Adding table ".$prefix."posts_archive: New feature -> edit history";
	$db->query("CREATE TABLE IF NOT EXISTS `".$prefix."posts_archive` (
	  `pid` bigint(10) NOT NULL default '0',
	  `tid` bigint(10) NOT NULL default '0',
	  `author` int(10) NOT NULL default '0',
	  `subject` varchar(255) NOT NULL default '',
	  `message` text NOT NULL,
	  `postdate` int(10) NOT NULL default '0',
	  `smiliesoff` smallint(1) default NULL,
	  KEY `author` (`author`),
	  KEY `pid` (`pid`),
	  KEY `tid` (`tid`)
	)");
	
	echo "<br/>Modifying table ".$prefix."settings: New feature -> edit history";
	$db->query("ALTER TABLE `".$prefix."settings` ADD `edithistory` TINYINT(1) NOT NULL");
	
	echo "<br/>Modifying table ".$prefix."skins: Adding new skin corporate";
	$db->query("INSERT INTO `".$prefix."skins` VALUES ('corporate', 'images/corporate', 'images/smilies/dark', 'templates/corporate', 'logo.gif', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '')");

	echo "<br/>Modifying table ".$prefix."users: Adding new feature: Email verification";
	$db->query("ALTER TABLE `".$prefix."users` ADD `valnum` VARCHAR(10) NULL");	
	
	echo "<br/>Modifying table ".$prefix."settings: Adding new feature: Email verification";
	$db->query("ALTER TABLE `".$prefix."settings` ADD `emailver` TINYINT(1) DEFAULT '0'");
}

if($sub<=8) { ##from 1.1 to 1.2
	echo "<br/>Modifying table ".$prefix."restrictions: Removing field flash (not needed anymore)";
	$db->query("ALTER TABLE `".$prefix."restrictions` DROP `flash`");
	
	echo "<br/>Modifying table ".$prefix."flash: Removing table";
	$db->query("DROP TABLE `".$prefix."flash`");
		
	echo "<br/>Modifying table ".$prefix."settings: Cleaning up table";
	$cleansettings = $db->query("SELECT * FROM `".$prefix."settings` WHERE name='settings'");
	$value = $db->fetch_array($cleansettings);
	
	$db->query("ALTER TABLE `".$prefix."settings` CHANGE `sightml` `sightml` TINYINT(1) NOT NULL");
	if($value['sightml']=="yes") {
		$db->query("UPDATE `".$prefix."settings` SET `sightml` = '1' WHERE name='settings'");
	} else {
		$db->query("UPDATE `".$prefix."settings` SET `sightml` = '0' WHERE name='settings'");
	}
	$db->query("ALTER TABLE `".$prefix."settings` CHANGE `cplog` `cplog` TINYINT(1) NOT NULL");
	if($value['cplog']=="on") {
		$db->query("UPDATE `".$prefix."settings` SET `cplog` = '1' WHERE name='settings'");
	} else {
		$db->query("UPDATE `".$prefix."settings` SET `cplog` = '0' WHERE name='settings'");
	}
	$db->query("ALTER TABLE `".$prefix."settings` CHANGE `gzip` `gzip` TINYINT(1) NOT NULL");
	if($value['gzip']=="on") {
		$db->query("UPDATE `".$prefix."settings` SET `gzip` = '1' WHERE name='settings'");
	} else {
		$db->query("UPDATE `".$prefix."settings` SET `gzip` = '0' WHERE name='settings'");
	}
	$db->query("ALTER TABLE `".$prefix."settings` CHANGE `smilies` `smilies` TINYINT(1) NOT NULL");
	if($value['smilies']=="on") {
		$db->query("UPDATE `".$prefix."settings` SET `smilies` = '1' WHERE name='settings'");
	} else {
		$db->query("UPDATE `".$prefix."settings` SET `smilies` = '0' WHERE name='settings'");
	}
	$db->query("ALTER TABLE `".$prefix."settings` CHANGE `censors` `censors` TINYINT(1) NOT NULL");
	if($value['censors']=="on") {
		$db->query("UPDATE `".$prefix."settings` SET `censors` = '1' WHERE name='settings'");
	} else {
		$db->query("UPDATE `".$prefix."settings` SET `censors` = '0' WHERE name='settings'");
	}
	$db->query("ALTER TABLE `".$prefix."settings` DROP `stats`");
}

if($sub<=9) { ##from 1.2 to 1.3
  echo "<br/>Modifying table ".$prefix."settings: Adding Captcha Script";
  $db->query("ALTER TABLE `".$prefix."settings` ADD `captcha` TINYINT(1) NULL");
  
  echo "<br/>Cleaning up table ".$prefix."skins";
  $db->query("DELETE FROM `".$prefix."skins` WHERE skinname='dbb blue sky'");
  $db->query("DELETE FROM `".$prefix."skins` WHERE skinname='dbb gray'");
  $db->query("DELETE FROM `".$prefix."skins` WHERE skinname='dbb greenworld'");
  
  $db->query("ALTER TABLE `".$prefix."skins`
  DROP `tablebordercolor`,
  DROP `tablewidth`,
  DROP `tdbgcolor`,
  DROP `tdaltbgcolor`,
  DROP `headerbgcolor`,
  DROP `headeraltbgcolor`,
  DROP `barbgcolor`,
  DROP `barbgimage`,
  DROP `catbarbgcolor`,
  DROP `catbarbgimage`,
  DROP `forumbarcolor`,
  DROP `forumcolor`,
  DROP `forumaltcolor`,
  DROP `pinnedthread`,
  DROP `copyrightbox`,
  DROP `topiccolor`,
  DROP `topicaltcolor`,
  DROP `topicseperatorcolor`,
  DROP `topicseperatorimage`");
  
  $fix_skin = $db->query("SELECT skin FROM `".$prefix."settings` WHERE name='settings'");
  if($db->result($fix_skin)=='dbb blue sky'||'dbb gray'||'dbb greenworld') {
    $db->query("UPDATE ".$prefix."settings SET `skin`='blue' WHERE `name`='settings'");
  }
  
	$getdata = $db->query("SELECT uid FROM `".$prefix."users` WHERE (skin='dbb blue sky'||skin='dbb gray'||skin='dbb greenworld')");
	while($workdata = $db->fetch_array($getdata)) {
		$db->query("UPDATE ".$prefix."users SET `skin`='default' WHERE `uid`='$workdata[uid]'");
	}
	
	echo "<br/>Modifying table ".$prefix."skins: Adding the new skin \"blue\"";
	$db->query("INSERT INTO `".$prefix."skins` VALUES ('blue', 'images/blue', 'images/smilies/funny', 'templates/blue', 'logo.gif', '')");
  
  echo "<br/>Modifying table ".$prefix."settings: Adding Topic Starter";
  echo "<br/>Modifying table ".$prefix."settings: Adding Quick Reply Box";
  $db->query("ALTER TABLE `".$prefix."settings` ADD `topicstarter` TINYINT(1) default '0', ADD `quickreply` TINYINT(1) default '0'");

  echo "<br/>Converting Database to utf-8";
  $db->query("ALTER DATABASE `$dbname` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci");
  
  $res = $db->query("SHOW TABLES FROM `$dbname`");
  $arrayentry = "Tables_in_".$dbname;
  while($row = $db->fetch_array($res)) {
    $query = "ALTER TABLE ".$dbname.".`".$row[$arrayentry]."` CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci";
    $db->query($query);
    $query2 = "ALTER TABLE ".$dbname.".`".$row[$arrayentry]."` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci";
    $db->query($query2);
  }
}
echo "<br/>There are lots of other changes, check docs/changelog.txt for a complete list!";
echo "<br/><br/>You have successfully upgraded your forum to $version ($db->qn queries used).<br />Please remove install.php from your server.<br /><br /><a href=\"index.php\">Click here to go to your forum</a>.";
?>
</font></td>
</tr>
</table>
</div>
<?php
} // end if sub==upgrade

if($submit=="Setup") {
?>
<table width="90%" align="center">
<tr>
<td><font size="1">&gt;&gt; <a href="<?php echo $PHP_SELF; ?>">Installation Main Page</a> &gt;&gt; <a href="<?php echo $PHP_SELF; ?>?sub=install">Enter Database information</a> &gt;&gt; Installing..... please wait</font></td>
</tr>
</table>

<br />
<?php

if(!ereg("[A-Za-z0-9_-]+([\.]{1}[A-Za-z0-9_-]+)*@[A-Za-z0-9-]+([\.]{1}[A-Za-z0-9-]+)+", $myemail)) {
	die("Please go back and enter a valid email!");
}

$write = "<?php\n\n";
$write .= "\$hostname = \"$hostname\";\n";
$write .= "\$dbname = \"$dbname\";\n";
$write .= "\$dbusername = \"$dbusername\";\n";
$write .= "\$dbpassword = \"$dbpassword\";\n";
$write .= "\$prefix = \"$prefix\";\n";
$write .= "\$fullpath = \"$fullpath\";\n";
$write .= "\$logs = 1;\n\n";
$write .= "?>";

@chmod('./logs/cp.php', 0666);
@chmod('./settings/info.php', 0666);
@chmod('./files/', 0666);

$file = @fopen('./settings/info.php','w');
if(!$file) {
	echo "<b>We could not create your info.php file, make sure you have Chmoded it 777.<br />The file is located in the settings directory</b>";
	exit();
}
@fputs($file, $write);
@fclose($file);

?>
<table class="tblcl">
<caption>Setting up the database for DeluxeBB</caption>
<tr class="trcl">
<td class="tdcl"><font size="1">
<font color="green"><strong>Configuration File set up...</strong></font><br />

<?php

include('classes/mysql.php');
$db = new db;
$db->connect($hostname, $dbname, $dbusername, $dbpassword);

echo "<br/>Creating ".$prefix."attachments... ";
if($droptables==1) {
	$db->query("DROP TABLE IF EXISTS `".$prefix."attachments`");
}
$db->query("CREATE TABLE `".$prefix."attachments` (
  `aid` mediumint(4) NOT NULL auto_increment,
  `pid` int(5) NOT NULL default '0',
  `filename` varchar(100) NOT NULL default '',
  `ext` varchar(10) NOT NULL default '',
  `type` varchar(50) NOT NULL default '',
  `size` int(5) default '0',
  `downloads` int(4) default '0',
  PRIMARY KEY  (`aid`),
  KEY `pid` (`pid`))
  CHARACTER SET utf8 COLLATE utf8_general_ci
");

echo "<font color=\"green\"><b>Done</b> with ".$prefix."attachments</font><br/><br/>Creating ".$prefix."banned... ";
if($droptables==1) {
	$db->query("DROP TABLE IF EXISTS `".$prefix."banned`");
}
$db->query("CREATE TABLE `".$prefix."banned` (
  `value` VARCHAR(30) NOT NULL,
  `type` VARCHAR(5) NOT NULL)
  CHARACTER SET utf8 COLLATE utf8_general_ci
");

	echo "<font color=\"green\"><b>Done</b> with ".$prefix."banned</font><br/><br/>Creating ".$prefix."boardstats...";
if($droptables==1) {
	$db->query("DROP TABLE IF EXISTS `".$prefix."boardstats`");
}
$db->query("CREATE TABLE `".$prefix."boardstats` (
  `nameof` varchar(225) NOT NULL default '',
  `whatof` varchar(225) NOT NULL default '',
  `whenof` varchar(225) NOT NULL default '',
  PRIMARY KEY  (`nameof`))
  CHARACTER SET utf8 COLLATE utf8_general_ci
");

$db->query("INSERT INTO `".$prefix."boardstats` (`nameof`, `whatof`, `whenof`) VALUES ('members', '1', '$myusername'), ('recordonline', '0', 'No date set')");

echo "<font color=\"green\"><b>Done</b> with ".$prefix."boardstats</font><br/><br/>Creating ".$prefix."categories...";
if($droptables==1) {
	$db->query("DROP TABLE IF EXISTS `".$prefix."categories`");
}
$db->query("CREATE TABLE `".$prefix."categories` (
  `cid` int(3) NOT NULL auto_increment,
  `ordered` int(5) NOT NULL default '0',
  `name` varchar(225) NOT NULL default '',
  PRIMARY KEY  (`cid`))
  CHARACTER SET utf8 COLLATE utf8_general_ci
");

$db->query("INSERT INTO ".$prefix."categories VALUES ('1', '0', 'Default')");

echo "<font color=\"green\"><b>Done</b> with ".$prefix."categories</font><br/><br/>Creating ".$prefix."forums...";

if($droptables==1) {
	$db->query("DROP TABLE IF EXISTS `".$prefix."forums`");
}
$db->query("CREATE TABLE `".$prefix."forums` (
  `ordered` int(5) default '0',
  `cid` int(3) default NULL,
  `name` varchar(225) default NULL,
  `fid` int(6) NOT NULL auto_increment,
  `topics` int(6) default NULL,
  `replies` int(6) default NULL,
  `viewstatus` varchar(10) default NULL,
  `poststatus` varchar(10) default NULL,
  `replystatus` varchar(10) default NULL,
  `lastpost` varchar(225) default NULL,
  `lastpostby` int(10) default '0',
  `description` tinytext default NULL,
  `lastpid` int(6) default '0',
  `lastpidtime` varchar(255) default NULL,
  `password` varchar(32) default '',
  `userlist` mediumtext NOT NULL,
  `moderators` mediumtext NOT NULL,
  `redirect` VARCHAR(225) NOT NULL default '',
  PRIMARY KEY  (`fid`),
  KEY `cid` (`cid`),
  KEY `lastpostby` (`lastpostby`),
  KEY `lastpid` (`lastpid`))
  CHARACTER SET utf8 COLLATE utf8_general_ci
");

$db->query("INSERT INTO ".$prefix."forums VALUES ('0', '1', 'Default Forum', 1, '0', '0', 'all', 'all', 'all', NULL, NULL, 'You can change all this, add and edit within the admin cp', 0, NULL, '', '', '', '')");

echo "<font color=\"green\"><b>Done</b> with ".$prefix."forums</font><br/><br/>Creating ".$prefix."online... ";
if($droptables==1) {
	$db->query("DROP TABLE IF EXISTS `".$prefix."online`");
}
$db->query("CREATE TABLE `".$prefix."online` (
  `name` varchar(225) NOT NULL default '',
  `time` varchar(225) NOT NULL default '',
  `wherein` varchar(225) NOT NULL default '',
  `ip` varchar(225) NOT NULL default '')
  CHARACTER SET utf8 COLLATE utf8_general_ci
");

echo "<font color=\"green\"><b>Done</b> with ".$prefix."online</font><br/><br/>Creating ".$prefix."pm... ";
if($droptables==1) {
	$db->query("DROP TABLE IF EXISTS `".$prefix."pm`");
}
$db->query("CREATE TABLE ".$prefix."pm (
  `pmid` int(10) NOT NULL auto_increment,
  `whoto` varchar(70) NOT NULL default '',
  `from` varchar(70) NOT NULL default '',
  `subject` varchar(255) NOT NULL default '',
  `post` mediumtext NOT NULL,
  `posticon` varchar(40) NOT NULL default '',
  `hasread` char(3) NOT NULL default '',
  `orderunixtime` int(10) NOT NULL default '0',
  `type` varchar(20) NOT NULL default '',
  PRIMARY KEY (pmid))
  CHARACTER SET utf8 COLLATE utf8_general_ci
");

echo "<font color=\"green\"><b>Done</b> with ".$prefix."pm</font><br/><br/>Creating ".$prefix."posts... ";
if($droptables==1) {
	$db->query("DROP TABLE IF EXISTS `".$prefix."posts`");
}
$db->query("CREATE TABLE `".$prefix."posts` (
   `pid` bigint(10) NOT NULL auto_increment,
   `tid` bigint(10) NOT NULL default '0',
   `author` int(10) NOT NULL,
   `subject` varchar(255) NOT NULL,
   `message` text NOT NULL,
   `picon` varchar(50) NOT NULL,
   `postdate` int(10) NOT NULL,
   `ip` varchar(50) NOT NULL,
   `smiliesoff` smallint(1) default '0',
   PRIMARY KEY (`pid`),
   KEY `tid` (`tid`),
   KEY `author` (`author`))
  CHARACTER SET utf8 COLLATE utf8_general_ci
");

echo "<font color=\"green\"><b>Done</b> with ".$prefix."posts</font><br/><br/>Creating ".$prefix."posts_archive... ";

if($droptables==1) {
	$db->query("DROP TABLE IF EXISTS `".$prefix."posts_archive`");
}
$db->query("CREATE TABLE IF NOT EXISTS `".$prefix."posts_archive` (
  `pid` bigint(10) NOT NULL default '0',
  `tid` bigint(10) NOT NULL default '0',
  `author` int(10) NOT NULL default '0',
  `subject` varchar(255) NOT NULL default '',
  `message` text NOT NULL,
  `postdate` int(10) NOT NULL default '0',
  `smiliesoff` smallint(1) default NULL,
  KEY `author` (`author`),
  KEY `pid` (`pid`),
  KEY `tid` (`tid`))
  CHARACTER SET utf8 COLLATE utf8_general_ci
");

echo "<font color=\"green\"><b>Done</b> with ".$prefix."posts_archive</font><br/><br/>Creating ".$prefix."ranks... ";

if($droptables==1) {
	$db->query("DROP TABLE IF EXISTS ".$prefix."ranks");
}
$db->query("CREATE TABLE IF NOT EXISTS ".$prefix."ranks ( 
  `rid` int(3) NOT NULL auto_increment,
  `title` varchar(100) NOT NULL default '',
  `posts` smallint(5) default '0',
  `stars` smallint(6) NOT NULL default '0',
  `starimage` varchar(50) NOT NULL default '',
  `allowavatar` tinyint(1) NOT NULL default '0',
  `allowsig` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`rid`))
  CHARACTER SET utf8 COLLATE utf8_general_ci
"); 

$db->query("INSERT INTO ".$prefix."ranks VALUES (1, 'Newbie', 0, 1, 'star.gif', 1, 1)");
$db->query("INSERT INTO ".$prefix."ranks VALUES (2, 'Copper Member', 5, 2, 'star.gif', 1, 1)");
$db->query("INSERT INTO ".$prefix."ranks VALUES (3, 'Bronze Member', 20, 3, 'star.gif', 1, 1)");
$db->query("INSERT INTO ".$prefix."ranks VALUES (4, 'Silver Member', 100, 4, 'star.gif', 1, 1)");
$db->query("INSERT INTO ".$prefix."ranks VALUES (5, 'Gold Member', 500, 5, 'star.gif', 1, 1)");
$db->query("INSERT INTO ".$prefix."ranks VALUES (6, 'Platinum Member', 1000, 6, 'star.gif', 1, 1)");
$db->query("INSERT INTO ".$prefix."ranks VALUES (7, 'Moderator', NULL, 7, 'star.gif', 1, 1)");
$db->query("INSERT INTO ".$prefix."ranks VALUES (8, 'Super Moderator', NULL, 8, 'star.gif', 1, 1)");
$db->query("INSERT INTO ".$prefix."ranks VALUES (9, 'Administrator', NULL, 9, 'star.gif', 1, 1)");
$db->query("INSERT INTO ".$prefix."ranks VALUES (10, 'Head Admin', NULL, 9, 'star.gif', 1, 1)");

echo "<font color=\"green\"><b>Done</b> with ".$prefix."ranks</font><br/><br/>Creating ".$prefix."replacements... ";

if($droptables==1) {
	$db->query("DROP TABLE IF EXISTS ".$prefix."replacements");
}
$db->query("CREATE TABLE IF NOT EXISTS ".$prefix."replacements ( 
  id smallint(5) unsigned NOT NULL auto_increment,
  tag varchar(200) NOT NULL DEFAULT '',
  replacement MEDIUMTEXT NOT NULL,
  type varchar(30) NOT NULL DEFAULT '',
  inmenu char(3) NOT NULL DEFAULT '',
  enabled char(3) NOT NULL DEFAULT '',
  PRIMARY KEY (id))
  CHARACTER SET utf8 COLLATE utf8_general_ci
");
	
$db->query("INSERT INTO `".$prefix."replacements` VALUES (1, ':D', 'bigsmile.gif', 'smilie', 'yes', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (2, ':-D', 'bigsmile.gif', 'smilie', 'no', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (3, ':d', 'bigsmile.gif', 'smilie', 'no', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (4, ':-d', 'bigsmile.gif', 'smilie', 'no', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (5, ':|', 'down.gif', 'smilie', 'yes', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (6, ':-|', 'down.gif', 'smilie', 'no', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (7, '(!)', 'exclamation.gif', 'smilie', 'yes', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (8, ';-)', 'wink.gif', 'smilie', 'yes', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (9, ';)', 'wink.gif', 'smilie', 'no', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (10, ':o', 'shocked.gif', 'smilie', 'yes', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (11, ':-o', 'shocked.gif', 'smilie', 'no', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (12, ':O', 'shocked.gif', 'smilie', 'no', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (13, ':-O', 'shocked.gif', 'smilie', 'no', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (14, ':(', 'sad.gif', 'smilie', 'yes', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (15, ':-(', 'sad.gif', 'smilie', 'no', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (16, '[cool]', 'cool.gif', 'smilie', 'yes', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (17, '[happy]', 'happy.gif', 'smilie', 'yes', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (18, ':x', 'mad.gif', 'smilie', 'yes', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (19, ':X', 'mad.gif', 'smilie', 'no', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (20, ':\\\', 'moarn.gif', 'smilie', 'yes', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (21, '(?)', 'question.gif', 'smilie', 'yes', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (22, ':)', 'smile.gif', 'smilie', 'no', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (23, ':-)', 'smile.gif', 'smilie', 'no', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (24, ':P', 'tongue.gif', 'smilie', 'yes', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (25, ':p', 'tongue.gif', 'smilie', 'no', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (26, '', 'bigsmile.gif', 'posticon', 'yes', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (27, '', 'cool.gif', 'posticon', 'yes', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (28, '', 'exclamation.gif', 'posticon', 'yes', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (29, '', 'mad.gif', 'posticon', 'yes', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (30, '', 'question.gif', 'posticon', 'yes', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (31, '', 'sad.gif', 'posticon', 'yes', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (32, '', 'shocked.gif', 'posticon', 'yes', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (33, '', 'smile.gif', 'posticon', 'yes', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (34, '', 'wink.gif', 'posticon', 'yes', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (35, '', 'tongue.gif', 'posticon', 'yes', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (36, '', 'thumbup.gif', 'posticon', 'yes', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (37, '', 'thumbdown.gif', 'posticon', 'yes', 'yes')");
$db->query("INSERT INTO `".$prefix."replacements` VALUES (38, 'fuck', 'f*ck', 'censor', '', 'yes')");

echo "<font color=\"green\"><b>Done</b> with ".$prefix."replacements</font><br/><br/>Creating ".$prefix."restrictions... ";	
if($droptables==1) {
	$db->query("DROP TABLE IF EXISTS `".$prefix."restrictions`");
}
$db->query("CREATE TABLE `".$prefix."restrictions` (
  `name` varchar(100) NOT NULL default '',
  `status` smallint(1) NOT NULL default '0',
  `settings` smallint(1) NOT NULL default '0',
  `editmember` smallint(1) NOT NULL default '0',
  `maintenance` smallint(1) NOT NULL default '0',
  `skins` smallint(1) NOT NULL default '0',
  `editforum` smallint(1) NOT NULL default '0',
  `editposticons` smallint(1) NOT NULL default '0',
  `editsmilies` smallint(1) NOT NULL default '0',
  `editcensors` smallint(1) NOT NULL default '0',
  `ban` smallint(1) NOT NULL default '0',
  `cplogopt` smallint(1) NOT NULL default '0',
  `cplog` smallint(1) NOT NULL default '0',
  `optimize` smallint(1) NOT NULL default '0',
  `exec` smallint(1) NOT NULL default '0',
  `pruneposts` smallint(1) NOT NULL default '0',
  `prunepms` smallint(1) NOT NULL default '0',
  `backup` smallint(1) NOT NULL default '0',
  `newsletter` smallint(1) NOT NULL default '0',
  `attachsettings` smallint(1) NOT NULL default '0',
  `listattachments` smallint(1) NOT NULL default '0',
  `userranks` smallint(1) NOT NULL default '0')
  CHARACTER SET utf8 COLLATE utf8_general_ci
");

$db->query("INSERT INTO `".$prefix."restrictions` VALUES ('default', 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1)");

echo "<font color=\"green\"><b>Done</b> with ".$prefix."restrictions</font><br/><br/>Creating ".$prefix."settings... ";	
if($droptables==1) {
	$db->query("DROP TABLE IF EXISTS `".$prefix."settings`");
}
$db->query("CREATE TABLE `".$prefix."settings` (
  `name` char(8) NOT NULL default '',
  `homeurl` varchar(225) NOT NULL default '',
  `maintenance` smallint(1) NOT NULL default '0',
  `maintenancemsg` text NOT NULL,
  `headadmin` varchar(50) NOT NULL default '',
  `boardname` varchar(225) NOT NULL default '',
  `siglength` smallint(2) NOT NULL default '0',
  `sightml` tinyint(1) NOT NULL,
  `language` varchar(225) NOT NULL default '',
  `avatarw` int(4) NOT NULL default '0',
  `avatarh` int(4) NOT NULL default '0',
  `avatarwlow` int(3) NOT NULL default '0',
  `avatarhlow` int(3) NOT NULL default '0',
  `skin` varchar(225) NOT NULL default '',
  `logpath` varchar(30) NOT NULL default '',
  `cplog` tinyint(1) NOT NULL,
  `gzip` tinyint(1) NOT NULL,
  `hottopic` int(4) NOT NULL default '0',
  `tppf` smallint(3) NOT NULL default '0',
  `tppt` smallint(3) NOT NULL default '0',
  `ompp` smallint(3) NOT NULL default '0',
  `homeurlname` varchar(100) NOT NULL default '',
  `htmloff` tinyint(1) NOT NULL default '0',
  `smilies` tinyint(1) NOT NULL,
  `censors` tinyint(1) NOT NULL,
  `editby` smallint(1) NOT NULL default '0',
  `duplicateemail` smallint(1) NOT NULL default '0',
  `floodctrl` smallint(1) NOT NULL default '0',
  `maxpm` smallint(5) NOT NULL default '0',
  `useredit` smallint(1) NOT NULL default '0',
  `maxchars` smallint(5) NOT NULL default '0',
  `guestposting` smallint(1) NOT NULL default '0',
  `dateformat` varchar(10) NOT NULL default '',
  `timeformat` smallint(2) NOT NULL default '0',
  `timeoffset` smallint(2) NOT NULL default '0',
  `overridedate` tinyint(1) NOT NULL default '0',  
  `overridetime` tinyint(1) NOT NULL default '0',
  `overrideoffset` tinyint(1) NOT NULL default '0', 
  `hideprivf` smallint(1) NOT NULL default '0',
  `showmod` smallint(1) NOT NULL default '0',
  `gzlevel` smallint(1) NOT NULL default '0',
  `perstitleedit` smallint(1) NOT NULL default '0',
  `pmwelcome` smallint(1) NOT NULL default '0',
  `pmwelcometxt` mediumtext NOT NULL,
  `allowattach` smallint(1) NOT NULL default '0',
  `attachdir` varchar(100) NOT NULL default '',
  `attachtypes` varchar(100) NOT NULL default '',
  `attachmaxsize` int(5) NOT NULL default '0',
  `attachimgpost` smallint(1) NOT NULL default '0',
  `spr` smallint(2) NOT NULL default '0',
  `email_pro` smallint(1) NOT NULL default '0',
  `showlocation` smallint(1) NOT NULL default '0',
  `userranks` smallint(1) NOT NULL default '0',
  `invisible` tinyint(1) default '0',
  `wrap` tinyint(1) default '0',
  `wraplength` smallint(1) NOT NULL,
  `guestmemfunctions` tinyint(1) default '0',
  `allowpm` tinyint(1) default '0',
  `allowonline` tinyint(1) default '0',
  `guestforumview` tinyint(1) default '0',
  `allowlostpw` tinyint(1) default '0',
  `showforumrules` tinyint(1) default '0',
  `forumrules` mediumtext,
  `edithistory` tinyint(1) default '0',
  `emailver` tinyint(1) default '0',
  `captcha` tinyint(1) default '0',
  `topicstarter` tinyint(1) default '0',
  `quickreply` tinyint(1) default '0')
  CHARACTER SET utf8 COLLATE utf8_general_ci
");

$db->query("INSERT INTO `".$prefix."settings` VALUES ('settings', 'http://www.deluxebb.com', '0', 'Sorry, we are in Maintenance', '$myusername', 'My New DeluxeBB!', '4', '1', 'English', '120', '120', '5', '5', 'blue', 'logs', '1', '0', '20', '15', '20', '20', 'DeluxeBB homepage', '0', '1', '1', '0', '0', '20', '100', '1', '5000', '1', 'd.m.y', '12', '0', '0', '0', '0', '1', '1', '5', '0', '1', '<u>Hello and welcome to \"<b>\$boardname</b>\".</u><br />\nWe hope you have fun joining in the community, helping us out and having a general browse.<br />\nThank you for registering. Happy posting.\nYour DeluxeBB Team\n\n\n<br /><br />Btw: <a href=\"http://www.deluxebb.com\">Using DeluxeBB is for free, you can get it here</a>', '1', './files/', 'bmp gif jpg jpeg tif zip rar txt doc', '1048576', '1', '3', '0', '0', '1', '1', '0', '100', '1', '1', '1', '1', '1', '0', 'Text here', '0', '0', '0', '1', '1')");

echo "<font color=\"green\"><b>Done</b> with ".$prefix."settings</font><br/><br/>Creating ".$prefix."subscriptions... ";
if($droptables==1) {
	$db->query("DROP TABLE IF EXISTS `".$prefix."subscriptions`");
}
$db->query("CREATE TABLE `".$prefix."subscriptions` (
  `tid` int(10) NOT NULL default '0',
  `pid` bigint(10) NOT NULL default '0',
  `uid` int(10) NOT NULL default '0',
  `checked` tinyint(1) NOT NULL default '0',
  KEY (`tid`),
  KEY (`pid`),
  KEY (`uid`))
  CHARACTER SET utf8 COLLATE utf8_general_ci
");

echo "<font color=\"green\"><b>Done</b> with ".$prefix."subscriptions</font><br/><br/>Creating ".$prefix."skins... ";
if($droptables==1) {
	$db->query("DROP TABLE IF EXISTS `".$prefix."skins`");
}
$db->query("CREATE TABLE `".$prefix."skins` (
  `skinname` varchar(40) NOT NULL default '',
  `images` varchar(100) NOT NULL default '',
  `smiliepath` varchar(100) NOT NULL default '',
  `templatefolder` varchar(100) NOT NULL default '',
  `logourl` varchar(100) NOT NULL default '',
  `comment` text NOT NULL)
  CHARACTER SET utf8 COLLATE utf8_general_ci
");

$db->query("INSERT INTO `".$prefix."skins` VALUES ('deluxe', 'images/deluxe', 'images/smilies/standart', 'templates/deluxe', 'logo.png', '')");
$db->query("INSERT INTO `".$prefix."skins` VALUES ('corporate', 'images/corporate', 'images/smilies/dark', 'templates/corporate', 'logo.gif', '')");
$db->query("INSERT INTO `".$prefix."skins` VALUES ('blue', 'images/blue', 'images/smilies/funny', 'templates/blue', 'logo.gif', '')");

echo "<font color=\"green\"><b>Done</b> with ".$prefix."skins</font><br/><br/>Creating ".$prefix."threads... ";
if($droptables==1) {
	$db->query("DROP TABLE IF EXISTS `".$prefix."threads`");
}
$db->query("CREATE TABLE `".$prefix."threads` (
  `tid` bigint(10) NOT NULL auto_increment,
  `fid` int(5) NOT NULL default '0',
  `author` int(10) NOT NULL default '0',
  `subject` varchar(255) NOT NULL default '',
  `picon` varchar(50) NOT NULL default '',
  `views` int(3) NOT NULL default '0',
  `replies` int(3) NOT NULL default '0',
  `closed` smallint(1) NOT NULL default '0',
  `pinned` smallint(1) NOT NULL default '0',
  `moved` int(10) unsigned default '0',
  `lastpostby` varchar(255) NOT NULL default '0',
  `lastpostdate` int(10) NOT NULL default '0',
  PRIMARY KEY  (`tid`),
  KEY (`fid`),
  KEY (`pinned`),
  KEY (`lastpostdate`),
  KEY (`author`),
  KEY (`moved`))
  CHARACTER SET utf8 COLLATE utf8_general_ci
");

echo "<font color=\"green\"><b>Done</b> with ".$prefix."threads</font><br/><br/>Creating ".$prefix."users... ";
if($droptables==1) {
	$db->query("DROP TABLE IF EXISTS `".$prefix."users`");
}
$db->query("CREATE TABLE `".$prefix."users` (
  `uid` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(255) default NULL,
  `pass` varchar(32) default NULL,
  `email` varchar(50) default NULL,
  `membercode` int(1) default '0',
  `customtitle` varchar(50) default NULL,
  `sig` varchar(255) default NULL,
  `msn` varchar(30) default NULL,
  `icq` varchar(30) NOT NULL default '',
  `aim` varchar(30) default NULL,
  `yim` varchar(30) default NULL,
  `avatar` varchar(255) default NULL,
  `posts` int(10) default '0',
  `lastpost` int(10) default '0',
  `location` varchar(255) default NULL,
  `skin` varchar(30) default NULL,
  `language` varchar(20) default NULL,
  `joineddate` int(10) default '0',
  `hideemail` char(3) default NULL,
  `site` varchar(120) default NULL,
  `timeoffset` smallint(2) default '0',
  `dateformat` varchar(10) default NULL,
  `timeformat` smallint(2) default '0',
  `lastip` varchar(15) default NULL,
  `lastactive` int(10) default '0',
  `pmnotify` smallint(1) default '0',
  `markposts` mediumint(2) default '0',
  `invisible` tinyint(1) default '0',
  `valnum` varchar(10) default NULL,
  PRIMARY KEY (`uid`))
  CHARACTER SET utf8 COLLATE utf8_general_ci
");

$mypassword = md5($mypassword);
$todaydate = time();

$db->query("INSERT INTO ".$prefix."users VALUES (NULL, '$myusername', '$mypassword', '$myemail', '5',  NULL, NULL, NULL, '', NULL, NULL, NULL, '0',  NULL, NULL, 'default', 'English', '$todaydate', '0',  NULL, '0',  'd.m.y', '12', NULL, NULL, NULL, '15', '0', NULL)");
$db->query("INSERT INTO ".$prefix."users VALUES (NULL, 'guest', '', '', '0', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '$todaydate', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)");
$db->query("INSERT INTO ".$prefix."users VALUES (NULL, 'invisible', '', '', NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '$todaydate', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)");

	echo "<font color=\"green\"><b>Done</b> with ".$prefix."users</font><br/><br/><b><u>Installation Complete ($db->qn queries used)</u><br />Please delete install.php from your server now, afterwards you can log in to your brandnew forum <a href=\"misc.php?sub=login\">here</a>.</b></font>";

?>
</font></td>
</tr>
</table>
</div>

<?php
} elseif($test=="Test Input") {
?>
<table width="90%" align="center">
<tr>
<td><font size="1">&gt;&gt; <a href="<?php echo $PHP_SELF; ?>">Installation Main Page</a> &gt;&gt; Checking Connection</font></td>
</tr>
</table>

<br />
<form method="post" action="<?php echo $PHP_SELF; ?>">
<table class="tblcl">
<caption>Results</caption>
<tr class="trcl">
<td class="tdcl"><font size="1">
<?php
	//Initialising
	$errors = 0;
	
	//Checking PHP version
	echo "PHP version: ";
	if(phpversion() < '5.0.0') {
		echo "<font color=\"red\">PHP5 is not installed --- <b>FAILURE</b></font><br />";
		$errors++;
	} else {
		echo "<font color=\"green\">" .phpversion() . " installed --- <b>OK</b></font><br />";
	}
	//Checking Database Connection
	echo "MySQL connection ";
	$link = @mysql_connect($hostname, $dbusername, $dbpassword);
	if(!$link) {
		echo "<font color=\"red\">failed: " . mysql_error() . " --- <b>FAILURE</b></font><br />";
		$errors++;
	} else {
		echo "<font color=\"green\">successfull --- <b>OK</b></font><br />";
	}
	//Checking if Database Exists
	echo "MySQL database ";
	$connection = @mysql_select_db($dbname, $link);
	if($connection===FALSE) {
		echo "<font color=\"red\">dosn't exist --- <b>FAILURE</b></font><br />";
		$errors++;
	} else {
		echo "<font color=\"green\">exists --- <b>OK</b></font><br />";
	}
	@mysql_close($link);
	
	//Checking file and folder permissions
	echo "Writable files:<br />../settings/info.php ";
	if(!is_writable('settings/info.php')) {
		echo "<font color=\"red\">is missing or not writable --- <b>FAILURE</b></font><br />";
		$errors++;
	} else {
		echo "<font color=\"green\">is writable --- <b>OK</b></font><br />";
	}
	echo "../logs/cp.php ";
	if(!is_writable('logs/cp.php')) {
		echo "<font color=\"red\">is missing or not writable --- <b>FAILURE</b></font><br />";
		$errors++;
	}  else {
		echo "<font color=\"green\">is writeable --- <b>OK</b></font><br />";
	}
	echo "../files/ ";
	if(!is_writable('files')) {
		echo "<font color=\"red\">is missing or not writable --- <b>FAILURE</b></font><br />";
		$errors++;
	} else {
		echo "<font color=\"green\">is writeable --- <b>OK</b></font><br />";
	}
	//Checking Admin Email
	echo "Admin Email ";
	if(!ereg("[A-Za-z0-9_-]+([\.]{1}[A-Za-z0-9_-]+)*@[A-Za-z0-9-]+([\.]{1}[A-Za-z0-9-]+)+", $myemail)) {
		echo "<font color=\"red\">is not valid --- <b>FAILURE</b></font><br />";
		$errors++;
	} else {
		echo "<font color=\"green\">is valid --- <b>OK</b></font><br />";
	}
	if($errors!=0) {
		echo "<br /><br />Not all of your informations were correct or your host doesn't match all requirements.<br />Check above whats wrong and hit the back button to correct your input.<br />If you're not sure how to solve the problem contact us at <a href=\"http://www.deluxebb.com/community\">DeluxeBB.com/community</a>"; 
	} else {
		echo "<br /><br />Everything seems to be OK! Proceed installing DeluxeBB by hitting the Setup button!";
	}
?>
</font></td></tr>
<tr class="title">
<td><font size="1">
<input type="hidden" name="dbname" value="<?php echo $dbname; ?>" />
<input type="hidden" name="dbusername" value="<?php echo $dbusername; ?>" />
<input type="hidden" name="dbpassword" value="<?php echo $dbpassword; ?>" />
<input type="hidden" name="hostname" value="<?php echo $hostname; ?>" />
<input type="hidden" name="prefix" value="<?php echo $prefix; ?>" />
<input type="hidden" name="droptables" value="<?php echo $droptables; ?>" />
<input type="hidden" name="fullpath" value="<?php echo $fullpath; ?>" />
<input type="hidden" name="myusername" value="<?php echo $myusername; ?>" />
<input type="hidden" name="mypassword" value="<?php echo $mypassword; ?>" />
<input type="hidden" name="mypassword2" value="<?php echo $mypassword2; ?>" />
<input type="hidden" name="myemail" value="<?php echo $myemail; ?>" />
<input type="submit" value="Setup" name="submit" /> <input type="button" value="Back to previous page" name="back" onclick="javascript:window.back();" />
</font></td>
</tr>
</table>
</form>
</div>
<?php	
}
?>

<div id="footer">
<div class="copyright"><br /><br /><br /><br />Copyright deluxebb.com 2008 All rights Reserved&copy;</div>
</div>
</div>
</div>
</body>

</html>