<?php

declare(strict_types=1);

namespace GitList\SCM\Exception;

class InvalidCommitException extends \RuntimeException
{
}
