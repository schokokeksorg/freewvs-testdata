<?php
if(!defined("PHORUM_ADMIN")) return;

/* keep it empty here for sanity - its content is now in 2007071900 */
?>
