UPDATE `lc_settings` SET `function` = 'password()' WHERE `key` = 'smtp_password' LIMIT 1;
-- --------------------------------------------------------
UPDATE `lc_countries` SET `language_code` = 'sv' WHERE `iso_code_2` = 'AX' LIMIT 1;
